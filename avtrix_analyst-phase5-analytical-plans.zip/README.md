# AvTrix Fleet Intelligence — Local Analyst

Replaces Databricks Genie with a local Ollama LLM connected directly
to your Delta tables. No usage caps. Everything runs on your laptop.
Your data never leaves your environment.

---

## First-time setup (one-time, ~10 minutes)

### 1. Install Python dependencies

```bash
pip install databricks-sql-connector python-dotenv ollama
```

### 2. Configure your credentials

```bash
cp .env.template .env
```

Open `.env` and fill in your three Databricks values:

| Setting | Where to find it |
|---|---|
| `DATABRICKS_HOST` | Databricks workspace URL (without https://) |
| `DATABRICKS_HTTP_PATH` | SQL Warehouses → your warehouse → Connection details |
| `DATABRICKS_TOKEN` | User Settings → Access Tokens → Generate new token |

`HISTORY_TABLE` is only the startup dataset. In the browser you can switch to
another accessible catalog, schema and table without editing `.env` or restarting
AvTrix.

Optional connector controls are already set to safe defaults in `.env.template`:

| Setting | Default | Purpose |
|---|---:|---|
| `DATABRICKS_QUERY_TIMEOUT_SECONDS` | `60` | Cancels a query that exceeds the local request budget |
| `DATABRICKS_MAX_ROWS` | `500` | Maximum rows returned to the CLI or browser |
| `DATABRICKS_SESSION_RETRIES` | `1` | Reconnect attempts after an expired session |
| `AVTRIX_LOG_LEVEL` | `INFO` | Local diagnostic logging level |

### 3. Pull the Ollama model (first time only)

```bash
ollama pull llama3
```

This downloads ~4GB once. Never again after that.

---

## Daily usage

### Start Ollama (if not set to auto-start)

```bash
ollama serve
```

Leave this running in a terminal tab. You only need to do this once per session.

### Open the analyst

```bash
cd avtrix_analyst
python avtrix_analyst.py
```

That's it. You're connected and ready.

---

## What you can do

### Use guided questions in either view

Focused and Analyst views both keep a persistent **Try asking** shelf above the
composer. Successful answers add up to three contextual **Ask next** questions;
choosing one places it in the active composer for review. Chart follow-ups reuse
the last result locally instead of asking the model to regenerate SQL.

“What data is available?” and “Give me a general summary of the datasets” are
handled as instant portfolio requests. They list discovered tables, the active
dataset and indicative coverage without invoking Ollama or generating SQL. Use
“Give me a general overview of the active dataset” for descriptive statistics,
date coverage and profile-driven charts. Use “profile the active dataset” for
the field-by-field structural profile, or “run a data integrity check” for the
completeness audit.

### Discover and switch datasets

The browser context panel discovers accessible Databricks catalogs, schemas and
tables. Selecting a table validates it with a live `DESCRIBE TABLE`, makes it the
server-side query target, and refreshes the schema context used for SQL
generation.

Every active dataset has a SHA-256 schema fingerprint derived from its live
column names, data types and comments. The profiler uses this fingerprint to
detect schema changes and will not reuse a profile created for an older schema.

Dataset discovery endpoints:

| Endpoint | Purpose |
|---|---|
| `GET /api/catalogs` | Accessible catalogs |
| `GET /api/schemas?catalog=...` | Schemas in a catalog |
| `GET /api/tables?catalog=...&schema=...` | Tables and views in a schema |
| `POST /api/table` | Validate and activate a fully qualified table |
| `GET /api/profile` | Return the matching cached profile summary, if one exists |
| `POST /api/profile` | Generate or refresh the active dataset profile |

`HISTORY_TABLE` remains as the startup fallback only; it is not the permanent
query target.

### Profile any selected dataset

Select a dataset, then use **Generate profile** in the context panel or ask
“profile the active dataset”. AvTrix runs bounded, read-only aggregate queries
and records:

- record and column counts;
- null, blank and placeholder rates;
- approximate distinct counts;
- numeric minimum, mean, maximum and sample standard deviation, plus date ranges;
- inferred identifiers, dimensions, measures, dates and cumulative fields;
- low-cardinality representative values and counts;
- candidate identifiers and possible natural-key components; and
- structural and formatting flags for review.

Profiles are stored locally in `.avtrix_profiles/`, excluded from Git, and
matched to the live schema fingerprint. Representative values are never
sampled from field names that look sensitive, including names, email, phone,
address, notes and account fields. Set `AVTRIX_PROFILE_SAMPLE_VALUES=false` to
store only counts, ranges and classifications.

All findings are evidence for review. Approximate uniqueness is not proof of a
key, and a review flag is not proof that a value is wrong.

### Natural language questions

```
AvTrix > how many records have a null jobtype in 2023?
AvTrix > show me the top 10 most frequently removed parts
AvTrix > what's the breakdown of reason codes under SCHEDULED jobs?
AvTrix > which components have the lowest MTBUR values?
```

For supported analytical patterns, AvTrix resolves the requested concepts
against live columns and builds SQL deterministically. For example,
“distribution of removal reason by aircraft” resolves both dimensions from the
active schema, runs a bounded grouped query and returns a stacked chart. If a
phrase maps to more than one field, AvTrix asks for clarification.

Unsupported analytical patterns fall back to local-model SQL generation. The
tool displays the SQL and interprets the returned evidence — same flow as
Genie, with no usage cap.

Questions that ask for both job-type and removal-reason spread are routed to an
evidence-led visual story rather than generic domain knowledge. The browser
shows an overall job-type donut beside a stacked bar of the leading removal
reasons, then reports the exact split, leading valid reasons and any missing or
placeholder classifications. For example:

```
AvTrix > what's the spread across jobtype and removal reason?
```

### Named shortcuts (pre-built, instant)

Pre-built queries from the FB discovery analysis. No LLM needed — run directly.

```bash
# List all shortcuts
python avtrix_analyst.py --list

# Run a specific shortcut
python avtrix_analyst.py --run jobtype_temporal
python avtrix_analyst.py --run reason_by_jobtype
python avtrix_analyst.py --run workorder_coverage
python avtrix_analyst.py --run component_mtbur
```

Or from inside the interactive session:
```
AvTrix > run jobtype_temporal
AvTrix > run component_mtbur
```

### Raw SQL (no LLM, instant)

```
AvTrix > sql SELECT COUNT(*) FROM poc.avtrix_fb.alg_history_report
```

Or from the command line:
```bash
python avtrix_analyst.py --sql "SELECT COUNT(*) FROM poc.avtrix_fb.alg_history_report"
```

### Save results to CSV

```
AvTrix > save
AvTrix > run component_mtbur
```

Or via flag:
```bash
python avtrix_analyst.py --run component_mtbur --save
```

---

## Named shortcuts available

| Shortcut | What it does |
|---|---|
| `jobtype_distribution` | Overall SCHEDULED / UNSCHEDULED / NULL split |
| `jobtype_temporal` | JOBTYPE by year — surfaces the 2022-2025 labelling collapse |
| `reason_by_jobtype` | Job-type spread plus removal-reason mix, with missing labels made explicit |
| `workorder_coverage` | WORKORDER_NUMBER population rate |
| `installed_side_capture` | INSTALLED_PARTNO/SERIALNO null rates across three denominators |
| `utilisation_by_year` | Annual flight hours derived from the maintenance record |
| `missing_dates_by_aircraft` | Missing install/removal dates by aircraft registration |
| `time_expired_split` | TIME EXPIRED reason split across SCHEDULED vs UNSCHEDULED |
| `true_reliability_population` | Count of defensible reliability events after all filters |
| `component_mtbur` | Component-level MTBUR for parts with n ≥ 5 events |

---

## What persists when you shut down

| Thing | Persists? |
|---|---|
| Delta tables in Databricks | ✓ Always — unaffected by anything local |
| This script | ✓ It's a file on your laptop |
| Ollama models | ✓ Downloaded once, stored locally forever |
| Your .env credentials | ✓ File on your laptop |
| CSV exports | ✓ Saved to the script folder |
| Conversation context | ✗ Resets each session (same as a browser tab) |
| Ollama server process | ✗ Needs `ollama serve` each session (or set to auto-start) |

**Bottom line:** shut down any time. Open the laptop, run `ollama serve` + `python avtrix_analyst.py`, and you're back exactly where you were.

---

## Auto-start Ollama on login (optional)

### Mac
```bash
# Add to your ~/.zshrc or ~/.bashrc
# ollama serve runs automatically — no need to start it manually
```
Ollama on Mac installs as a menu bar app and auto-starts by default.

### Windows
Add a shortcut to `ollama serve` in your Startup folder
(`shell:startup` in Windows Explorer).

---

## Adding new named shortcuts

Open `avtrix_analyst.py` and add an entry to the `NAMED_QUERIES` dict:

```python
"my_new_query": {
    "description": "What this query does",
    "sql": """
        SELECT ...
        FROM {table}
        WHERE ...
    """
},
```

The `{table}` placeholder is automatically replaced with your `HISTORY_TABLE` value.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `Databricks connection failed` | Check .env credentials. Try generating a new token. |
| `Ollama not reachable` | Run `ollama serve` in a separate terminal |
| `Model not found` | Run `ollama pull llama3` |
| SQL error from LLM | Use `sql <query>` mode and write SQL directly |
| Wrong table name | Update `HISTORY_TABLE` in .env |

### Databricks connection lifecycle

AvTrix does not share one Databricks cursor across browser requests. Each query
gets a managed connection that is closed after use. Before the UI reports
Databricks as ready, it executes `SELECT 1` rather than only checking that a
Python connection object exists.

If Databricks returns `INVALID_STATE: Invalid SessionHandle`, AvTrix reconnects
and retries the query once. It will not retry authentication, permissions or SQL
errors, and it will not enter an unlimited retry loop.

API failures are returned as JSON with a category, safe message and retryable
flag. Tokens and full connection details are redacted from diagnostic errors.

### Read-only protections

The query client accepts only a single `SELECT`, `WITH`, `DESCRIBE`, `SHOW`,
`EXPLAIN` or `USE` statement. Write and administrative operations are rejected
before they reach Databricks. Returned results are capped using
`DATABRICKS_MAX_ROWS`.

### Profile-informed SQL generation

Free-text analytical questions are grounded in the dataset selected in the
browser. AvTrix sends the local model:

- the live table reference, schema fingerprint, column names and Databricks
  types;
- a compact subset of relevant statistics from the matching cached profile,
  when one exists; and
- bounded SQL rules requiring exact quoted source-column names.

A profile is used only when its dataset reference and schema fingerprint match
the live table. Sensitive-looking representative values remain suppressed. If
there is no matching profile, AvTrix uses the live schema alone.

Before execution, generated SQL is checked for read-only safety, the active
dataset and obvious invented quoted identifiers. If local validation or
Databricks reports a repairable SQL error, AvTrix gives the model the actual
evidence and allows one correction. It does not loop, and it does not treat
authentication or timeout failures as SQL problems.

The Sources tab records which dataset and schema fingerprint were used, whether
a cached profile contributed context, whether SQL came from the local model or
a deterministic template, and whether the one correction was needed.

Legacy named shortcuts are optional table-specific analysis packs. The browser
hides them when their required columns are missing and blocks stale calls before
they reach Databricks.

### Schema-grounded analytical plans

AvTrix resolves several common question shapes deterministically before using
the local model:

- categorical distributions: `distribution of <category> by <group>`;
- temporal trends: `yearly distribution of <category>`, `<category> by month`,
  or a record-count trend; and
- rankings and comparisons: `top 10 <dimension> by total <measure>` or
  `compare average <measure> across <dimension>`.

The requested phrases are matched against the selected dataset's live names,
types and comments. Temporal questions use a live date/time field; when two
fields are equally plausible, AvTrix asks which one to use. Sum, average,
minimum and maximum require a numeric field or a profile showing that the text
field is consistently numeric-like. These plans generate bounded, read-only SQL
and evidence-led summaries without asking the model to invent a query.

Use `PHASE5_ACCEPTANCE.md` for the three-dataset milestone test after deployment.

### Run the connector tests

From the `avtrix_analyst` folder:

```bash
python3 -m unittest discover -s tests -v
```

These tests do not require Databricks credentials. They cover read-only SQL
validation, result limits, timeout handling, credential redaction, and the
single reconnect attempt for an expired session.

# Phase 7 Acceptance — Operational Release Candidate

Run this after deploying the Version 1 release candidate to the Mac. Complete
the Phase 5 and Phase 6 acceptance sheets first; operational features should not
hide unresolved analytical or integrity problems.

## 1. One-click integrity workflow

- Select each of the three acceptance datasets.
- Confirm the Integrity review card shows the correct per-dataset last-check
  state.
- Select **Run review** and confirm the button is disabled while the request is
  active.
- Confirm the completed scorecard is recorded as `interactive` and the context
  card refreshes.
- Switch datasets and confirm their histories do not leak into each other.

## 2. Local history privacy and retention

- Inspect `.avtrix_state/integrity_history.json`.
- Confirm it contains dataset references, schema fingerprints, statuses and the
  six scorecard rows only.
- Confirm it contains no detailed evidence rows, sampled values, Databricks
  token, hostname, HTTP path or complete connection string.
- Temporarily set a low entry limit in a test copy and confirm older entries are
  pruned. Restore the intended setting afterwards.

## 3. Methodology locking

- Run one deterministic analysis and select **Lock methodology**.
- Confirm a JSON file appears in `.avtrix_state/methodologies/`.
- Confirm it contains the question, active dataset, schema fingerprint,
  provenance and read-only SQL, with `result_rows_stored: false`.
- Switch to another dataset before locking an older response and confirm the
  lock is rejected as stale.
- Confirm write SQL cannot be saved through the methodology endpoint.

## 4. Manual report export

- Export an analytical response and an integrity response.
- Open both Markdown files and confirm the narrative, dataset, table evidence
  and read-only SQL are readable.
- Confirm the integrity report includes all available evidence sections.
- Confirm no report file is silently created on the server when Export is not
  selected.

## 5. Scheduler safety

- Leave `AVTRIX_SCHEDULER_ENABLED=false` for the initial deployment and confirm
  application status reports scheduling disabled.
- In a controlled test window, copy `scheduler_config.json.example` to
  `scheduler_config.json`, use one test table and enable both the environment
  flag and file setting.
- Confirm only the allowlisted table runs and its history origin is `scheduled`.
- Confirm `run_on_start: false` does not issue a query immediately at launch.
- Return scheduling to disabled after the test unless continuous monitoring is
  intentionally approved.

## 6. Regression and security

- Run the full offline test suite.
- Confirm dataset discovery, profiling, analytical plans, integrity tabs, Stop,
  exports and methodology buttons work in both Focused and Analyst views.
- Confirm `.env`, `.avtrix_profiles/`, `.avtrix_state/`, `integrity_config.json`
  and `scheduler_config.json` are absent from the release archive.
- Confirm Databricks remains read-only throughout the acceptance run.

## Release decision

Version 1 is accepted when the three-dataset analytical/integrity tests pass,
local operational records contain no raw result rows, stale methodology locks
are rejected, manual exports are complete and the scheduler remains explicit
dual opt-in.

Accepted by: ____________________  Date: ____________________


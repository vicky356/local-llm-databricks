"""Opt-in background scheduling for the AvTrix integrity review.

Scheduling is disabled unless both the environment flag and the JSON config
enable it. The scheduler accepts an injected audit callable so it contains no
Databricks credentials and performs no writes to source datasets.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
import logging
from pathlib import Path
import threading
from typing import Callable, Optional


LOGGER = logging.getLogger(__name__)


@dataclass(frozen=True)
class SchedulerConfig:
    enabled: bool = False
    interval_minutes: int = 1440
    run_on_start: bool = False
    tables: tuple[str, ...] = ()


def load_scheduler_config(path: Path | str, *, environment_enabled: bool = False) -> tuple[SchedulerConfig, Optional[str]]:
    config_path = Path(path)
    if not config_path.exists():
        return SchedulerConfig(), None
    try:
        payload = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return SchedulerConfig(), f"Scheduler configuration could not be read: {exc}"
    if not isinstance(payload, dict):
        return SchedulerConfig(), "Scheduler configuration must be a JSON object."
    tables = tuple(
        str(table).strip() for table in (payload.get("tables") or [])
        if isinstance(table, str) and len(table.strip().split(".")) == 3
    )
    interval = max(15, int(payload.get("interval_minutes") or 1440))
    file_enabled = bool(payload.get("enabled", False))
    return SchedulerConfig(
        enabled=bool(environment_enabled and file_enabled and tables),
        interval_minutes=interval,
        run_on_start=bool(payload.get("run_on_start", False)),
        tables=tables,
    ), None


class IntegrityScheduler:
    """A small daemon loop with explicit dual opt-in and an allowlisted table set."""

    def __init__(self, config: SchedulerConfig, audit: Callable[[str], None]) -> None:
        self.config = config
        self.audit = audit
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.RLock()
        self.last_run: Optional[str] = None
        self.last_error: Optional[str] = None

    def run_once(self) -> None:
        from datetime import datetime, timezone

        errors = []
        for table in self.config.tables:
            try:
                self.audit(table)
            except Exception as exc:  # logged locally; credentials should never be present
                LOGGER.exception("Scheduled integrity review failed for %s", table)
                errors.append(f"{table}: {exc}")
        with self._lock:
            self.last_run = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
            self.last_error = "; ".join(errors)[:2000] if errors else None

    def _loop(self) -> None:
        if self.config.run_on_start and not self._stop.is_set():
            self.run_once()
        wait_seconds = self.config.interval_minutes * 60
        while not self._stop.wait(wait_seconds):
            self.run_once()

    def start(self) -> bool:
        if not self.config.enabled:
            return False
        with self._lock:
            if self._thread and self._thread.is_alive():
                return True
            self._thread = threading.Thread(target=self._loop, name="avtrix-integrity-scheduler", daemon=True)
            self._thread.start()
        return True

    def stop(self) -> None:
        self._stop.set()

    def status(self) -> dict:
        with self._lock:
            return {
                "enabled": self.config.enabled,
                "running": bool(self._thread and self._thread.is_alive()),
                "interval_minutes": self.config.interval_minutes,
                "table_count": len(self.config.tables),
                "run_on_start": self.config.run_on_start,
                "last_run": self.last_run,
                "last_error": self.last_error,
            }


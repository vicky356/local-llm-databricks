"""
AvTrix Fleet Intelligence — Browser Chat Interface
===================================================
A local web app replacing Databricks Genie.
Two modes: Focused (clean chat) and Analyst (split canvas).
Intent router: answers meta/domain/schema questions directly,
SQL questions via Ollama, all without leaving your browser.

Usage:
    python3 web_analyst.py

Then open: http://localhost:5000
"""

import os
import sys
import json
import logging
import re
import threading
import webbrowser
from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv

load_dotenv(Path(__file__).parent / ".env")

DATABRICKS_HOST      = os.getenv("DATABRICKS_HOST", "")
DATABRICKS_HTTP_PATH = os.getenv("DATABRICKS_HTTP_PATH", "")
DATABRICKS_TOKEN     = os.getenv("DATABRICKS_TOKEN", "")
OLLAMA_MODEL         = os.getenv("OLLAMA_MODEL", "ministral-3:8b")
HISTORY_TABLE        = os.getenv("HISTORY_TABLE", "poc.avtrix_fb.alg_history_report")
OLLAMA_BASE_URL      = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
DATABRICKS_QUERY_TIMEOUT_SECONDS = float(os.getenv("DATABRICKS_QUERY_TIMEOUT_SECONDS", "60"))
DATABRICKS_MAX_ROWS  = int(os.getenv("DATABRICKS_MAX_ROWS", "500"))
DATABRICKS_SESSION_RETRIES = int(os.getenv("DATABRICKS_SESSION_RETRIES", "1"))
PROFILE_DIR          = Path(os.getenv("AVTRIX_PROFILE_DIR", str(Path(__file__).parent / ".avtrix_profiles")))
PROFILE_COLUMNS_PER_QUERY = int(os.getenv("AVTRIX_PROFILE_COLUMNS_PER_QUERY", "16"))
PROFILE_LOW_CARDINALITY = int(os.getenv("AVTRIX_PROFILE_LOW_CARDINALITY", "20"))
PROFILE_MAX_VALUES   = int(os.getenv("AVTRIX_PROFILE_MAX_VALUES", "10"))
PROFILE_MAX_VALUE_COLUMNS = int(os.getenv("AVTRIX_PROFILE_MAX_VALUE_COLUMNS", "25"))
PROFILE_SAMPLE_VALUES = os.getenv("AVTRIX_PROFILE_SAMPLE_VALUES", "true").strip().lower() in {
    "1", "true", "yes", "on",
}
INTEGRITY_CONFIG_PATH = Path(os.getenv(
    "AVTRIX_INTEGRITY_CONFIG",
    str(Path(__file__).parent / "integrity_config.json"),
))
STATE_DIR             = Path(os.getenv("AVTRIX_STATE_DIR", str(Path(__file__).parent / ".avtrix_state")))
HISTORY_RETENTION_DAYS = int(os.getenv("AVTRIX_HISTORY_RETENTION_DAYS", "90"))
HISTORY_MAX_ENTRIES   = int(os.getenv("AVTRIX_HISTORY_MAX_ENTRIES", "500"))
SCHEDULER_CONFIG_PATH = Path(os.getenv(
    "AVTRIX_SCHEDULER_CONFIG",
    str(Path(__file__).parent / "scheduler_config.json"),
))
SCHEDULER_ENV_ENABLED = os.getenv("AVTRIX_SCHEDULER_ENABLED", "false").strip().lower() in {
    "1", "true", "yes", "on",
}

# ── Import shared components from CLI tool ───────────────────────────────────
from avtrix_analyst import (
    NAMED_QUERIES, _match_shortcut_by_intent,
    UNIVERSAL_GUARDRAILS,
    build_completeness_sql, format_completeness_rows,
    list_installed_models, set_model,
)
from databricks_client import DatabricksQueryClient, QueryError
from dataset_registry import DatasetDiscoveryService, DatasetRegistry
from dataset_profiler import (
    DatasetProfiler, ProfileStore, ProfilerConfig, profile_summary,
)
from visual_story import summarise_reason_by_jobtype, build_reason_jobtype_story_chart
from semantic_layer import (
    parse_distribution_request,
    parse_temporal_request,
    parse_ranking_request,
    resolve_column,
    resolve_temporal_column,
    build_grouped_distribution_sql,
    build_temporal_distribution_sql,
    build_ranking_sql,
)
from query_reasoning import (
    build_reasoning_context,
    is_repairable_sql_error,
    missing_shortcut_columns,
    validate_generated_sql,
)
from integrity_framework import (
    build_consistency_sql,
    build_date_coverage_sql,
    build_integrity_plan,
    build_monotonicity_sql,
    build_uniqueness_sql,
    load_integrity_overrides,
)
from operational_store import OperationalStore
from integrity_scheduler import IntegrityScheduler, load_scheduler_config

# ── Flask ─────────────────────────────────────────────────────────────────────
try:
    from flask import Flask, request, jsonify
except ImportError:
    print("Flask not found. Run: pip3 install flask")
    sys.exit(1)

app = Flask(__name__)
app.secret_key = "avtrix-local-only"

logging.basicConfig(
    level=os.getenv("AVTRIX_LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)

conversation_history = []
discovered_tables = []   # populated at startup
last_query_context = {"shortcut": None, "question": None}
last_query_context_lock = threading.RLock()

# ── Databricks ────────────────────────────────────────────────────────────────
db_client = DatabricksQueryClient(
    DATABRICKS_HOST,
    DATABRICKS_HTTP_PATH,
    DATABRICKS_TOKEN,
    max_rows=DATABRICKS_MAX_ROWS,
    query_timeout_seconds=DATABRICKS_QUERY_TIMEOUT_SECONDS,
    session_retries=DATABRICKS_SESSION_RETRIES,
)
dataset_registry = DatasetRegistry(HISTORY_TABLE)
dataset_discovery = DatasetDiscoveryService(db_client)
dataset_profiler = DatasetProfiler(
    db_client,
    ProfileStore(PROFILE_DIR),
    ProfilerConfig(
        columns_per_query=PROFILE_COLUMNS_PER_QUERY,
        low_cardinality_threshold=PROFILE_LOW_CARDINALITY,
        max_representative_values=PROFILE_MAX_VALUES,
        max_value_columns=PROFILE_MAX_VALUE_COLUMNS,
        sample_values_enabled=PROFILE_SAMPLE_VALUES,
    ),
)
operational_store = OperationalStore(
    STATE_DIR,
    retention_days=HISTORY_RETENTION_DAYS,
    max_history_entries=HISTORY_MAX_ENTRIES,
)
scheduler_config, scheduler_config_error = load_scheduler_config(
    SCHEDULER_CONFIG_PATH,
    environment_enabled=SCHEDULER_ENV_ENABLED,
)
integrity_scheduler = None


def active_table():
    return dataset_registry.get().table_ref


def _error_payload(error):
    if isinstance(error, QueryError):
        return error.to_dict()
    if isinstance(error, dict):
        return error
    if error:
        return {"category": "application", "message": str(error), "retryable": False}
    return None


def _error_text(error):
    payload = _error_payload(error)
    if not payload:
        return "Unknown error."
    detail = payload.get("detail")
    return f"{payload['message']} {detail}".strip() if detail else payload["message"]


def run_sql(sql_query, table_ref=None):
    outcome = db_client.execute(sql_query, table_ref=table_ref or active_table())
    if not outcome.ok:
        return None, None, outcome.error
    return outcome.columns, outcome.rows, None


def discover_tables():
    """Discover tables using an isolated managed connection."""
    global discovered_tables
    current = dataset_registry.get()
    described = dataset_discovery.describe_table(current.table_ref)
    if described.ok:
        dataset_registry.activate(described.value)

    outcome = dataset_discovery.list_tables(current.catalog, current.schema)
    if outcome.ok:
        discovered_tables = [item["table_ref"] for item in outcome.value]
    if not discovered_tables:
        discovered_tables = [current.table_ref]


# ── Ollama ────────────────────────────────────────────────────────────────────
def call_ollama(prompt, system_prompt=None, timeout=120):
    try:
        import urllib.request
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        payload = json.dumps({
            "model": OLLAMA_MODEL,
            "messages": messages,
            "stream": False,
        }).encode()

        req = urllib.request.Request(
            f"{OLLAMA_BASE_URL}/api/chat",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read())
            return data["message"]["content"].strip(), None
    except Exception as e:
        return None, str(e)


def check_ollama():
    try:
        import urllib.request
        req = urllib.request.Request(f"{OLLAMA_BASE_URL}/api/tags", method="GET")
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
            models = [m["name"] for m in data.get("models", [])]
            return True, models
    except Exception as e:
        return False, str(e)


# ── Intent Router ─────────────────────────────────────────────────────────────
PROFILE_PATTERNS = [
    r"\b(profile|profiling)\b.{0,25}\b(active\s+)?(table|data|dataset)\b",
    r"\b(statistical|structural)\s+profile\b",
    r"\b(show|build|generate|refresh|create|run)\b.{0,20}\bprofile\b",
]


def _is_profile_question(question):
    q = (question or "").lower()
    return any(re.search(pattern, q) for pattern in PROFILE_PATTERNS)


INTEGRITY_PATTERNS = [
    r"\bdata\s+(integrity|quality)\b",
    r"\bintegrity\s+check\b",
    r"\b(completeness|fill rate|null count|null rate)\b",
    r"\b(profile|audit)\b.{0,20}\b(table|data|dataset|fields?|columns?)\b",
    r"\bcheck\b.{0,25}\b(null|placeholder|missing|completeness|fields?|columns?|quality|integrity)\b",
    r"\bwere\s+null(s| values)?\b",
    r"\bplaceholders?\b.{0,20}\b(taken|considered|handled|checked)\b",
]


def _is_integrity_question(question):
    q = (question or "").lower()
    return any(re.search(p, q) for p in INTEGRITY_PATTERNS)


META_PATTERNS = [
    r"\b(what|which|list|show)\b.{0,30}\b(table|tables|schema|catalog|dataset|data)\b",
    r"\b(what data|what tables|what can you|what do you have)\b",
    r"\bdo you have access\b",
    r"\b(available|accessible)\b.{0,20}\b(table|data|schema)\b",
    r"\bshow.{0,10}tables?\b",
    r"\blist.{0,10}tables?\b",
    r"\bwhat.{0,15}(columns?|fields?)\b",
    r"\bdescribe.{0,20}(table|schema|data)\b",
    r"\bschema\b",
    r"\bcolumns?.{0,20}\b(in|of|for)\b",
]

DOMAIN_PATTERNS = [
    r"\b(what(?:'s|s|\s+is)|explain|define|tell me about|how does|why)\b",
    r"\b(mtbur|mtbf|reliability|removal|lru|ata chapter|jobtype)\b.{0,30}\b(mean|definition|explain|why)\b",
    r"\bwhat does.{0,30}mean\b",
    r"\badvice\b|\brecommend\b|\bshould i\b|\bwhat should\b",
    r"\binterpret\b|\bsummarise\b|\bsummarize\b",
    r"\bcontext\b.{0,20}\b(for|of|behind)\b",
]

# Signals that the user is asking for values from the active dataset. These
# take precedence over a conversational opener such as "what's"; otherwise a
# question like "what's the spread across jobtype?" is incorrectly answered as
# generic domain knowledge without querying Databricks.
ANALYTICAL_SIGNALS = re.compile(
    r"\b(spread|distribution|breakdown|mix|count|how many|number of|top|bottom|"
    r"most|least|highest|lowest|average|avg|sum|total|percentage|percent|rate|"
    r"trend|compare|comparison|rank|ranking|group(ed)? by|per)\b",
    re.I,
)


def _is_guardrails_question(question):
    q = (question or "").lower()
    return bool(re.search(r"\bguardrails?\b|\bmethodolog|how.{0,20}\binvoke\b.{0,20}\bguardrail", q))


def _is_capabilities_question(question):
    q = (question or "").lower()
    return bool(re.search(
        r"\bwhat can you do\b|\bwhat are your capabilities\b|\b(show|list|explain)\b.{0,15}\bcapabilit|"
        r"\bwhat options (do you offer|are there)\b|\bhelp me understand what you can do\b",
        q,
    ))


def _is_data_availability_question(question):
    """Recognise requests for available data rather than assistant features."""
    q = (question or "").lower()
    return bool(re.search(
        r"\bwhat (data|datasets?|tables?) (is|are|do you have)\b.{0,20}\b(available|access|have)?\b|"
        r"\b(show|list)\b.{0,15}\bavailable (data|datasets?|tables?)\b|"
        r"\bwhat data do you have\b",
        q,
    ))


def _is_multi_dataset_overview(question):
    """True when the user asks for a portfolio summary, not one table."""
    q = (question or "").lower()
    return bool(
        re.search(
            r"\b(summary|summarise|summarize|overview)\b.{0,35}\b(all\s+)?(datasets|tables)\b",
            q,
        )
        or re.search(
            r"\b(all\s+)?(datasets|tables)\b.{0,35}\b(summary|summarise|summarize|overview)\b",
            q,
        )
    )


def _is_contextual_repeat(question):
    """Recognise a follow-up that refers to the last trusted query."""
    q = (question or "").lower()
    return bool(re.search(
        r"\b(same|previous|last|that)\b.{0,35}\b(distribution|breakdown|spread|result|query)\b|"
        r"\b(show|include|add)\b.{0,20}\b(null|missing|blank)\b.{0,20}\b(same|previous|last|that)?\b",
        q,
    ))


def _is_ambiguous_year_type_question(question):
    """Catch 'year type' before the model invents a meaning or invalid SQL."""
    q = (question or "").lower()
    return bool(re.search(r"\byear\s*type\b", q)) and not bool(
        re.search(r"\b(job\s*type|jobtype|component\s*type|aircraft\s*type)\b", q)
    )


def answer_year_type_clarification() -> dict:
    return {
        "type": "clarification",
        "answer": (
            "I’m not sure what **year type** refers to in this dataset. Choose the dimension "
            "you want plotted by year: **job type**, **component type**, or **aircraft type**. "
            "For example: “show me a yearly distribution of job types.”"
        ),
        "sql": None,
        "columns": None,
        "rows": None,
    }


def _is_reliability_glossary_question(question):
    """Detect the recurring multi-topic reliability/status/utilisation explainer."""
    q = (question or "").lower()
    topic_hits = sum([
        bool(re.search(r"\breliabilit(y|ies)\b", q)),
        bool(re.search(r"\b(tsi|tsn|tso)\b", q)),
        bool(re.search(r"\b(aircraft|fleet)\s+utili[sz]ation\b", q)),
    ])
    return topic_hits >= 2


def answer_reliability_glossary() -> dict:
    """A deterministic, context-safe knowledge card for common status terms."""
    answer = """## Reliability

Reliability is the probability that an aircraft, system or component performs its required function **without failure**, for a defined period or operating exposure, under stated conditions.

Common measures include:

- **MTBF:** mean operating time between confirmed failures.
- **MTBUR:** mean operating time between unscheduled removals. A removal is not automatically a confirmed failure, so this is not identical to MTBF.
- **Removal or defect rate:** events per defined exposure, such as 1,000 flight hours or 100 cycles.
- **Dispatch reliability:** the proportion of planned departures completed without a defined technical delay or cancellation.

A reliability figure is only meaningful when its event definition, population, exposure and reporting period are stated.

## TSI, TSN and TSO

In component and maintenance-status records, these usually describe accumulated time:

| Term | Usual maintenance meaning | Practical interpretation |
|---|---|---|
| TSI | Time Since Installation | Time accumulated since the item was installed in its current aircraft or position. Reinstallation starts a new installation interval; it does not erase the item’s life history. |
| TSN | Time Since New | Total time accumulated since manufacture or entry into service as new. It normally continues throughout the item’s life. |
| TSO | Time Since Overhaul | Time accumulated since the last qualifying overhaul. The overhaul status must be supported by approved records. |

**Context matters:** in certification material, TSO can instead mean **Technical Standard Order**—an FAA minimum-performance standard for an article. That is unrelated to the “time since overhaul” usage. If a field name is ambiguous, confirm it from the operator’s data dictionary or maintenance records.

## Aircraft utilization

Aircraft utilization is the rate at which an aircraft accumulates operational exposure over a stated period. It is commonly expressed as:

- flight hours per day, month or year;
- flight cycles or departures per day, month or year; or
- block hours per period, where block time is the operator’s chosen measure.

For example, 300 flight hours and 120 cycles over 30 days equal **10 flight hours per day** and **4 cycles per day**.

## How they fit together

Utilization provides the exposure used to calculate reliability and forecast maintenance. TSN, TSO and TSI describe where an aircraft or component sits on different maintenance clocks; reliability measures what happened during that exposure."""
    return {
        "type": "domain",
        "answer": answer,
        "sql": None,
        "columns": None,
        "rows": None,
    }


def answer_guardrails() -> dict:
    """Explain how the guardrails are invoked and show both layers."""
    answer = (
        "**How the guardrails are invoked:** automatically. Every SQL question is given these "
        "rules in the model's system prompt — you don't call them, they're always on.\n\n"
        "They're split into two layers so they stay correct across different tables:\n\n"
        "**1. Universal methodology (applies to ANY table):**\n"
        f"{UNIVERSAL_GUARDRAILS}\n\n"
        "**2. Per-table methodology (only valid for a table with these columns):**\n"
        f"Active table: `{active_table()}`\n"
        "The reliability-specific rules (True Reliability filter, MTBUR, same-serial exclusion) "
        "ONLY apply when the table actually has REASON / removal-hours columns. On a different "
        "table — e.g. a utilisation table with Cum_Hours / ENG1-4 columns — those rules are NOT "
        "applied; the model is given that table's real columns instead."
    )
    return {"type": "domain", "answer": answer, "sql": None, "columns": None, "rows": None}


def answer_capabilities() -> dict:
    """Describe everything the assistant can do."""
    answer = (
        "**What I can do** — ask in plain English and I route automatically:\n\n"
        "- **Analytics** — generate & run Databricks SQL (\"which aircraft have the most removals?\")\n"
        "- **Dataset profile** — record counts, missingness, ranges, roles and candidate keys "
        "for any selected dataset (\"profile the active dataset\")\n"
        "- **Data integrity check** — six-part schema-agnostic integrity review of any table "
        "(\"run a data integrity check\")\n"
        "- **Overview** — fingerprinted structural and statistical summary of the active dataset "
        "(\"general overview\")\n"
        "- **Schema** — columns/tables from metadata, no SQL (\"what columns do you have?\")\n"
        "- **Knowledge** — aviation/reliability expertise, no SQL (\"what is MTBUR?\")\n"
        "- **Charts** — re-render the last result as pie/bar/line (\"show that as percentages\")\n\n"
        f"Active table: `{active_table()}` · Model: `{OLLAMA_MODEL}` "
        "(switch it in the sidebar). Ask \"what guardrails do you apply?\" to see the methodology."
    )
    return {"type": "meta", "answer": answer, "sql": None, "columns": None, "rows": None}


def _dataset_theme(table_ref: str) -> str:
    """Conservative table-name classification; labels are explicitly indicative."""
    name = table_ref.rsplit(".", 1)[-1].lower()
    if "mtbur" in name:
        return "Reliability / MTBUR"
    if "compliance" in name:
        return "Maintenance compliance"
    if "discrepancy" in name:
        return "Discrepancy history"
    if "installed" in name and "component" in name:
        return "Installed components"
    if "utilization" in name:
        return "Fleet utilisation"
    if "history" in name:
        return "Maintenance history"
    return "Other / requires profiling"


def answer_dataset_portfolio() -> dict:
    """Summarise discovered datasets without model generation or data scans."""
    tables = list(discovered_tables)
    current = dataset_registry.get()
    if not tables:
        tables = [current.table_ref]

    theme_counts = {}
    rows = []
    for table_ref in tables:
        theme = _dataset_theme(table_ref)
        theme_counts[theme] = theme_counts.get(theme, 0) + 1
        is_active = table_ref == current.table_ref
        rows.append([
            table_ref,
            theme,
            "Active" if is_active else "Available",
            len(current.columns) if is_active else None,
        ])

    coverage = ", ".join(
        f"{theme}: {count}" for theme, count in sorted(theme_counts.items())
    )
    answer = (
        f"**Dataset portfolio — {len(tables)} discovered table(s)**\n\n"
        f"- **Active dataset:** `{current.table_ref}`\n"
        f"- **Live active schema:** {len(current.columns)} columns\n"
        f"- **Indicative coverage from table names:** {coverage}\n\n"
        "The table below is a discovery summary, not a claim about data quality or content. "
        "Select and profile a dataset to get verified record counts, date ranges, missingness, "
        "field roles and candidate identifiers."
    )
    return {
        "type": "overview",
        "answer": answer,
        "sql": None,
        "columns": ["dataset", "indicative coverage", "status", "live columns"],
        "rows": rows,
    }


def classify_intent(question: str) -> str:
    """
    Returns one of: 'meta' | 'domain' | 'analytical'
    - meta:       questions about the data structure itself (what tables, what columns)
    - domain:     aviation/reliability knowledge questions (no SQL needed)
    - analytical: questions requiring a Databricks query
    """
    q = question.lower().strip()

    for pat in META_PATTERNS:
        if re.search(pat, q):
            return "meta"

    if ANALYTICAL_SIGNALS.search(q):
        return "analytical"

    for pat in DOMAIN_PATTERNS:
        if re.search(pat, q):
            return "domain"

    return "analytical"


# ── Response generators ───────────────────────────────────────────────────────
def answer_meta(question: str) -> dict:
    """Answer schema/catalog discovery questions directly from Databricks metadata."""
    q = question.lower()

    # Table listing request
    if any(w in q for w in ["table", "tables", "catalog", "dataset", "access"]):
        current_table = active_table()
        if discovered_tables:
            parts = current_table.split(".")
            catalog = parts[0] if len(parts) == 3 else "N/A"
            schema  = parts[1] if len(parts) == 3 else "N/A"
            table_list = "\n".join(f"  • {t}" for t in discovered_tables)
            answer = (
                f"You have access to **{len(discovered_tables)} table(s)** "
                f"in catalog `{catalog}`, schema `{schema}`:\n\n{table_list}\n\n"
                f"The active table for queries is `{current_table}`. "
                f"Ask me to analyse any of these tables by name."
            )
        else:
            answer = (
                f"The configured table is `{current_table}`. "
                "I couldn't enumerate additional tables — check your Databricks credentials."
            )
        return {"type": "meta", "answer": answer, "sql": None, "columns": None, "rows": None}

    # Column/schema request
    if any(w in q for w in ["column", "columns", "fields", "schema", "describe"]):
        current = dataset_registry.get()
        if current.columns:
            schema_text = "\n".join(
                f"- `{column.name}` — {column.data_type}"
                + (f" — {column.comment}" if column.comment else "")
                for column in current.columns
            )
        else:
            schema_text = "Live column metadata is not available. Refresh discovery and try again."
        answer = f"Here are the live columns in `{current.table_ref}`:\n\n{schema_text}"
        return {"type": "meta", "answer": answer, "sql": None, "columns": None, "rows": None}

    # Fallback
    return {"type": "meta", "answer": f"I have access to `{active_table()}`. Ask me to describe its columns or list available tables.", "sql": None, "columns": None, "rows": None}


def answer_domain(question: str) -> dict:
    """Answer aviation/reliability domain questions using Ollama without SQL."""
    system = (
        "You are an aviation reliability and maintenance analytics expert with deep knowledge "
        "of MRO (Maintenance, Repair & Overhaul), component reliability analysis, MTBUR (Mean "
        "Time Between Unscheduled Removals), ATA chapters, LRU (Line Replaceable Units), "
        "Airworthiness Directives, and fleet management. "
        "Answer concisely and accurately. Lead with the direct answer, then organise separate "
        "topics under short Markdown ## headings. Use short paragraphs for explanations and bullets "
        "only for genuine lists; do not put a dash before every sentence. Use bold sparingly for "
        "key terms or figures only—never bold a whole heading, paragraph or bullet. Use a compact "
        "Markdown table only when it makes a comparison clearer. Do not emit backslash line breaks. "
        "Never invent an acronym expansion. In maintenance-status context, TSI usually means Time "
        "Since Installation, TSN means Time Since New, and TSO usually means Time Since Overhaul. "
        "In certification context, FAA TSO means Technical Standard Order; explicitly distinguish "
        "the two meanings. MTBF is used in aviation, and a removal is not automatically a confirmed "
        "failure. Aircraft utilisation is operational exposure (typically hours, cycles, departures "
        "or block hours per period); turnaround time is an influence, not itself a utilisation rate. "
        "If terminology remains ambiguous, say what context must be confirmed. "
        "If the question relates to the AvTrix fleet data system, mention that you can run "
        "queries against the Databricks table for specific numbers."
    )
    answer, err = call_ollama(question, system_prompt=system)
    if err:
        return {"type": "domain", "answer": f"Ollama is not reachable: {err}", "sql": None, "columns": None, "rows": None}
    return {"type": "domain", "answer": answer, "sql": None, "columns": None, "rows": None}


def _matching_profile(metadata):
    """Return only a cache entry that matches this exact schema fingerprint."""
    if not metadata or not metadata.columns or metadata.schema_fingerprint == "pending":
        return None
    try:
        return dataset_profiler.get_cached(metadata)
    except OSError:
        return None


def _query_provenance(
    metadata,
    profile,
    *,
    sql_source: str,
    repair_attempted: bool = False,
    repair_succeeded: bool = False,
):
    return {
        "dataset": metadata.table_ref if metadata else active_table(),
        "schema_fingerprint": metadata.schema_fingerprint if metadata else None,
        "profile_used": bool(profile),
        "profile_generated_at": profile.get("generated_at") if profile else None,
        "sql_source": sql_source,
        "repair_attempted": bool(repair_attempted),
        "repair_succeeded": bool(repair_succeeded),
    }


def _metadata_for_query(table_ref=None, metadata=None):
    if metadata is not None:
        return metadata
    current = dataset_registry.get()
    if not table_ref or current.table_ref == table_ref:
        return current
    return None


def nl_to_sql(question: str, table_ref: str = None, metadata=None, repair_context=None):
    """Generate SQL from live schema plus the matching cached profile."""
    metadata = _metadata_for_query(table_ref, metadata)
    if metadata is None or not metadata.columns:
        return None, "Live column metadata is unavailable for the selected dataset."
    current_table = table_ref or metadata.table_ref
    profile = _matching_profile(metadata)
    schema_context = build_reasoning_context(metadata, profile, question)
    repair_instruction = ""
    if repair_context:
        previous_sql = str(repair_context.get("sql") or "")[:6000]
        error_text = str(repair_context.get("error") or "")[:2000]
        repair_instruction = f"""

ONE CORRECTION ATTEMPT:
The previous SQL was rejected or failed local schema validation.
Previous SQL:
{previous_sql}

Evidence from validation/Databricks:
{error_text}

Correct the query using only the live physical columns above. Do not repeat the same error.
"""
    table_info = f"""
{schema_context}

RULES FOR THIS QUERY:
- Always reference the active dataset exactly as: {current_table}
- Every physical source column must use its exact live name inside backticks
- Aliases may be unquoted, but must not be presented as physical source columns
- Never invent a column, table, relationship, business definition or filter value
- Prefer a flat grouped query or a clearly staged CTE; every non-aggregated selected field must be grouped
- Treat profile statistics as context, not as query results
- Use LIMIT 500 unless the user asks for more
- Return ONLY the SQL query — no explanation, no markdown fences, no commentary
{repair_instruction}
"""
    prompt = f"{table_info}\n\nQuestion: {question}\n\nSQL:"
    system = (
        "You are a careful Databricks SQL analyst working against an unfamiliar dataset. "
        "Generate valid Spark SQL only. No markdown. No explanation. Just the SQL. "
        "The live schema in the prompt is authoritative. Never rely on a memorised table. "
        "Never write a query that JOINs an aggregate CTE back to the base table — "
        "use a single flat SELECT with all aggregates instead."
    )
    sql, err = call_ollama(prompt, system_prompt=system)
    if err:
        return None, err
    # Clean up any accidental markdown fences
    sql = re.sub(r"```sql|```", "", sql).strip()
    return sql, None


RESULT_INTERPRETATION_SYSTEM = (
    "You are a careful aviation data analyst. Interpret only facts explicitly present in the "
    "query result. Distinguish record counts, event counts and distinct-entity counts. Do not "
    "infer causes, failure rates, maintenance programme maturity, regulatory drivers, predictive "
    "maintenance, criticality, fleet risk or operational impact unless the result directly proves "
    "the claim. Never turn a possible explanation into a finding. If useful, label one hypothesis "
    "as a suggested next check. Quote exact values and acknowledge missing categories."
)


def interpret_results(question: str, columns: list, rows: list) -> str:
    """Ask Ollama to interpret query results in plain English."""
    if not rows:
        return "The query returned no rows."
    preview_rows = rows[:20]
    table_text = " | ".join(columns) + "\n"
    table_text += "\n".join(" | ".join(str(v) for v in row) for row in preview_rows)
    if len(rows) > 20:
        table_text += f"\n... ({len(rows) - 20} more rows)"

    prompt = (
        f"Question: {question}\n\n"
        f"Query results:\n{table_text}\n\n"
        "Write 2-4 concise sentences. Start with what the returned numbers show. State what cannot "
        "be concluded if the question invites a causal or reliability claim. End with at most one "
        "clearly labelled suggested next check."
    )
    interpretation, _ = call_ollama(
        prompt,
        system_prompt=RESULT_INTERPRETATION_SYSTEM,
        timeout=60,
    )
    return interpretation or "Results retrieved — see table below."


def _rows_as_dicts(columns: list, rows: list) -> list[dict]:
    return [dict(zip(columns, row)) for row in rows]


def summarise_jobtype_distribution(columns: list, rows: list) -> str:
    """Deterministic summary: never infer failure rates from record counts."""
    records = _rows_as_dicts(columns, rows)
    total = sum(int(item.get("record_count") or 0) for item in records)
    if not records or total == 0:
        return "No JOBTYPE records were returned."
    details = []
    for item in records:
        label = str(item.get("job_type") or "(Missing)")
        count = int(item.get("record_count") or 0)
        pct = item.get("pct_of_total")
        pct_text = f"{float(pct):.1f}%" if pct is not None else f"{count * 100.0 / total:.1f}%"
        details.append(f"**{label}**: {count:,} ({pct_text})")
    return (
        f"The dataset contains **{total:,} records** across {len(records)} JOBTYPE categories: "
        + "; ".join(details)
        + ". These are record proportions; they do not by themselves establish failure rates, "
          "maintenance effectiveness or the causes of unscheduled work."
    )


def summarise_jobtype_temporal(columns: list, rows: list) -> str:
    """Deterministic yearly summary with explicit missing-label visibility."""
    records = _rows_as_dicts(columns, rows)
    if not records:
        return (
            "No records contained a usable year in `REMOVAL_C_W_MOS`. "
            "Check the source date format before interpreting a yearly trend."
        )
    years = [int(item["year"]) for item in records if item.get("year") is not None]
    total = sum(int(item.get("total_records") or 0) for item in records)
    scheduled = sum(int(item.get("scheduled") or 0) for item in records)
    unscheduled = sum(int(item.get("unscheduled") or 0) for item in records)
    missing = sum(int(item.get("missing_jobtype") or 0) for item in records)
    other = sum(int(item.get("other_jobtype") or 0) for item in records)
    return (
        f"The yearly view covers **{min(years)}–{max(years)}** and **{total:,} records**: "
        f"**{scheduled:,} scheduled**, **{unscheduled:,} unscheduled**, "
        f"**{missing:,} missing JOBTYPE**, and **{other:,} other labels**. "
        "Use the chart to compare record volumes over time; the distribution alone does not prove "
        "a change in reliability or maintenance performance."
    )


def summarise_categorical_distribution(question: str, columns: list, rows: list):
    """Return a grounded summary for generic distribution questions.

    This works from the returned shape rather than any table-specific schema.
    It deliberately describes counts and shares only; causal interpretation is
    left to a separately requested analysis with supporting evidence.
    """
    if not re.search(r"\b(distribution|spread|breakdown|mix)\b", question or "", re.I):
        return None
    if not columns or not rows:
        return None

    label_idx = next((
        index for index in range(len(columns))
        if any(isinstance(row[index], str) for row in rows if len(row) > index and row[index] is not None)
    ), None)
    numeric_idxs = [
        index for index in range(len(columns))
        if any(isinstance(row[index], (int, float)) and not isinstance(row[index], bool)
               for row in rows if len(row) > index and row[index] is not None)
    ]
    if label_idx is None or not numeric_idxs:
        return None

    preferred = next((
        index for index in numeric_idxs
        if re.search(r"(^|_)(record|row|job|event|component)?_?count$|^count$|^total(_|$)",
                     columns[index], re.I)
        and not columns[index].lower().startswith("unique_")
    ), numeric_idxs[0])

    categories = []
    for row in rows:
        value = row[preferred] if len(row) > preferred else None
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            continue
        label = str(row[label_idx] if row[label_idx] not in (None, "") else "(Missing)")
        categories.append((label, float(value)))
    if not categories:
        return None

    total = sum(value for _, value in categories)
    ranked = sorted(categories, key=lambda item: item[1], reverse=True)
    details = []
    for label, value in ranked[:6]:
        display_value = f"{int(value):,}" if value.is_integer() else f"{value:,.2f}"
        share = f"{value * 100.0 / total:.1f}%" if total else "share unavailable"
        details.append(f"**{label}**: {display_value} ({share})")
    remainder = len(ranked) - len(details)
    remainder_text = f"; plus {remainder} smaller categories" if remainder > 0 else ""
    total_text = f"{int(total):,}" if total.is_integer() else f"{total:,.2f}"
    return (
        f"Based on `{columns[preferred]}`, the result contains **{total_text}** across "
        f"**{len(categories)} `{columns[label_idx]}` categories**: "
        + "; ".join(details)
        + remainder_text
        + ". The other measures are available in the table. These are returned counts and shares; "
          "they do not by themselves establish failure rates, causes, criticality or maintenance effectiveness."
    )


_OVERVIEW_SQL = """
    SELECT
        COUNT(*)                                                                    AS total_records,
        COUNT(DISTINCT AC_REG)                                                      AS unique_aircraft,
        COUNT(DISTINCT REMOVED_PARTNO)                                              AS unique_part_numbers,
        MIN(TRY_CAST(REMOVAL_C_W_MOS AS DATE))                                     AS earliest_removal,
        MAX(TRY_CAST(REMOVAL_C_W_MOS AS DATE))                                     AS latest_removal,
        COUNT(DISTINCT YEAR(TRY_CAST(REMOVAL_C_W_MOS AS DATE)))                     AS years_covered,
        SUM(CASE WHEN JOBTYPE = 'SCHEDULED'   THEN 1 ELSE 0 END)                    AS scheduled_jobs,
        SUM(CASE WHEN JOBTYPE = 'UNSCHEDULED' THEN 1 ELSE 0 END)                    AS unscheduled_jobs,
        SUM(CASE WHEN JOBTYPE IS NULL          THEN 1 ELSE 0 END)                    AS null_jobtype,
        ROUND(SUM(CASE WHEN JOBTYPE IS NULL THEN 1.0 ELSE 0 END)
              * 100.0 / COUNT(*), 1)                                                AS pct_null_jobtype,
        SUM(CASE WHEN WORKORDER_NUMBER IS NULL
                  OR TRIM(WORKORDER_NUMBER) IN ('', '-', 'N/A')
             THEN 1 ELSE 0 END)                                                     AS missing_workorders,
        ROUND(SUM(CASE WHEN WORKORDER_NUMBER IS NULL
                       OR TRIM(WORKORDER_NUMBER) IN ('', '-', 'N/A')
                  THEN 1.0 ELSE 0 END)
              * 100.0 / COUNT(*), 1)                                                AS pct_missing_workorders,
        SUM(CASE WHEN REMOVED_SERIALNO IS NULL
                  OR TRIM(REMOVED_SERIALNO) IN ('', 'SN-UNKNOWN', 'NSN', 'NOT INSTALLED')
             THEN 1 ELSE 0 END)                                                     AS missing_removed_serial,
        ROUND(SUM(CASE WHEN REMOVED_SERIALNO IS NULL
                       OR TRIM(REMOVED_SERIALNO) IN ('', 'SN-UNKNOWN', 'NSN', 'NOT INSTALLED')
                  THEN 1.0 ELSE 0 END)
              * 100.0 / COUNT(*), 1)                                                AS pct_missing_removed_serial
    FROM {table}
"""


def _summarise_one_table(table_ref):
    """Run overview SQL through the thread-safe query client."""
    sql = _OVERVIEW_SQL.format(table=table_ref).strip()
    outcome = db_client.execute(sql, table_ref=table_ref)
    if not outcome.ok:
        return table_ref, None, None, _error_text(outcome.error)
    return table_ref, outcome.columns, outcome.rows, None


def _answer_legacy_cross_dataset_overview() -> dict:
    """
    Semantic-layer overview: query every discovered table for the same summary
    metrics, then ask Ollama to synthesise a cross-dataset narrative with
    similarities and differences highlighted.
    """
    import concurrent.futures

    tables = discovered_tables if discovered_tables else [active_table()]

    # Run summary queries in parallel (one thread per table)
    table_summaries = {}
    all_cols = None
    all_rows = []

    with concurrent.futures.ThreadPoolExecutor(max_workers=min(len(tables), 6)) as ex:
        futures = {ex.submit(_summarise_one_table, t): t for t in tables}
        for fut in concurrent.futures.as_completed(futures):
            tref, cols, rows, err = fut.result()
            if err or not rows:
                table_summaries[tref] = {"error": err or "no rows returned"}
            else:
                table_summaries[tref] = dict(zip(cols, rows[0]))
                if all_cols is None:
                    all_cols = ["dataset"] + cols
                all_rows.append([tref] + list(rows[0]))

    if not all_rows:
        # Surface the actual per-table error(s) instead of a generic message
        err_lines = []
        for tref, stats in table_summaries.items():
            if "error" in stats:
                err_lines.append(f"• `{tref}`: {stats['error']}")
        err_detail = "\n".join(err_lines) if err_lines else "No tables returned data."
        return {
            "type": "error",
            "answer": f"Could not retrieve summary stats. Query errors:\n\n{err_detail}",
            "sql": _OVERVIEW_SQL.strip(),
            "columns": None,
            "rows": None,
        }

    # Build a readable text block for Ollama
    summary_lines = []
    for tref, stats in table_summaries.items():
        if "error" in stats:
            summary_lines.append(f"Dataset: {tref}\n  ⚠ {stats['error']}")
        else:
            lines = [f"Dataset: {tref}"]
            for k, v in stats.items():
                lines.append(f"  {k}: {v}")
            summary_lines.append("\n".join(lines))

    summary_text = "\n\n".join(summary_lines)

    system = (
        "You are an aviation fleet reliability analyst. You have been given summary "
        "statistics for one or more maintenance datasets from a business aviation operator. "
        "Your job is to give a clear, concise overview that an engineering director would "
        "find useful — covering: what data exists, the date coverage, data quality issues "
        "(null jobtypes, missing work orders, missing serial numbers), and where datasets "
        "overlap or differ in scope. Use plain language. Use bullet points. Be direct about "
        "data quality problems — don't soften them. Flag anything anomalous."
    )

    narrative_prompt = (
        f"Here are the summary statistics for {len(table_summaries)} dataset(s) "
        f"in this Databricks environment:\n\n{summary_text}\n\n"
        "Please provide:\n"
        "1. A brief description of each dataset (what it appears to cover)\n"
        "2. Key metrics for each (record count, date range, aircraft count)\n"
        "3. Data quality highlights (null jobtypes, missing work orders/serials)\n"
        "4. If multiple datasets: similarities, differences, and any apparent overlap\n"
        "5. One or two recommended first questions to explore the data further"
    )

    narrative, err = call_ollama(narrative_prompt, system_prompt=system, timeout=120)
    if err or not narrative:
        # Fallback: return the raw table without narrative
        narrative = f"Retrieved stats for {len(all_rows)} dataset(s). See table below."

    return {
        "type": "overview",
        "answer": narrative,
        "sql": _OVERVIEW_SQL.strip(),
        "columns": all_cols,
        "rows": all_rows,
    }


def _live_profile_metadata(table_ref: str):
    """Refresh metadata so a changed schema cannot reuse a stale profile."""
    described = dataset_discovery.describe_table(table_ref)
    if not described.ok:
        return None, described.error
    metadata = described.value
    if dataset_registry.get().table_ref == table_ref:
        dataset_registry.activate(metadata)
    return metadata, None


def answer_profile(table_ref: str = None, *, refresh: bool = False) -> dict:
    """Build a bounded schema-agnostic profile for the active dataset."""
    table_ref = table_ref or active_table()
    metadata, metadata_error = _live_profile_metadata(table_ref)
    if metadata_error:
        return {
            "type": "error",
            "answer": f"Could not describe `{table_ref}`: {_error_text(metadata_error)}",
            "error": _error_payload(metadata_error),
            "sql": f"DESCRIBE TABLE {table_ref}",
            "columns": None,
            "rows": None,
        }

    outcome = dataset_profiler.get_or_create(metadata, refresh=refresh)
    if not outcome.ok:
        return {
            "type": "error",
            "answer": f"Could not profile `{table_ref}`: {_error_text(outcome.error)}",
            "error": _error_payload(outcome.error),
            "sql": None,
            "columns": None,
            "rows": None,
        }

    profile = outcome.profile
    role_summary = ", ".join(
        f"{role}: {count}" for role, count in sorted(profile["role_summary"].items())
    ) or "none inferred"
    anomaly_summary = ", ".join(
        f"{name.replace('_', ' ')}: {count} column(s)"
        for name, count in sorted(profile["anomaly_summary"].items())
    ) or "no structural flags"
    identifier_names = [
        ", ".join(candidate["columns"])
        for candidate in profile.get("candidate_identifiers", [])
    ]
    key_text = "; ".join(identifier_names[:5]) or "none identified"
    source_text = "cached profile" if outcome.cached else "new live profile"
    answer = (
        f"**Dataset profile — `{table_ref}`**\n\n"
        f"- Records: **{profile['record_count']:,}**\n"
        f"- Columns: **{profile['column_count']}**\n"
        f"- Inferred roles: {role_summary}\n"
        f"- Candidate identifiers: {key_text}\n"
        f"- Review flags: {anomaly_summary}\n"
        f"- Schema fingerprint: `{metadata.schema_fingerprint[:12]}`\n"
        f"- Source: {source_text}\n\n"
        "Flags and candidate keys are evidence for review, not proof that data is wrong or unique. "
        "Candidate keys should be confirmed with an exact duplicate check before use."
    )
    rows = []
    for column in profile["columns"]:
        value_range = ""
        if column.get("min") is not None or column.get("max") is not None:
            value_range = f"{column.get('min', '')} → {column.get('max', '')}"
        rows.append([
            column["name"],
            column["data_type"],
            column["inferred_role"],
            round(column["missing_rate"] * 100, 2),
            column.get("approx_distinct_count"),
            value_range,
            ", ".join(column["anomalies"]),
        ])
    return {
        "type": "profile",
        "answer": answer,
        "sql": None,
        "columns": ["column", "type", "inferred role", "missing %", "approx distinct", "range", "review flags"],
        "rows": rows,
        "profile": profile,
        "cached": outcome.cached,
    }


def _format_stat(value):
    if value is None:
        return None
    if isinstance(value, float):
        if abs(value) >= 1000:
            return round(value, 1)
        return round(value, 3)
    return value


def build_overview_charts(profile: dict) -> list[dict]:
    """Create structural and categorical visuals from a generic profile."""
    charts = []
    role_summary = profile.get("role_summary") or {}
    if role_summary:
        labels = [label.replace("_", " ").title() for label in role_summary]
        values = [role_summary[label] for label in role_summary]
        charts.append({
            "data": [{
                "type": "pie",
                "labels": labels,
                "values": values,
                "hole": 0.55,
                "textinfo": "label+value",
                "marker": {"colors": [
                    "#B8864F", "#5B8DB8", "#6FA58D", "#C46F5B",
                    "#8D75B8", "#D1A95D", "#8B929A",
                ]},
            }],
            "layout": {
                "title": {"text": "Dataset structure", "font": {"size": 15}, "x": 0.02},
                "paper_bgcolor": "rgba(0,0,0,0)",
                "plot_bgcolor": "rgba(0,0,0,0)",
                "font": {"color": "#FCFAF6", "family": "Inter, ui-sans-serif, sans-serif"},
                "margin": {"l": 20, "r": 20, "t": 45, "b": 20},
                "height": 300,
                "legend": {"orientation": "h", "y": -0.1},
            },
        })

    dimensions = [
        column for column in profile.get("columns", [])
        if column.get("inferred_role") == "dimension"
        and column.get("representative_values")
        and 1 < (column.get("approx_distinct_count") or 0) <= 15
    ]
    dimensions.sort(key=lambda column: (
        column.get("missing_rate", 0),
        column.get("approx_distinct_count", 999),
        column.get("name", "").lower(),
    ))
    for column in dimensions[:2]:
        pairs = [
            (str(item.get("value")), int(item.get("count") or 0))
            for item in column.get("representative_values", [])
        ]
        missing = int(column.get("missing_count") or 0)
        if missing:
            pairs.append(("(Missing)", missing))
        pairs.sort(key=lambda item: item[1])
        charts.append({
            "data": [{
                "type": "bar",
                "orientation": "h",
                "x": [count for _, count in pairs],
                "y": [label for label, _ in pairs],
                "marker": {"color": "#B8864F"},
                "hovertemplate": "%{y}: %{x:,}<extra></extra>",
            }],
            "layout": {
                "title": {"text": f"{column['name']} distribution", "font": {"size": 15}, "x": 0.02},
                "paper_bgcolor": "rgba(0,0,0,0)",
                "plot_bgcolor": "rgba(0,0,0,0)",
                "font": {"color": "#FCFAF6", "family": "Inter, ui-sans-serif, sans-serif"},
                "margin": {"l": 100, "r": 20, "t": 45, "b": 45},
                "height": max(280, 45 + len(pairs) * 28),
                "xaxis": {"title": "Record count", "gridcolor": "rgba(255,255,255,.08)"},
                "yaxis": {"automargin": True},
            },
        })
    return charts


def answer_overview(table_ref: str = None) -> dict:
    """Return descriptive statistics and visuals, distinct from integrity."""
    table_ref = table_ref or active_table()
    profiled = answer_profile(table_ref, refresh=False)
    if profiled.get("type") == "error":
        return profiled
    profile = profiled["profile"]
    record_count = int(profile.get("record_count") or 0)
    columns = profile.get("columns") or []
    measures = [column for column in columns if column.get("inferred_role") == "measure"]
    dates = [
        column for column in columns
        if column.get("inferred_role") == "date"
        and (column.get("min") is not None or column.get("max") is not None)
    ]
    dimensions = [column for column in columns if column.get("inferred_role") == "dimension"]
    complete_columns = sum(1 for column in columns if not column.get("missing_count"))
    high_missing_columns = sum(1 for column in columns if (column.get("missing_rate") or 0) >= 0.5)

    date_text = "; ".join(
        f"`{column['name']}`: {column.get('min', '—')} to {column.get('max', '—')}"
        for column in dates[:4]
    ) or "No typed date range was identified."
    dimension_text = ", ".join(
        f"`{column['name']}` ({column.get('approx_distinct_count', 0):,} values)"
        for column in dimensions[:6]
    ) or "none inferred"
    answer = (
        f"## Dataset overview\n\n"
        f"`{table_ref}` contains **{record_count:,} records** and **{len(columns)} columns**: "
        f"**{len(measures)} measures**, **{len(dimensions)} dimensions**, "
        f"and **{len(dates)} typed date fields**.\n\n"
        f"## Coverage\n\n{date_text}\n\n"
        f"Key categorical fields include {dimension_text}.\n\n"
        f"## Data-quality context\n\n"
        f"**{complete_columns} columns** are fully populated and **{high_missing_columns} columns** "
        "have at least 50% missing values. This is only overview context; use **Data integrity** "
        "for completeness, uniqueness, monotonicity, consistency, date coverage and metadata evidence."
    )
    rows = []
    for column in measures[:12]:
        rows.append([
            column["name"],
            record_count - int(column.get("missing_count") or 0),
            round(float(column.get("missing_rate") or 0) * 100, 2),
            column.get("approx_distinct_count"),
            _format_stat(column.get("min")),
            _format_stat(column.get("mean")),
            _format_stat(column.get("max")),
            _format_stat(column.get("stddev")),
        ])
    return {
        "type": "overview",
        "answer": answer,
        "sql": None,
        "columns": [
            "measure", "populated", "missing %", "approx distinct",
            "minimum", "mean", "maximum", "std deviation",
        ] if rows else None,
        "rows": rows or None,
        "profile": profile,
        "cached": profiled.get("cached", False),
        "charts": build_overview_charts(profile),
    }


def answer_integrity_check(table: str = None, metadata=None) -> dict:
    """Run the six-part, schema-agnostic integrity review.

    The result deliberately uses Review/No flags/Not run rather than Pass/Fail:
    every flag is evidence for review, not proof that a record is wrong.
    """
    table = table or active_table()
    if metadata is None or metadata.table_ref != table or not metadata.columns:
        metadata, metadata_error = _live_profile_metadata(table)
        if metadata_error:
            return {
                "type": "error",
                "answer": f"Could not describe `{table}`: {_error_text(metadata_error)}",
                "error": _error_payload(metadata_error),
                "sql": f"DESCRIBE TABLE {table}",
                "columns": None,
                "rows": None,
            }

    columns = [column.name for column in metadata.columns]
    profile = _matching_profile(metadata)
    overrides, config_error = load_integrity_overrides(INTEGRITY_CONFIG_PATH, table)
    plan = build_integrity_plan(metadata, profile, overrides)

    completeness_sql = build_completeness_sql(table, columns)
    pcols, prows, perr = run_sql(completeness_sql, table_ref=table)
    if perr or not prows:
        return {
            "type": "error",
            "answer": f"Integrity completeness scan failed: {_error_text(perr) if perr else 'no rows returned'}",
            "error": _error_payload(perr) if perr else {
                "category": "empty_result",
                "message": "The completeness scan returned no rows.",
                "retryable": False,
            },
            "sql": completeness_sql,
            "columns": None,
            "rows": None,
        }

    aggregate = dict(zip(pcols, prows[0]))
    completeness_header, completeness_report = format_completeness_rows(columns, aggregate)
    total_rows = int(completeness_report[0]["Total Rows"] if completeness_report else 0)
    report_by_name = {row["Field Name"]: row for row in completeness_report}
    summary_rows = []
    details = []
    sql_statements = {"completeness": completeness_sql}

    def number(value):
        try:
            return int(value or 0)
        except (TypeError, ValueError):
            return 0

    def add_summary(check, scope, status, flags, population, evidence):
        summary_rows.append([check, scope, status, flags, population, evidence])

    def run_optional(name, sql):
        if not sql:
            return None, None, None
        sql_statements[name] = sql
        check_columns, check_rows, check_error = run_sql(sql, table_ref=table)
        return check_columns, check_rows, check_error

    missing_fields = [row for row in completeness_report if float(row["% Null"]) > 0]
    high_missing = [row for row in completeness_report if float(row["% Null"]) >= 50]
    empty_fields = [row for row in completeness_report if float(row["% Null"]) >= 100]
    add_summary(
        "Completeness",
        f"{len(completeness_report)} live fields",
        "Review" if missing_fields else "No flags",
        len(missing_fields),
        f"{total_rows:,} rows",
        f"{len(high_missing)} field(s) ≥50% missing; {len(empty_fields)} completely empty.",
    )
    details.append({
        "name": "Completeness",
        "columns": completeness_header,
        "rows": [[row[name] for name in completeness_header] for row in completeness_report],
    })

    uniqueness_sql = build_uniqueness_sql(plan)
    ucols, urows, uerr = run_optional("uniqueness", uniqueness_sql)
    key_label = " + ".join(plan.key_columns) if plan.key_columns else "No candidate key"
    if uniqueness_sql is None:
        add_summary("Uniqueness", key_label, "Not run", "—", "—", "Configure or profile a candidate key.")
    elif uerr:
        add_summary("Uniqueness", key_label, "Unavailable", "—", "—", _error_text(uerr))
    else:
        uniqueness = dict(zip(ucols or [], (urows or [[0]])[0]))
        duplicate_groups = number(uniqueness.get("duplicate_groups"))
        excess_rows = number(uniqueness.get("excess_duplicate_rows"))
        add_summary(
            "Uniqueness", key_label, "Review" if duplicate_groups else "No flags",
            duplicate_groups, f"{total_rows:,} rows",
            f"{excess_rows:,} excess row(s) across exact duplicate-key groups.",
        )
        details.append({"name": "Uniqueness", "columns": ucols, "rows": urows or []})

    monotonicity_sql = build_monotonicity_sql(plan)
    mcols, mrows, merr = run_optional("monotonicity", monotonicity_sql)
    cumulative_label = ", ".join(plan.cumulative_columns) or "No cumulative fields"
    if monotonicity_sql is None:
        add_summary("Monotonicity", cumulative_label, "Not run", "—", "—", "Needs entity, date/time and cumulative fields.")
    elif merr:
        add_summary("Monotonicity", cumulative_label, "Unavailable", "—", "—", _error_text(merr))
    else:
        monotonicity = [dict(zip(mcols or [], row)) for row in (mrows or [])]
        decreases = sum(number(row.get("decreases")) for row in monotonicity)
        transitions = sum(number(row.get("checked_transitions")) for row in monotonicity)
        add_summary(
            "Monotonicity", cumulative_label, "Review" if decreases else "No flags",
            decreases, f"{transitions:,} transitions",
            "Same-timestamp records are collapsed before cumulative decreases are counted.",
        )
        details.append({"name": "Monotonicity", "columns": mcols, "rows": mrows or []})

    consistency_sql = build_consistency_sql(plan)
    ccols, crows, cerr = run_optional("cross_column_consistency", consistency_sql)
    consistency_label = "; ".join(f"{event} ≤ {cumulative}" for event, cumulative in plan.consistency_pairs)
    if consistency_sql is None:
        add_summary("Cross-column consistency", "No field pairs", "Not run", "—", "—", "Configure or profile event/cumulative pairs.")
    elif cerr:
        add_summary("Cross-column consistency", consistency_label, "Unavailable", "—", "—", _error_text(cerr))
    else:
        consistency = [dict(zip(ccols or [], row)) for row in (crows or [])]
        violations = sum(number(row.get("violations")) for row in consistency)
        comparable = sum(number(row.get("comparable_rows")) for row in consistency)
        add_summary(
            "Cross-column consistency", consistency_label, "Review" if violations else "No flags",
            violations, f"{comparable:,} comparisons",
            "Flags event values greater than their paired cumulative value.",
        )
        details.append({"name": "Consistency", "columns": ccols, "rows": crows or []})

    date_sql = build_date_coverage_sql(plan)
    dcols, drows, derr = run_optional("date_coverage", date_sql)
    date_label = plan.order_column or "No date/time field"
    if date_sql is None:
        add_summary("Date coverage", date_label, "Not run", "—", "—", "Needs both entity and date/time fields.")
    elif derr:
        add_summary("Date coverage", date_label, "Unavailable", "—", "—", _error_text(derr))
    else:
        date_evidence = [dict(zip(dcols or [], row)) for row in (drows or [])]
        entities_with_gaps = sum(1 for row in date_evidence if number(row.get("largest_gap_days")) > 0)
        largest_gap = max((number(row.get("largest_gap_days")) for row in date_evidence), default=0)
        add_summary(
            "Date coverage", date_label, "Review" if entities_with_gaps else "No flags",
            entities_with_gaps, f"{len(date_evidence):,} entities shown",
            f"Largest calendar gap: {largest_gap:,} day(s); cadence may legitimately be non-daily.",
        )
        details.append({"name": "Date coverage", "columns": dcols, "rows": drows or []})

    metadata_report = [
        report_by_name[name] for name in plan.metadata_columns if name in report_by_name
    ]
    if not plan.metadata_columns:
        add_summary("Metadata completeness", "No metadata fields", "Not run", "—", "—", "Configure or profile descriptor fields.")
    else:
        metadata_missing = [row for row in metadata_report if float(row["% Null"]) > 0]
        add_summary(
            "Metadata completeness", ", ".join(plan.metadata_columns),
            "Review" if metadata_missing else "No flags", len(metadata_missing),
            f"{len(metadata_report)} fields",
            "Missing/placeholder values in inferred or configured descriptor fields.",
        )
        details.append({
            "name": "Metadata",
            "columns": completeness_header,
            "rows": [[row[name] for name in completeness_header] for row in metadata_report],
        })

    review_count = sum(1 for row in summary_rows if row[2] == "Review")
    no_flag_count = sum(1 for row in summary_rows if row[2] == "No flags")
    not_run_count = sum(1 for row in summary_rows if row[2] in {"Not run", "Unavailable"})
    notes = list(plan.review_notes)
    if config_error:
        notes.insert(0, config_error)
    note_text = "\n".join(f"- {note}" for note in notes[:8]) or "- No planning limitations were recorded."
    profile_text = "matching dataset profile" if profile else "live schema only"
    answer = (
        f"## Data integrity review\n\n"
        f"`{table}` contains **{total_rows:,} rows**. Across six checks, **{review_count} need review**, "
        f"**{no_flag_count} returned no flags**, and **{not_run_count} were not run or unavailable**. "
        f"The plan was **{plan.source}** using {profile_text}.\n\n"
        "A flag is evidence for review, not proof that data is wrong. Duplicate operational values, "
        "counter decreases and date gaps can be legitimate; confirm the business rule and record history "
        "before changing, merging or deleting anything. Decimal and `H:MM` operational values are "
        "normalised for numeric comparisons.\n\n"
        f"## Planning notes\n\n{note_text}"
    )
    return {
        "type": "integrity",
        "answer": answer,
        "sql": completeness_sql,
        "sql_statements": sql_statements,
        "columns": ["Check", "Scope", "Status", "Flags", "Population", "Evidence"],
        "rows": summary_rows,
        "integrity_details": details,
        "integrity_plan": plan.to_dict(),
        "provenance": _query_provenance(metadata, profile, sql_source="integrity_framework"),
    }


def _semantic_distribution_summary(
    columns: list,
    rows: list,
    *,
    category_column: str,
    group_column: str,
) -> str:
    records = _rows_as_dicts(columns, rows)
    total = sum(int(item.get("record_count") or 0) for item in records)
    groups = {str(item.get("group_value")) for item in records}
    categories = {str(item.get("category_value")) for item in records}
    category_totals = {}
    for item in records:
        category = str(item.get("category_value"))
        category_totals[category] = category_totals.get(category, 0) + int(item.get("record_count") or 0)
    leading = sorted(category_totals.items(), key=lambda item: (-item[1], item[0]))[:5]
    leading_text = "; ".join(
        f"**{label}**: {count:,} ({count * 100.0 / total:.1f}%)"
        for label, count in leading
    ) if total else "no populated categories"
    missing_group = sum(
        int(item.get("record_count") or 0)
        for item in records if item.get("group_value") == "(Missing)"
    )
    missing_category = category_totals.get("(Missing)", 0)
    quality_parts = []
    if missing_group:
        quality_parts.append(f"{missing_group:,} records have a missing `{group_column}`")
    if missing_category:
        quality_parts.append(f"{missing_category:,} have a missing `{category_column}`")
    quality_text = (
        " Data visibility note: " + "; ".join(quality_parts) + "."
        if quality_parts else ""
    )
    return (
        f"## Distribution of `{category_column}` by `{group_column}`\n\n"
        f"The result covers **{total:,} records**, **{len(groups)} `{group_column}` groups**, "
        f"and **{len(categories)} displayed `{category_column}` categories**. "
        f"Overall category mix: {leading_text}.{quality_text}\n\n"
        "The stacked visual compares record counts across groups. Percentages in the table are "
        "calculated within each group; they describe the recorded distribution, not failure rates."
    )


def answer_semantic_distribution(question: str, table_ref: str = None) -> dict:
    """Resolve and run a category-by-group distribution from live metadata."""
    request_spec = parse_distribution_request(question)
    if request_spec is None:
        return {
            "type": "clarification",
            "answer": "Name both dimensions, for example: “distribution of removal reason by aircraft.”",
            "sql": None,
            "columns": None,
            "rows": None,
        }

    table_ref = table_ref or active_table()
    current = dataset_registry.get()
    metadata = current if current.table_ref == table_ref and current.columns else None
    if metadata is None:
        metadata, metadata_error = _live_profile_metadata(table_ref)
        if metadata_error:
            return {
                "type": "error",
                "answer": f"Could not read the live schema for `{table_ref}`: {_error_text(metadata_error)}",
                "error": _error_payload(metadata_error),
                "sql": None,
                "columns": None,
                "rows": None,
            }

    category_match = resolve_column(request_spec.category_phrase, metadata.columns)
    group_match = resolve_column(request_spec.group_phrase, metadata.columns)
    unresolved = []
    for label, match in (("category", category_match), ("grouping", group_match)):
        if match.column is None:
            if match.ambiguous:
                unresolved.append(
                    f"The {label} phrase **{match.phrase}** matches more than one field: "
                    + ", ".join(f"`{name}`" for name in match.ambiguous)
                )
            else:
                unresolved.append(
                    f"I could not map the {label} phrase **{match.phrase}** to a live field"
                )
    if unresolved:
        return {
            "type": "clarification",
            "answer": "\n\n".join(unresolved) + ". Please name the intended column.",
            "sql": None,
            "columns": None,
            "rows": None,
        }
    if category_match.column.name == group_match.column.name:
        return {
            "type": "clarification",
            "answer": (
                f"Both phrases resolved to `{category_match.column.name}`. "
                "Please provide two different dimensions."
            ),
            "sql": None,
            "columns": None,
            "rows": None,
        }

    sql = build_grouped_distribution_sql(
        table_ref,
        category_match.column.name,
        group_match.column.name,
    )
    columns, rows, error = run_sql(sql, table_ref=table_ref)
    if error:
        return {
            "type": "error",
            "answer": f"The grouped distribution query failed: {_error_text(error)}",
            "error": _error_payload(error),
            "sql": sql,
            "columns": None,
            "rows": None,
        }
    return {
        "type": "analytical",
        "answer": _semantic_distribution_summary(
            columns,
            rows,
            category_column=category_match.column.name,
            group_column=group_match.column.name,
        ),
        "sql": sql,
        "columns": columns,
        "rows": rows,
        "semantic_distribution": {
            "category_column": category_match.column.name,
            "group_column": group_match.column.name,
            "category_phrase": request_spec.category_phrase,
            "group_phrase": request_spec.group_phrase,
        },
        "provenance": _query_provenance(
            metadata,
            _matching_profile(metadata),
            sql_source="semantic_template",
        ),
    }


def _semantic_metadata(table_ref: str):
    current = dataset_registry.get()
    if current.table_ref == table_ref and current.columns:
        return current, None
    return _live_profile_metadata(table_ref)


def _column_clarification(label: str, match) -> str:
    if match.ambiguous:
        return (
            f"The {label} phrase **{match.phrase}** matches more than one live field: "
            + ", ".join(f"`{name}`" for name in match.ambiguous)
            + ". Please name the intended field."
        )
    return f"I could not map the {label} phrase **{match.phrase}** to a live field."


def _semantic_temporal_summary(columns, rows, semantic: dict) -> str:
    records = _rows_as_dicts(columns, rows)
    if not records:
        return (
            f"No records contained a usable `{semantic['date_column']}` value for the requested "
            f"{semantic['period']} view."
        )
    periods = sorted({str(item.get("period_value")) for item in records})
    total = sum(int(item.get("record_count") or 0) for item in records)
    category_column = semantic.get("category_column")
    if not category_column:
        peak = max(records, key=lambda item: int(item.get("record_count") or 0))
        return (
            f"## {semantic['period'].title()}ly record trend\n\n"
            f"The result covers **{total:,} records** across **{len(periods)} periods**, using "
            f"`{semantic['date_column']}`. The highest displayed period is "
            f"**{peak.get('period_value')}** with **{int(peak.get('record_count') or 0):,} records**. "
            "This is a record-volume trend; it does not by itself represent a failure or utilisation rate."
        )

    totals = {}
    for item in records:
        category = str(item.get("category_value") or "(Missing)")
        totals[category] = totals.get(category, 0) + int(item.get("record_count") or 0)
    leading = sorted(totals.items(), key=lambda item: (-item[1], item[0]))[:5]
    mix = "; ".join(
        f"**{label}**: {count:,} ({count * 100.0 / total:.1f}%)"
        for label, count in leading
    ) if total else "no populated categories"
    return (
        f"## `{category_column}` by {semantic['period']}\n\n"
        f"The trend covers **{total:,} records** across **{len(periods)} periods**, using "
        f"`{semantic['date_column']}`. Overall mix: {mix}.\n\n"
        "The visual shows recorded category volumes by period. Changes in record counts do not, "
        "without an exposure denominator, establish a change in reliability or event rate."
    )


def answer_semantic_temporal(question: str, table_ref: str = None) -> dict:
    request_spec = parse_temporal_request(question)
    if request_spec is None:
        return {
            "type": "clarification",
            "answer": "Name a period and subject, for example: “yearly distribution of job type.”",
            "sql": None,
            "columns": None,
            "rows": None,
        }
    table_ref = table_ref or active_table()
    metadata, metadata_error = _semantic_metadata(table_ref)
    if metadata_error:
        return {
            "type": "error",
            "answer": f"Could not read the live schema for `{table_ref}`: {_error_text(metadata_error)}",
            "error": _error_payload(metadata_error),
            "sql": None,
            "columns": None,
            "rows": None,
        }

    date_match = resolve_temporal_column(question, metadata.columns)
    if date_match.column is None:
        guidance = _column_clarification("date/time", date_match)
        if date_match.ambiguous:
            guidance += " Repeat the question with `using <date field>`."
        return {
            "type": "clarification",
            "answer": guidance,
            "sql": None,
            "columns": None,
            "rows": None,
        }

    category_match = None
    if request_spec.category_phrase:
        category_match = resolve_column(request_spec.category_phrase, metadata.columns)
        if category_match.column is None:
            return {
                "type": "clarification",
                "answer": _column_clarification("trend category", category_match),
                "sql": None,
                "columns": None,
                "rows": None,
            }

    sql = build_temporal_distribution_sql(
        table_ref,
        date_match.column.name,
        category_column=category_match.column.name if category_match else None,
        period=request_spec.period,
    )
    columns, rows, error = run_sql(sql, table_ref=table_ref)
    if error:
        return {
            "type": "error",
            "answer": f"The temporal query failed: {_error_text(error)}",
            "error": _error_payload(error),
            "sql": sql,
            "columns": None,
            "rows": None,
        }

    semantic = {
        "date_column": date_match.column.name,
        "category_column": category_match.column.name if category_match else None,
        "period": request_spec.period,
    }
    return {
        "type": "analytical",
        "answer": _semantic_temporal_summary(columns, rows, semantic),
        "sql": sql,
        "columns": columns,
        "rows": rows,
        "semantic_temporal": semantic,
        "provenance": _query_provenance(
            metadata,
            _matching_profile(metadata),
            sql_source="semantic_template",
        ),
    }


def _is_numeric_column(column, profile) -> bool:
    data_type = (column.data_type or "").lower().split("(", 1)[0]
    if data_type in {
        "tinyint", "smallint", "int", "integer", "bigint", "float", "double",
        "real", "decimal", "numeric", "short", "long",
    }:
        return True
    for item in (profile or {}).get("columns", []):
        if str(item.get("name") or "").lower() != column.name.lower():
            continue
        non_missing = int((profile or {}).get("record_count") or 0) - int(item.get("missing_count") or 0)
        return non_missing > 0 and int(item.get("numeric_like_count") or 0) / non_missing >= 0.9
    return False


def _semantic_ranking_summary(columns, rows, semantic: dict) -> str:
    records = _rows_as_dicts(columns, rows)
    if not records:
        return "No populated groups were returned for this ranking."
    value_column = next(
        (name for name in columns if str(name).lower() in {"record_count", "sum_value", "avg_value", "min_value", "max_value"}),
        columns[1],
    )
    leaders = records[:5]
    def format_value(raw):
        number = float(raw or 0)
        return f"{int(number):,}" if str(value_column).lower() == "record_count" else f"{number:,.1f}"
    detail = "; ".join(
        f"**{item.get('dimension_value')}**: {format_value(item.get(value_column))}"
        for item in leaders
    )
    title = "Comparison" if semantic.get("comparison") else (
        "Top ranking" if semantic.get("direction") == "desc" else "Bottom ranking"
    )
    measure_text = (
        "record count" if not semantic.get("measure_column")
        else f"{semantic['aggregation']} of `{semantic['measure_column']}`"
    )
    return (
        f"## {title} by `{semantic['dimension_column']}`\n\n"
        f"The query compares **{len(records)} displayed groups** using **{measure_text}**. "
        f"Leading results: {detail}.\n\n"
        "`group_records` is included as the sample-size context. The ranking describes the "
        "selected aggregate and does not by itself establish cause or performance quality."
    )


def answer_semantic_ranking(question: str, table_ref: str = None) -> dict:
    request_spec = parse_ranking_request(question)
    if request_spec is None:
        return {
            "type": "clarification",
            "answer": "Use an explicit ranking, for example: “top 10 suppliers by total cost.”",
            "sql": None,
            "columns": None,
            "rows": None,
        }
    table_ref = table_ref or active_table()
    metadata, metadata_error = _semantic_metadata(table_ref)
    if metadata_error:
        return {
            "type": "error",
            "answer": f"Could not read the live schema for `{table_ref}`: {_error_text(metadata_error)}",
            "error": _error_payload(metadata_error),
            "sql": None,
            "columns": None,
            "rows": None,
        }

    dimension_match = resolve_column(request_spec.dimension_phrase, metadata.columns)
    if dimension_match.column is None:
        return {
            "type": "clarification",
            "answer": _column_clarification("ranking dimension", dimension_match),
            "sql": None,
            "columns": None,
            "rows": None,
        }

    generic_counts = {"record", "records", "row", "rows", "event", "events", "event count", "record count"}
    measure_match = None
    if request_spec.measure_phrase.lower().strip() not in generic_counts:
        measure_match = resolve_column(request_spec.measure_phrase, metadata.columns)
        if measure_match.column is None:
            return {
                "type": "clarification",
                "answer": _column_clarification("ranking measure", measure_match),
                "sql": None,
                "columns": None,
                "rows": None,
            }

    profile = _matching_profile(metadata)
    if (
        request_spec.aggregation != "count"
        and measure_match
        and not _is_numeric_column(measure_match.column, profile)
    ):
        return {
            "type": "clarification",
            "answer": (
                f"`{measure_match.column.name}` is not a verified numeric measure in the live schema/profile. "
                "Choose a numeric field or ask for a record count."
            ),
            "sql": None,
            "columns": None,
            "rows": None,
        }

    sql = build_ranking_sql(
        table_ref,
        dimension_match.column.name,
        measure_column=measure_match.column.name if measure_match else None,
        aggregation=request_spec.aggregation,
        direction=request_spec.direction,
        limit=request_spec.limit,
    )
    columns, rows, error = run_sql(sql, table_ref=table_ref)
    if error:
        return {
            "type": "error",
            "answer": f"The ranking query failed: {_error_text(error)}",
            "error": _error_payload(error),
            "sql": sql,
            "columns": None,
            "rows": None,
        }
    semantic = {
        "dimension_column": dimension_match.column.name,
        "measure_column": measure_match.column.name if measure_match else None,
        "aggregation": request_spec.aggregation,
        "direction": request_spec.direction,
        "limit": request_spec.limit,
        "comparison": request_spec.comparison,
    }
    return {
        "type": "analytical",
        "answer": _semantic_ranking_summary(columns, rows, semantic),
        "sql": sql,
        "columns": columns,
        "rows": rows,
        "semantic_ranking": semantic,
        "provenance": _query_provenance(
            metadata,
            profile,
            sql_source="semantic_template",
        ),
    }


def answer_analytical(
    question: str,
    shortcut_name: str = None,
    table_ref: str = None,
    metadata=None,
) -> dict:
    """Run a guarded shortcut or one schema-grounded generated query.

    Generated SQL gets at most one correction attempt.  There is no retry loop:
    the correction is used either for local schema-validation evidence or for a
    real, repairable Databricks SQL error.
    """
    sql = None
    table_ref = table_ref or active_table()
    metadata = _metadata_for_query(table_ref, metadata)
    if metadata is None or not metadata.columns:
        return {
            "type": "error",
            "answer": "Live schema metadata is unavailable for the selected dataset.",
            "error": {
                "category": "metadata",
                "message": "Live schema metadata is unavailable for the selected dataset.",
                "retryable": True,
            },
            "sql": None,
            "columns": None,
            "rows": None,
        }

    profile = _matching_profile(metadata)
    sql_source = "named_shortcut" if shortcut_name else "local_model"
    repair_attempted = False
    repair_succeeded = False

    def provenance():
        return _query_provenance(
            metadata,
            profile,
            sql_source=sql_source,
            repair_attempted=repair_attempted,
            repair_succeeded=repair_succeeded,
        )

    # A legacy shortcut is an optional analysis pack, not a universal schema.
    if shortcut_name and shortcut_name in NAMED_QUERIES:
        shortcut = NAMED_QUERIES[shortcut_name]
        missing = missing_shortcut_columns(shortcut, metadata)
        if missing:
            message = (
                f"The **{shortcut_name}** shortcut is not compatible with `{table_ref}`. "
                "It requires fields that are not present: "
                + ", ".join(f"`{name}`" for name in missing)
                + ". Ask the same analytical question in plain English so AvTrix can use this dataset's live schema."
            )
            return {
                "type": "error",
                "answer": message,
                "error": {"category": "schema_compatibility", "message": message, "retryable": False},
                "sql": None,
                "columns": None,
                "rows": None,
                "provenance": provenance(),
            }
        sql = shortcut["sql"].format(table=table_ref).strip()
    else:
        sql, generation_error = nl_to_sql(
            question,
            table_ref=table_ref,
            metadata=metadata,
        )
        if generation_error:
            return {
                "type": "error",
                "answer": f"Could not generate SQL: {generation_error}",
                "error": {"category": "generation", "message": str(generation_error), "retryable": True},
                "sql": None,
                "columns": None,
                "rows": None,
                "provenance": provenance(),
            }
        if not sql:
            return {
                "type": "error",
                "answer": "No SQL was generated.",
                "error": {"category": "generation", "message": "No SQL was generated.", "retryable": True},
                "sql": None,
                "columns": None,
                "rows": None,
                "provenance": provenance(),
            }

        validation_issues = validate_generated_sql(sql, metadata)
        if validation_issues:
            repair_attempted = True
            sql, generation_error = nl_to_sql(
                question,
                table_ref=table_ref,
                metadata=metadata,
                repair_context={"sql": sql, "error": " ".join(validation_issues)},
            )
            if generation_error or not sql:
                message = generation_error or "The correction attempt returned no SQL."
                return {
                    "type": "error",
                    "answer": f"Could not correct the generated query: {message}",
                    "error": {"category": "generation", "message": str(message), "retryable": True},
                    "sql": sql,
                    "columns": None,
                    "rows": None,
                    "provenance": provenance(),
                }
            validation_issues = validate_generated_sql(sql, metadata)
            if validation_issues:
                message = "The corrected query still conflicts with the live schema: " + " ".join(validation_issues)
                return {
                    "type": "error",
                    "answer": message,
                    "error": {"category": "schema_validation", "message": message, "retryable": False},
                    "sql": sql,
                    "columns": None,
                    "rows": None,
                    "provenance": provenance(),
                }

    columns, rows, err = run_sql(sql, table_ref=table_ref)

    if err and not shortcut_name and not repair_attempted and is_repairable_sql_error(err):
        repair_attempted = True
        repaired_sql, generation_error = nl_to_sql(
            question,
            table_ref=table_ref,
            metadata=metadata,
            repair_context={"sql": sql, "error": _error_text(err)},
        )
        if generation_error or not repaired_sql:
            message = generation_error or "The correction attempt returned no SQL."
            return {
                "type": "error",
                "answer": f"The first query failed and could not be corrected: {message}",
                "error": _error_payload(err),
                "sql": sql,
                "columns": None,
                "rows": None,
                "provenance": provenance(),
            }
        sql = repaired_sql
        validation_issues = validate_generated_sql(sql, metadata)
        if validation_issues:
            message = "The correction conflicts with the live schema: " + " ".join(validation_issues)
            return {
                "type": "error",
                "answer": message,
                "error": {"category": "schema_validation", "message": message, "retryable": False},
                "sql": sql,
                "columns": None,
                "rows": None,
                "provenance": provenance(),
            }
        columns, rows, err = run_sql(sql, table_ref=table_ref)
        repair_succeeded = err is None

    if err:
        return {
            "type": "error",
            "answer": f"Query failed: {_error_text(err)}",
            "error": _error_payload(err),
            "sql": sql,
            "columns": None,
            "rows": None,
            "provenance": provenance(),
        }

    if repair_attempted:
        repair_succeeded = True

    if shortcut_name == "reason_by_jobtype":
        interpretation = summarise_reason_by_jobtype(columns, rows)
        visual_story = "reason_by_jobtype"
    elif shortcut_name == "jobtype_distribution":
        interpretation = summarise_jobtype_distribution(columns, rows)
        visual_story = None
    elif shortcut_name == "jobtype_temporal":
        interpretation = summarise_jobtype_temporal(columns, rows)
        visual_story = None
    else:
        interpretation = (
            summarise_categorical_distribution(question, columns, rows)
            or interpret_results(question, columns, rows)
        )
        visual_story = None

    return {
        "type": "analytical",
        "answer": interpretation,
        "sql": sql,
        "columns": columns,
        "rows": rows,
        "visual_story": visual_story,
        "provenance": provenance(),
    }


# ── Chart helpers ─────────────────────────────────────────────────────────────
def detect_chart_type(columns, rows):
    """Auto-detect chart type from result shape."""
    if not columns or not rows:
        return None
    numeric_cols = []
    string_cols  = []
    date_cols    = []
    for i, col in enumerate(columns):
        col_l = col.lower()
        sample = [r[i] for r in rows[:20] if r[i] is not None]
        if any(kw in col_l for kw in ["year", "month", "date", "time", "quarter"]):
            date_cols.append(i)
        elif sample and isinstance(sample[0], (int, float)):
            numeric_cols.append(i)
        else:
            string_cols.append(i)

    if date_cols and numeric_cols:
        return "line"
    if string_cols and numeric_cols:
        return "bar"
    if len(numeric_cols) >= 2:
        return "scatter"
    return None


def build_chart(columns, rows, chart_type):
    """Build a Plotly JSON chart spec."""
    try:
        import plotly.graph_objects as go
        import plotly

        copper = "#B8864F"
        copper2 = "#CBA36A"
        slate  = "#1A1F25"

        if chart_type == "bar":
            # First string col = labels, first numeric col = values
            label_idx = next((i for i, c in enumerate(columns)
                              if not isinstance(rows[0][i], (int, float))), 0)
            val_idx   = next((i for i, c in enumerate(columns)
                              if isinstance(rows[0][i], (int, float))), 1)
            fig = go.Figure(go.Bar(
                x=[str(r[label_idx]) for r in rows],
                y=[r[val_idx] for r in rows],
                marker_color=copper,
            ))
            fig.update_layout(xaxis_title=columns[label_idx], yaxis_title=columns[val_idx])

        elif chart_type == "line":
            # Date/year col = x, all numeric cols = series
            date_idx = next((i for i, c in enumerate(columns)
                             if any(k in c.lower() for k in ["year","month","date","time","quarter"])), 0)
            numeric_idxs = [i for i in range(len(columns)) if i != date_idx
                            and rows and isinstance(rows[0][i], (int, float))]
            # A time-series story is clearer without denominator and percentage
            # fields competing with the actual category counts.
            count_idxs = [
                i for i in numeric_idxs
                if not columns[i].lower().startswith("pct_")
                and columns[i].lower() not in {"total", "total_records", "record_count"}
            ]
            if count_idxs:
                numeric_idxs = count_idxs
            colors = [copper, copper2, "#8F6435", "#FCFAF6"]
            fig = go.Figure()
            for k, ni in enumerate(numeric_idxs[:4]):
                fig.add_trace(go.Scatter(
                    x=[r[date_idx] for r in rows],
                    y=[r[ni] for r in rows],
                    name=columns[ni],
                    line=dict(color=colors[k % len(colors)], width=2),
                    mode="lines+markers",
                ))
            fig.update_layout(xaxis_title=columns[date_idx])

        elif chart_type == "scatter":
            fig = go.Figure(go.Scatter(
                x=[r[0] for r in rows],
                y=[r[1] for r in rows],
                mode="markers",
                marker=dict(color=copper, size=6),
            ))
            fig.update_layout(xaxis_title=columns[0], yaxis_title=columns[1])
        else:
            return None

        fig.update_layout(
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#FCFAF6", family="Inter, ui-sans-serif, sans-serif"),
            margin=dict(l=40, r=20, t=30, b=40),
            height=280,
            showlegend=len(fig.data) > 1,
        )
        return json.loads(plotly.io.to_json(fig))
    except Exception:
        return None


def build_grouped_distribution_chart(columns, rows, semantic: dict):
    """Build a dependency-free stacked chart for category-by-group results."""
    try:
        indices = {str(name).lower(): index for index, name in enumerate(columns)}
        group_index = indices["group_value"]
        category_index = indices["category_value"]
        count_index = indices["record_count"]
        pct_index = indices["pct_within_group"]
    except (KeyError, TypeError):
        return None

    groups = []
    categories = []
    values = {}
    category_totals = {}
    for row in rows:
        group = str(row[group_index])
        category = str(row[category_index])
        count = int(row[count_index] or 0)
        pct = float(row[pct_index] or 0)
        if group not in groups:
            groups.append(group)
        if category not in categories:
            categories.append(category)
        values[(group, category)] = (count, pct)
        category_totals[category] = category_totals.get(category, 0) + count
    categories.sort(key=lambda category: (-category_totals[category], category))
    palette = [
        "#B8864F", "#5B8DB8", "#6FA58D", "#C46F5B", "#8D75B8",
        "#D1A95D", "#5EAAA8", "#A16F7E", "#7E8C57", "#8B929A",
    ]
    traces = []
    for index, category in enumerate(categories):
        counts = [values.get((group, category), (0, 0))[0] for group in groups]
        percentages = [values.get((group, category), (0, 0))[1] for group in groups]
        traces.append({
            "type": "bar",
            "name": category,
            "x": groups,
            "y": counts,
            "customdata": percentages,
            "marker": {"color": palette[index % len(palette)]},
            "hovertemplate": (
                f"{semantic['category_column']}: {category}<br>"
                f"{semantic['group_column']}: %{{x}}<br>"
                "Records: %{y:,}<br>Within group: %{customdata:.1f}%<extra></extra>"
            ),
        })
    return {
        "data": traces,
        "layout": {
            "title": {
                "text": (
                    f"{semantic['category_column']} distribution by "
                    f"{semantic['group_column']}"
                ),
                "font": {"size": 15},
                "x": 0.01,
            },
            "barmode": "stack",
            "paper_bgcolor": "rgba(0,0,0,0)",
            "plot_bgcolor": "rgba(0,0,0,0)",
            "font": {"color": "#FCFAF6", "family": "Inter, ui-sans-serif, sans-serif"},
            "margin": {"l": 55, "r": 20, "t": 48, "b": 55},
            "height": 380,
            "xaxis": {"title": semantic["group_column"], "automargin": True},
            "yaxis": {"title": "Record count", "gridcolor": "rgba(255,255,255,.08)"},
            "legend": {"orientation": "h", "y": -0.28, "x": 0},
            "hovermode": "x unified",
        },
    }


def build_temporal_distribution_chart(columns, rows, semantic: dict):
    """Build a line chart with one series per category when categories exist."""
    try:
        indices = {str(name).lower(): index for index, name in enumerate(columns)}
        period_index = indices["period_value"]
        count_index = indices["record_count"]
    except (KeyError, TypeError):
        return None

    category_index = indices.get("category_value")
    periods = []
    categories = []
    values = {}
    for row in rows:
        period = str(row[period_index])
        category = str(row[category_index]) if category_index is not None else "Records"
        if period not in periods:
            periods.append(period)
        if category not in categories:
            categories.append(category)
        values[(period, category)] = int(row[count_index] or 0)

    palette = [
        "#B8864F", "#5B8DB8", "#6FA58D", "#C46F5B", "#8D75B8",
        "#D1A95D", "#5EAAA8", "#A16F7E", "#7E8C57", "#8B929A",
    ]
    traces = []
    for index, category in enumerate(categories):
        traces.append({
            "type": "scatter",
            "mode": "lines+markers",
            "name": category,
            "x": periods,
            "y": [values.get((period, category), 0) for period in periods],
            "line": {"color": palette[index % len(palette)], "width": 2},
            "hovertemplate": f"{category}<br>Period: %{{x}}<br>Records: %{{y:,}}<extra></extra>",
        })
    title = (
        f"{semantic['category_column']} by {semantic['period']}"
        if semantic.get("category_column")
        else f"Records by {semantic['period']}"
    )
    return {
        "data": traces,
        "layout": {
            "title": {"text": title, "font": {"size": 15}, "x": 0.01},
            "paper_bgcolor": "rgba(0,0,0,0)",
            "plot_bgcolor": "rgba(0,0,0,0)",
            "font": {"color": "#FCFAF6", "family": "Inter, ui-sans-serif, sans-serif"},
            "margin": {"l": 55, "r": 20, "t": 48, "b": 55},
            "height": 360,
            "xaxis": {"title": semantic["period"].title(), "automargin": True},
            "yaxis": {"title": "Records", "gridcolor": "rgba(138,155,173,0.18)"},
            "legend": {"orientation": "h", "y": 1.12, "x": 1, "xanchor": "right"},
        },
    }


def suggest_next_questions(result: dict, shortcut_name: str = None) -> list[str]:
    """Return deterministic, executable follow-ups for the response just shown."""
    response_type = result.get("type")
    if response_type == "error":
        return []
    if shortcut_name == "reason_by_jobtype":
        return [
            "Show the jobtype distribution",
            "Show the top removed parts",
            "Run a data integrity check",
        ]
    if shortcut_name == "jobtype_distribution":
        return [
            "Show me a yearly distribution of job types",
            "What's the spread across jobtype and removal reason?",
            "Show this as a pie chart",
        ]
    if shortcut_name == "jobtype_temporal":
        return [
            "Show me the overall distribution of jobtype",
            "What's the spread across jobtype and removal reason?",
            "Show this as a line chart",
        ]
    if result.get("semantic_temporal"):
        semantic = result["semantic_temporal"]
        category = semantic.get("category_column")
        questions = ["Show this as a line chart"]
        if category:
            questions.extend([
                f"Top 10 {category} by number of records",
                f"Show the overall distribution of {category}",
            ])
        else:
            questions.extend([
                "Give me a general overview of the active dataset",
                "Run a data integrity check",
            ])
        return questions[:3]
    if result.get("semantic_ranking"):
        semantic = result["semantic_ranking"]
        dimension = semantic.get("dimension_column")
        return [
            "Show this as a bar chart",
            f"Show me a yearly distribution of {dimension}",
            "Run a data integrity check",
        ]
    if response_type == "clarification":
        return [
            "Show me a yearly distribution of job types",
            "Show me a yearly distribution of component type",
            "Show me a yearly distribution of aircraft type",
        ]
    if response_type == "analytical" and result.get("rows"):
        return [
            "Show this as a bar chart",
            "Show this as a pie chart",
            "Run a data integrity check",
        ]
    if response_type == "overview":
        return [
            "Profile the active dataset",
            "Run a data integrity check",
            "What columns are available?",
        ]
    if response_type == "profile":
        return [
            "Give me a general overview of the active dataset",
            "Run a data integrity check",
            "What columns are available?",
        ]
    if response_type == "meta":
        return [
            "Give me a general summary of the datasets",
            "Profile the active dataset",
            "Run a data integrity check",
        ]
    if response_type == "domain":
        return [
            "Compare MTBF, MTBUR and removal rate",
            "How should aircraft utilization be calculated?",
            "Which fields are needed for a reliability analysis?",
        ]
    return [
        "What tables do you have access to?",
        "Profile the active dataset",
        "Give me a general overview of the active dataset",
    ]


def _run_scheduled_integrity(table_ref: str) -> None:
    """Run one allowlisted background review without changing the active table."""
    described = dataset_discovery.describe_table(table_ref)
    if not described.ok:
        raise RuntimeError(_error_text(described.error))
    metadata = described.value
    result = answer_integrity_check(table_ref, metadata=metadata)
    if result.get("type") == "error":
        raise RuntimeError(result.get("answer") or "Scheduled integrity review failed.")
    operational_store.record_integrity(metadata, result, origin="scheduled")


def _scheduler_status() -> dict:
    if integrity_scheduler is not None:
        status = integrity_scheduler.status()
    else:
        status = {
            "enabled": scheduler_config.enabled,
            "running": False,
            "interval_minutes": scheduler_config.interval_minutes,
            "table_count": len(scheduler_config.tables),
            "run_on_start": scheduler_config.run_on_start,
            "last_run": None,
            "last_error": None,
        }
    if scheduler_config_error:
        status["configuration_error"] = scheduler_config_error
    return status


# ── Routes ────────────────────────────────────────────────────────────────────
@app.errorhandler(Exception)
def handle_unexpected_error(error):
    """Keep every API failure JSON-shaped so the browser never parses HTML."""
    app.logger.exception("Unhandled application error")
    if request.path.startswith("/api/"):
        return jsonify({
            "ok": False,
            "error": {
                "category": "application",
                "message": "AvTrix encountered an unexpected application error.",
                "retryable": False,
            },
        }), 500
    return "Internal server error", 500


@app.route("/")
def index():
    return render_html()


@app.route("/api/status")
def api_status():
    # Check Ollama (fast, local — 5s timeout already in check_ollama)
    ollama_ok, ollama_info = check_ollama()

    # Check Databricks with a hard 8s timeout so the page never freezes
    db_ok = False
    db_err = None
    result = [False, "timeout"]

    def _try_db():
        outcome = db_client.healthcheck()
        result[0] = outcome.ok
        result[1] = None if outcome.ok else _error_text(outcome.error)

    t = threading.Thread(target=_try_db, daemon=True)
    t.start()
    t.join(timeout=8)
    if result[1] == "timeout":
        db_err = "Connection timed out — Databricks may be starting up"
        db_ok = False
    elif result[1]:
        db_err = result[1]
        db_ok = False
    else:
        db_ok = bool(result[0])

    return jsonify({
        "ollama": {"ok": ollama_ok, "info": ollama_info},
        "databricks": {"ok": db_ok, "error": db_err},
        "model": OLLAMA_MODEL,
        "table": active_table(),
        "dataset": dataset_registry.get().to_dict(include_columns=False),
        "discovered_tables": discovered_tables,
        "scheduler": _scheduler_status(),
    })


@app.route("/api/catalogs")
def api_catalogs():
    outcome = dataset_discovery.list_catalogs()
    if not outcome.ok:
        return jsonify({"ok": False, "error": _error_payload(outcome.error)}), 502
    return jsonify({"ok": True, "catalogs": outcome.value, "active": dataset_registry.get().catalog})


@app.route("/api/schemas")
def api_schemas():
    catalog = (request.args.get("catalog") or dataset_registry.get().catalog).strip()
    outcome = dataset_discovery.list_schemas(catalog)
    if not outcome.ok:
        status = 400 if outcome.error and outcome.error.category == "validation" else 502
        return jsonify({"ok": False, "error": _error_payload(outcome.error)}), status
    return jsonify({"ok": True, "catalog": catalog, "schemas": outcome.value,
                    "active": dataset_registry.get().schema if catalog == dataset_registry.get().catalog else None})


@app.route("/api/tables")
def api_tables():
    current = dataset_registry.get()
    catalog = (request.args.get("catalog") or current.catalog).strip()
    schema = (request.args.get("schema") or current.schema).strip()
    outcome = dataset_discovery.list_tables(catalog, schema)
    if not outcome.ok:
        status = 400 if outcome.error and outcome.error.category == "validation" else 502
        return jsonify({"ok": False, "error": _error_payload(outcome.error)}), status
    datasets = outcome.value
    return jsonify({
        "ok": True,
        "catalog": catalog,
        "schema": schema,
        "tables": [item["table_ref"] for item in datasets],
        "datasets": datasets,
        "active": current.table_ref,
    })


@app.route("/api/table", methods=["POST"])
def api_set_table():
    global discovered_tables
    data = request.get_json(silent=True) or {}
    table_ref = (data.get("table") or "").strip()
    if not table_ref:
        return jsonify({"ok": False, "error": {
            "category": "validation",
            "message": "No dataset was selected.",
            "retryable": False,
        }}), 400

    described = dataset_discovery.describe_table(table_ref)
    if not described.ok:
        status = 400 if described.error and described.error.category == "validation" else 502
        return jsonify({"ok": False, "error": _error_payload(described.error)}), status

    metadata = dataset_registry.activate(described.value)
    listed = dataset_discovery.list_tables(metadata.catalog, metadata.schema)
    if listed.ok:
        discovered_tables = [item["table_ref"] for item in listed.value]
    else:
        discovered_tables = [metadata.table_ref]
    conversation_history.clear()
    with last_query_context_lock:
        last_query_context.update(shortcut=None, question=None)
    return jsonify({
        "ok": True,
        "dataset": metadata.to_dict(),
        "active": metadata.table_ref,
        "profile_available": dataset_profiler.get_cached(metadata) is not None,
    })


@app.route("/api/profile", methods=["GET", "POST"])
def api_profile():
    """Read the matching cached profile or explicitly generate a live one."""
    current = dataset_registry.get()
    metadata, metadata_error = _live_profile_metadata(current.table_ref)
    if metadata_error:
        return jsonify({"ok": False, "error": _error_payload(metadata_error)}), 502

    if request.method == "GET":
        cached = dataset_profiler.get_cached(metadata)
        if cached is None:
            return jsonify({
                "ok": True,
                "available": False,
                "dataset": metadata.to_dict(include_columns=False),
            })
        detail = request.args.get("detail", "").lower() in {"1", "true", "yes"}
        return jsonify({
            "ok": True,
            "available": True,
            "cached": True,
            "profile": cached if detail else profile_summary(cached),
        })

    data = request.get_json(silent=True) or {}
    refresh = bool(data.get("refresh", False))
    detail = bool(data.get("detail", False))
    outcome = dataset_profiler.get_or_create(metadata, refresh=refresh)
    if not outcome.ok:
        return jsonify({"ok": False, "error": _error_payload(outcome.error)}), 502
    return jsonify({
        "ok": True,
        "available": True,
        "cached": outcome.cached,
        "profile": outcome.profile if detail else profile_summary(outcome.profile),
    })


@app.route("/api/integrity-history")
def api_integrity_history():
    """Return bounded summary-only integrity history for the active dataset."""
    current = dataset_registry.get()
    try:
        limit = max(1, min(int(request.args.get("limit", "20")), 100))
    except ValueError:
        limit = 20
    records = operational_store.list_integrity_history(current.table_ref, limit=limit)
    return jsonify({
        "ok": True,
        "dataset": current.to_dict(include_columns=False),
        "latest": records[0] if records else None,
        "history": records,
        "retention_days": HISTORY_RETENTION_DAYS,
        "raw_result_rows_stored": False,
    })


@app.route("/api/methodology", methods=["POST"])
def api_methodology():
    """Explicitly lock a read-only method; query results are never persisted."""
    data = request.get_json(silent=True) or {}
    current = dataset_registry.get()
    client_dataset = data.get("dataset") or {}
    client_table = client_dataset.get("table_ref") if isinstance(client_dataset, dict) else None
    if client_table and client_table != current.table_ref:
        return jsonify({"ok": False, "error": {
            "category": "conflict",
            "message": "The active dataset changed. Run the analysis again before locking it.",
            "retryable": False,
        }}), 409
    provenance = data.get("provenance") if isinstance(data.get("provenance"), dict) else {}
    fingerprint = provenance.get("schema_fingerprint")
    if fingerprint and fingerprint != current.schema_fingerprint:
        return jsonify({"ok": False, "error": {
            "category": "conflict",
            "message": "The live schema fingerprint changed. Run the analysis again before locking it.",
            "retryable": False,
        }}), 409
    sql = str(data.get("sql") or "").strip()
    sql_statements = data.get("sql_statements") if isinstance(data.get("sql_statements"), dict) else {}
    if not sql and not sql_statements:
        return jsonify({"ok": False, "error": {
            "category": "validation",
            "message": "Only a response with read-only SQL can be locked as a methodology.",
            "retryable": False,
        }}), 400
    try:
        saved = operational_store.save_methodology(
            metadata=current,
            question=str(data.get("question") or ""),
            intent=str(data.get("intent") or "analytical"),
            sql=sql,
            sql_statements=sql_statements,
            provenance=provenance,
            integrity_plan=data.get("integrity_plan") if isinstance(data.get("integrity_plan"), dict) else None,
        )
    except ValueError as exc:
        return jsonify({"ok": False, "error": {
            "category": "validation", "message": str(exc), "retryable": False,
        }}), 400
    return jsonify({"ok": True, "methodology": {
        "saved_at": saved["saved_at"],
        "filename": saved["filename"],
        "result_rows_stored": False,
    }})


@app.route("/api/shortcuts")
def api_shortcuts():
    metadata = dataset_registry.get()
    return jsonify({
        name: {"description": q["description"]}
        for name, q in NAMED_QUERIES.items()
        if not missing_shortcut_columns(q, metadata)
    })


@app.route("/api/models")
def api_models():
    """List installed Ollama models (via the local Ollama /api/tags)."""
    ok, info = check_ollama()
    models = info if ok and isinstance(info, list) else []
    return jsonify({"ok": True, "models": models, "active": OLLAMA_MODEL})


@app.route("/api/model", methods=["POST"])
def api_set_model():
    """Switch the active Ollama model used for SQL generation and narratives."""
    global OLLAMA_MODEL
    data = request.get_json(silent=True) or {}
    name = (data.get("model") or "").strip()
    if not name:
        return jsonify({"ok": False, "error": {
            "category": "validation", "message": "No model was provided.", "retryable": False,
        }}), 400
    ok, info = check_ollama()
    installed = info if ok and isinstance(info, list) else []
    # exact or unique-prefix match
    exact = [m for m in installed if m == name]
    partial = [m for m in installed if name in m]
    if exact:
        OLLAMA_MODEL = exact[0]
    elif len(partial) == 1:
        OLLAMA_MODEL = partial[0]
    elif len(partial) > 1:
        return jsonify({"ok": False, "error": {
            "category": "validation",
            "message": f"The model name is ambiguous: {', '.join(partial)}",
            "retryable": False,
        }}), 400
    else:
        OLLAMA_MODEL = name  # allow; user may pull it
    return jsonify({"ok": True, "model": OLLAMA_MODEL})


@app.route("/api/query", methods=["POST"])
def api_query():
    data = request.get_json(silent=True) or {}
    question = (data.get("question") or "").strip()
    shortcut = data.get("shortcut") or None
    resolved_shortcut = shortcut
    request_dataset = dataset_registry.get()
    request_table = request_dataset.table_ref

    if not question and not shortcut:
        return jsonify({
            "ok": False,
            "error": {
                "category": "validation",
                "message": "No question was provided.",
                "retryable": False,
            },
        }), 400

    unresolved_context_repeat = False
    if not shortcut and _is_contextual_repeat(question):
        with last_query_context_lock:
            previous_shortcut = last_query_context.get("shortcut")
        if previous_shortcut in NAMED_QUERIES:
            shortcut = previous_shortcut
            resolved_shortcut = previous_shortcut
        else:
            unresolved_context_repeat = True

    display_question = question
    if shortcut and shortcut in NAMED_QUERIES:
        display_question = NAMED_QUERIES[shortcut]["description"]
    elif shortcut == "integrity_check":
        display_question = "Data integrity check"

    # Add to conversation history
    conversation_history.append({
        "role": "user",
        "content": display_question,
        "timestamp": datetime.now().strftime("%H:%M"),
    })

    # Route the intent
    if unresolved_context_repeat:
        result = {
            "type": "clarification",
            "answer": (
                "I do not have a previous trusted distribution to repeat in this conversation. "
                "Please name the field, for example: “show me the overall distribution of jobtype.”"
            ),
            "sql": None,
            "columns": None,
            "rows": None,
        }
    elif not shortcut and _is_ambiguous_year_type_question(question):
        result = answer_year_type_clarification()
    elif not shortcut and _is_reliability_glossary_question(question):
        result = answer_reliability_glossary()
    elif not shortcut and _is_guardrails_question(question):
        result = answer_guardrails()
    elif not shortcut and _is_data_availability_question(question):
        display_question = "Available data"
        result = answer_dataset_portfolio()
    elif not shortcut and _is_capabilities_question(question):
        result = answer_capabilities()
    elif not shortcut and _is_multi_dataset_overview(question):
        display_question = "General summary of available datasets"
        result = answer_dataset_portfolio()
    elif not shortcut and _is_profile_question(question):
        display_question = f"Dataset profile — {request_table}"
        refresh_profile = bool(re.search(r"\b(refresh|rebuild|regenerate|new|fresh)\b", question, re.I))
        result = answer_profile(request_table, refresh=refresh_profile)
    elif shortcut == "integrity_check" or (not shortcut and _is_integrity_question(question)):
        resolved_shortcut = "integrity_check"
        display_question = "Data integrity check"
        result = answer_integrity_check(request_table, metadata=request_dataset)
    elif not shortcut and parse_temporal_request(question):
        result = answer_semantic_temporal(question, table_ref=request_table)
    elif not shortcut and parse_distribution_request(question):
        result = answer_semantic_distribution(question, table_ref=request_table)
    elif not shortcut and parse_ranking_request(question):
        result = answer_semantic_ranking(question, table_ref=request_table)
    elif shortcut == "dataset_overview" or (not shortcut and _match_shortcut_by_intent(question) == "dataset_overview"):
        resolved_shortcut = "dataset_overview"
        display_question = f"General overview — {request_table}"
        result = answer_overview(request_table)
    elif shortcut:
        result = answer_analytical(
            display_question,
            shortcut_name=shortcut,
            table_ref=request_table,
            metadata=request_dataset,
        )
    else:
        # Check if the free-text question matches any other named shortcut by intent
        auto_shortcut = _match_shortcut_by_intent(question)
        if (
            auto_shortcut
            and auto_shortcut in NAMED_QUERIES
            and not missing_shortcut_columns(NAMED_QUERIES[auto_shortcut], request_dataset)
        ):
            resolved_shortcut = auto_shortcut
            display_question = NAMED_QUERIES[auto_shortcut]["description"]
            result = answer_analytical(
                display_question,
                shortcut_name=auto_shortcut,
                table_ref=request_table,
                metadata=request_dataset,
            )
        else:
            intent = classify_intent(question)
            if intent == "meta":
                result = answer_meta(question)
            elif intent == "domain":
                result = answer_domain(question)
            else:
                result = answer_analytical(
                    question,
                    table_ref=request_table,
                    metadata=request_dataset,
                )

    integrity_record = None
    if result.get("type") == "integrity":
        try:
            integrity_record = operational_store.record_integrity(
                request_dataset, result, origin="interactive"
            )
        except OSError:
            app.logger.exception("Could not save the local integrity summary")

    # Build chart only for analytical results — integrity/overview/meta tables
    # are not meaningfully chartable.
    chart = None
    if result.get("type") == "analytical" and result.get("columns") and result.get("rows"):
        if result.get("visual_story") == "reason_by_jobtype":
            chart = build_reason_jobtype_story_chart(result["columns"], result["rows"])
        elif result.get("semantic_distribution"):
            chart = build_grouped_distribution_chart(
                result["columns"], result["rows"], result["semantic_distribution"]
            )
        elif result.get("semantic_temporal"):
            chart = build_temporal_distribution_chart(
                result["columns"], result["rows"], result["semantic_temporal"]
            )
        else:
            chart_type = detect_chart_type(result["columns"], result["rows"])
            if chart_type:
                chart = build_chart(result["columns"], result["rows"], chart_type)

    # Summarise rows for JSON (cap at 500 for browser)
    rows_payload = result.get("rows") or []
    if len(rows_payload) > 500:
        rows_payload = rows_payload[:500]

    response_error = result.get("error")
    if result.get("type") == "error" and not response_error:
        response_error = {
            "category": "query",
            "message": result.get("answer") or "The query could not be completed.",
            "retryable": False,
        }

    response = {
        "ok": result.get("type") != "error",
        "question": display_question,
        "intent": result["type"],
        "answer": result["answer"],
        "error": response_error,
        "sql": result.get("sql"),
        "sql_statements": result.get("sql_statements") or {},
        "columns": result.get("columns"),
        "rows": rows_payload,
        "total_rows": len(result.get("rows") or []),
        "chart": chart,
        "charts": result.get("charts") or [],
        "suggested_questions": suggest_next_questions(result, resolved_shortcut),
        "shortcut": resolved_shortcut,
        "dataset": request_dataset.to_dict(include_columns=False),
        "provenance": result.get("provenance"),
        "integrity_details": result.get("integrity_details") or [],
        "integrity_plan": result.get("integrity_plan"),
        "integrity_record": integrity_record,
        "timestamp": datetime.now().strftime("%H:%M"),
    }

    conversation_history.append({
        "role": "assistant",
        "content": result["answer"],
        "timestamp": response["timestamp"],
    })

    if result.get("type") != "error" and resolved_shortcut in NAMED_QUERIES:
        with last_query_context_lock:
            last_query_context.update(
                shortcut=resolved_shortcut,
                question=display_question,
            )

    return jsonify(response)


@app.route("/api/clear", methods=["POST"])
def api_clear():
    conversation_history.clear()
    with last_query_context_lock:
        last_query_context.update(shortcut=None, question=None)
    return jsonify({"ok": True})


# ── HTML Template ─────────────────────────────────────────────────────────────
def render_html():
    shortcuts_json = json.dumps({
        name: q["description"] for name, q in NAMED_QUERIES.items()
    })
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AvTrix Fleet Intelligence</title>
<script src="https://cdn.jsdelivr.net/npm/plotly.js-dist@2.27.0/plotly.min.js"></script>
<style>
:root {{
  --bg:        #0F1318;
  --panel:     #1A1F25;
  --panel2:    #232A33;
  --panel3:    #2A3340;
  --line:      #2E3742;
  --text:      #E8E4DC;
  --muted:     #8A9BAD;
  --copper:    #B8864F;
  --copper-d:  #8F6435;
  --copper-l:  #CBA36A;
  --cream:     #FCFAF6;
  --good:      #4CAF7D;
  --warn:      #E8A844;
  --bad:       #E05454;
  --accent:    #B8864F;
}}

*, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}
html, body {{ height: 100%; background: var(--bg); color: var(--text); font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; font-size: 14px; }}

/* ── Layout ── */
.app {{ display: grid; grid-template-columns: 220px minmax(0,1fr) 260px; height: 100vh; overflow: hidden; }}

/* ── Sidebar ── */
.sidebar {{
  background: var(--panel);
  border-right: 1px solid var(--line);
  display: flex; flex-direction: column; gap: 12px;
  padding: 16px 12px; overflow-y: auto;
}}
.brand {{ display:flex; align-items:center; gap:10px; padding: 4px 6px; font-weight:600; }}
.logo {{
  width:32px; height:32px; border-radius:9px;
  background: linear-gradient(135deg, var(--copper) 0%, var(--copper-d) 100%);
  display:grid; place-items:center; font-size:16px; flex:0 0 auto;
}}
.new-btn {{
  display:flex; align-items:center; justify-content:center; gap:8px;
  background: var(--copper); color: var(--cream); border:none; border-radius:9px;
  padding: 10px; font-weight:600; cursor:pointer; font-size:14px; width:100%;
}}
.new-btn:hover {{ background: var(--copper-l); }}
.side-label {{ color:var(--muted); text-transform:uppercase; letter-spacing:.08em; font-size:11px; padding:0 6px; margin-top:4px; }}
.thread-list {{ display:grid; gap:3px; }}
.thread-btn {{
  text-align:left; padding:9px 10px; border:none; border-radius:7px;
  background:transparent; color:var(--muted); cursor:pointer;
  overflow:hidden; text-overflow:ellipsis; white-space:nowrap; width:100%;
  font-size:13px;
}}
.thread-btn.active, .thread-btn:hover {{ background:var(--panel3); color:var(--text); }}
.sidebar-foot {{ margin-top:auto; border-top:1px solid var(--line); padding-top:12px; display:grid; gap:8px; }}
.runtime {{ display:flex; align-items:center; gap:8px; color:var(--muted); font-size:12px; padding:0 6px; }}
.dot {{ width:8px; height:8px; border-radius:50%; background:var(--good); flex:0 0 auto; }}
.dot.bad {{ background: var(--bad); }}
.dot.warn {{ background: var(--warn); }}

/* ── Mode switch ── */
.mode-switch {{ display:inline-flex; align-items:center; gap:3px; padding:3px; border:1px solid var(--line); border-radius:10px; background:var(--panel2); }}
.mode-btn {{
  min-height:30px; padding:4px 12px; border:none; border-radius:7px;
  background:transparent; color:var(--muted); cursor:pointer; font-size:13px;
}}
.mode-btn.active {{ background:var(--panel3); color:var(--text); }}

/* ── Topbar ── */
.topbar {{
  border-bottom:1px solid var(--line); padding:12px 20px;
  display:flex; align-items:center; gap:16px; flex-wrap:wrap;
}}
.topbar-title {{ flex:1; }}
.topbar-title strong {{ display:block; font-size:15px; }}
.topbar-title span {{ color:var(--muted); font-size:12px; }}
.status-row {{ display:flex; gap:8px; flex-wrap:wrap; }}
.pill {{
  display:inline-flex; align-items:center; gap:6px;
  padding:4px 10px; border-radius:20px; font-size:12px;
  background:var(--panel2); border:1px solid var(--line); color:var(--muted);
}}
.pill.ok {{ border-color: var(--good); color: var(--good); }}
.pill.warn {{ border-color: var(--warn); color: var(--warn); }}

/* ── Main chat panel ── */
.main {{ display:flex; flex-direction:column; min-width:0; min-height:0; height:100vh; background:var(--bg); }}
.chat {{ flex:1; min-height:0; overflow-y:auto; padding:24px 28px; display:flex; flex-direction:column; gap:20px; }}

.welcome {{ text-align:center; padding:40px 20px; color:var(--muted); }}
.welcome h2 {{ font-size:22px; color:var(--text); margin-bottom:10px; }}
.welcome p {{ max-width:480px; margin:0 auto; line-height:1.6; }}

.suggestions {{ display:flex; flex-wrap:wrap; gap:8px; justify-content:center; margin-top:20px; }}
.suggestion-btn {{
  padding:8px 14px; border-radius:20px; border:1px solid var(--copper-d);
  background:transparent; color:var(--copper-l); cursor:pointer; font-size:13px;
}}
.suggestion-btn:hover {{ background:var(--panel2); }}

.prompt-shelf {{
  flex:0 0 auto; padding:10px 18px 8px; border-top:1px solid var(--line);
  background:color-mix(in srgb,var(--panel) 82%,transparent);
}}
.prompt-shelf-label {{
  display:block; margin-bottom:7px; color:var(--muted); font-size:11px;
  font-weight:700; letter-spacing:.08em; text-transform:uppercase;
}}
.prompt-chips {{ display:flex; gap:7px; overflow-x:auto; padding-bottom:3px; scrollbar-width:thin; }}
.prompt-chip, .next-question-btn {{
  flex:0 0 auto; padding:7px 11px; border-radius:16px; border:1px solid var(--line);
  background:var(--panel2); color:var(--text); cursor:pointer; font-size:12px;
}}
.prompt-chip:hover, .next-question-btn:hover {{ border-color:var(--copper); color:var(--copper-l); }}
.next-questions {{ margin-top:14px; padding-top:12px; border-top:1px solid var(--line); }}
.next-questions-label {{ color:var(--muted); font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.07em; }}
.next-questions-list {{ display:flex; flex-wrap:wrap; gap:7px; margin-top:8px; }}

/* ── Model switcher ── */
.model-switch-row {{ display:flex; align-items:center; gap:8px; margin:8px 0; font-size:12px; color:var(--muted); }}
.model-switch-row label {{ flex:0 0 auto; }}
.model-switch-row select {{
  flex:1; min-width:0; background:var(--panel2); color:var(--text);
  border:1px solid var(--line); border-radius:6px; padding:4px 6px; font-size:12px; cursor:pointer;
}}

/* ── Messages ── */
.message {{ display:flex; gap:12px; max-width:100%; }}
.message.user {{ flex-direction:row-reverse; }}
.message.user .bubble {{ background:var(--copper); color:var(--cream); border-radius:18px 4px 18px 18px; }}
.message .bubble {{
  background:var(--panel); border-radius:4px 18px 18px 18px;
  padding:14px 18px; max-width:82%; line-height:1.6;
}}
.message.user .bubble {{ max-width:72%; }}
.avatar {{
  width:30px; height:30px; border-radius:50%;
  background: linear-gradient(135deg, var(--copper) 0%, var(--copper-d) 100%);
  display:grid; place-items:center; font-size:14px; flex:0 0 auto; margin-top:4px;
}}

.answer-lead {{ font-weight:400; margin-bottom:8px; color:var(--text); line-height:1.62; }}
.answer-lead h2 {{
  margin:20px 0 8px; color:var(--cream); font-size:17px; line-height:1.3;
  font-weight:650; letter-spacing:-.01em;
}}
.answer-lead h2:first-child {{ margin-top:0; }}
.answer-lead h3 {{ margin:16px 0 6px; color:var(--cream); font-size:14px; font-weight:650; }}
.answer-lead p {{ margin:0 0 11px; }}
.answer-lead ul, .answer-lead ol {{ margin:5px 0 13px 20px; padding:0; }}
.answer-lead li {{ margin:5px 0; padding-left:2px; }}
.answer-lead strong {{ color:var(--cream); font-weight:650; }}
.answer-lead hr {{ border:0; border-top:1px solid var(--line); margin:16px 0; }}
.answer-table-wrap {{ overflow-x:auto; margin:10px 0 15px; }}
.answer-table {{ width:100%; border-collapse:collapse; font-size:12px; line-height:1.45; }}
.answer-table th {{
  padding:8px 10px; text-align:left; color:var(--cream); background:var(--panel2);
  border:1px solid var(--line); font-weight:650; white-space:nowrap;
}}
.answer-table td {{ padding:8px 10px; vertical-align:top; border:1px solid var(--line); color:var(--text); }}
.answer-meta {{
  display:flex; align-items:center; gap:12px; margin-top:12px;
  font-size:12px; color:var(--muted);
}}
.sql-toggle {{ background:none; border:none; color:var(--copper-l); cursor:pointer; font-size:12px; text-decoration:underline; }}
.sql-block {{
  display:none; margin-top:10px; background:var(--panel2); border-radius:8px;
  padding:12px 14px; font-family:monospace; font-size:12px; white-space:pre-wrap;
  word-break:break-all; color:var(--cream); border:1px solid var(--line);
}}
.sql-block.open {{ display:block; }}

/* ── Result tabs ── */
.result-tabs-row {{ display:flex; gap:4px; margin-top:14px; border-bottom:1px solid var(--line); padding-bottom:6px; overflow-x:auto; }}
.result-tab-btn {{ background:none; border:none; color:var(--muted); cursor:pointer; padding:4px 10px; border-radius:6px; font-size:12px; }}
.result-tab-btn.active {{ color:var(--text); background:var(--panel2); }}
.result-panel {{ margin-top:10px; }}
.result-panel[hidden] {{ display:none; }}

/* ── Mini table ── */
.mini-table {{ width:100%; border-collapse:collapse; font-size:13px; }}
.mini-table th {{ text-align:left; padding:7px 10px; color:var(--muted); border-bottom:1px solid var(--line); font-weight:500; }}
.mini-table td {{ padding:7px 10px; border-bottom:1px solid var(--line); vertical-align:top; }}
.mini-table tr:last-child td {{ border-bottom:none; }}
.mini-table tr:hover td {{ background:var(--panel2); }}
.row-count {{ color:var(--muted); font-size:12px; margin-top:6px; }}

/* ── Chart area ── */
.chart-wrap {{ margin-top:12px; background:var(--panel); border-radius:10px; padding:16px; border:1px solid var(--line); overflow:hidden; }}

/* ── Analyst split layout ── */
.analyst-body {{ display:grid; grid-template-columns:minmax(0,1fr) minmax(0,1fr); flex:1; min-height:0; overflow:hidden; }}
.analyst-chat {{ border-right:1px solid var(--line); display:flex; flex-direction:column; }}
.analyst-canvas {{ display:flex; flex-direction:column; background:var(--panel); }}
.canvas-head {{ padding:16px 20px; border-bottom:1px solid var(--line); }}
.canvas-head h2 {{ font-size:15px; font-weight:600; }}
.canvas-head p {{ color:var(--muted); font-size:12px; margin-top:2px; }}
.canvas-body {{ flex:1; overflow-y:auto; padding:16px 20px; display:flex; flex-direction:column; gap:16px; }}

/* ── Composer ── */
.composer {{ border-top:1px solid var(--line); padding:16px 20px; background:var(--panel); }}
.composer textarea {{
  width:100%; background:var(--panel2); border:1px solid var(--line);
  border-radius:10px; color:var(--text); padding:12px 14px;
  resize:none; outline:none; font:inherit; line-height:1.5;
  min-height:80px;
}}
.composer textarea:focus {{ border-color:var(--copper-d); }}
.compose-foot {{ display:flex; align-items:center; justify-content:space-between; margin-top:8px; }}
.send-btn {{
  background: var(--copper); color: var(--cream); border:none; border-radius:9px;
  padding:9px 20px; font-weight:600; cursor:pointer; font-size:14px;
}}
.send-btn:hover {{ background:var(--copper-l); }}
.send-btn:disabled {{ opacity:0.5; cursor:not-allowed; }}
.compose-actions {{ display:flex; align-items:center; gap:8px; }}
.stop-btn {{
  background:transparent; color:#F19A91; border:1px solid #8D4541; border-radius:9px;
  padding:8px 14px; font-weight:600; cursor:pointer; font-size:13px;
}}
.stop-btn:hover {{ background:rgba(141,69,65,.18); }}
.stop-btn[hidden] {{ display:none; }}

/* ── Context panel ── */
.context-panel {{ background:var(--panel); border-left:1px solid var(--line); padding:20px 16px; overflow-y:auto; display:flex; flex-direction:column; gap:20px; }}
.context-panel h3 {{ font-size:13px; font-weight:600; text-transform:uppercase; letter-spacing:.06em; color:var(--muted); }}
.context-section {{ display:grid; gap:8px; }}
.context-label {{ font-size:11px; color:var(--muted); text-transform:uppercase; letter-spacing:.06em; }}
.context-value {{ font-size:13px; font-weight:500; color:var(--cream); }}
.tag-row {{ display:flex; flex-wrap:wrap; gap:6px; }}
.tag {{ padding:3px 8px; border-radius:12px; border:1px solid var(--line); font-size:11px; color:var(--muted); }}
.security-list {{ display:grid; gap:6px; }}
.security-item {{ display:flex; align-items:center; gap:8px; font-size:12px; color:var(--muted); }}
.profile-card {{
  display:grid; gap:7px; padding:10px; border:1px solid var(--line);
  border-radius:8px; background:var(--panel2); font-size:11px; color:var(--muted);
}}
.profile-card strong {{ color:var(--text); font-size:12px; }}
.profile-action {{
  width:100%; padding:7px 9px; border-radius:7px; border:1px solid var(--copper-d);
  background:transparent; color:var(--copper-l); cursor:pointer; font-size:11px;
}}
.profile-action:hover {{ background:color-mix(in srgb,var(--copper) 12%,transparent); }}
.profile-action:disabled {{ opacity:.55; cursor:wait; }}
.integrity-status {{ font-size:11px; color:var(--muted); line-height:1.45; }}
.result-actions {{ display:flex; flex-wrap:wrap; gap:7px; margin-top:12px; }}
.result-action {{
  padding:6px 10px; border-radius:7px; border:1px solid var(--line);
  background:transparent; color:var(--muted); cursor:pointer; font-size:11px;
}}
.result-action:hover {{ color:var(--text); border-color:var(--copper-d); background:var(--panel2); }}
.result-action:disabled {{ opacity:.55; cursor:wait; }}

/* ── Shortcuts panel (in context) ── */
.shortcuts-list {{ display:grid; gap:4px; }}
.shortcut-btn {{
  text-align:left; padding:8px 10px; border:1px solid var(--line);
  border-radius:8px; background:transparent; color:var(--muted);
  cursor:pointer; font-size:12px; line-height:1.4;
}}
.shortcut-btn:hover {{ background:var(--panel2); color:var(--text); border-color:var(--copper-d); }}

/* ── Table picker ── */
.table-picker {{ display:grid; gap:4px; }}
.dataset-select {{
  width:100%; margin:4px 0 8px; padding:7px 8px; border-radius:6px;
  border:1px solid var(--line); background:var(--panel2); color:var(--text);
  font-size:12px;
}}
.table-item {{
  display:flex; align-items:center; gap:8px; padding:7px 10px;
  border-radius:7px; font-size:12px; font-family:monospace;
  color:var(--muted); cursor:pointer; user-select:none;
}}
.table-item.active {{ color:var(--copper-l); }}
.table-item:hover {{ background:var(--panel2); color:var(--text); }}
.table-dot {{ width:6px; height:6px; border-radius:50%; background:var(--line); flex:0 0 auto; }}
.table-item.active .table-dot {{ background:var(--copper); }}

/* ── Thinking indicator ── */
.thinking {{ display:flex; gap:12px; align-items:flex-start; }}
.thinking-dots span {{
  display:inline-block; width:6px; height:6px; border-radius:50%;
  background:var(--copper); animation:blink 1.2s infinite;
}}
.thinking-dots span:nth-child(2) {{ animation-delay:.2s; }}
.thinking-dots span:nth-child(3) {{ animation-delay:.4s; }}
@keyframes blink {{ 0%,80%,100%{{opacity:.2}} 40%{{opacity:1}} }}

/* ── Error state ── */
.error-bubble {{ background:color-mix(in srgb,var(--bad) 15%,var(--panel)); border:1px solid var(--bad); border-radius:10px; padding:12px 16px; color:var(--bad); font-size:13px; }}

/* ── Analyst canvas sections ── */
.canvas-chart-panel {{ background:var(--panel2); border-radius:10px; padding:16px; border:1px solid var(--line); }}
.canvas-result-panel {{ background:var(--panel2); border-radius:10px; border:1px solid var(--line); }}
.canvas-result-head {{ padding:12px 14px; border-bottom:1px solid var(--line); display:flex; gap:6px; overflow-x:auto; }}

/* ── Scrollbars ── */
::-webkit-scrollbar {{ width:6px; height:6px; }}
::-webkit-scrollbar-track {{ background:transparent; }}
::-webkit-scrollbar-thumb {{ background:var(--line); border-radius:3px; }}
::-webkit-scrollbar-thumb:hover {{ background:var(--muted); }}
</style>
</head>
<body>

<div class="app" id="app">

  <!-- ── Sidebar ── -->
  <aside class="sidebar">
    <div class="brand">
      <div class="logo">✦</div>
      <span>AvTrix AI</span>
    </div>

    <button class="new-btn" onclick="newConversation()">＋ New conversation</button>

    <div class="side-label">Interface</div>
    <div class="mode-switch">
      <button class="mode-btn active" id="mode-focused" onclick="setMode('focused')">Focused</button>
      <button class="mode-btn" id="mode-analyst" onclick="setMode('analyst')">Analyst</button>
    </div>

    <div class="side-label" style="margin-top:8px">Recent</div>
    <div class="thread-list" id="thread-list">
      <!-- populated dynamically -->
    </div>

    <div class="sidebar-foot">
      <div class="runtime" id="ollama-status">
        <span class="dot warn" id="ollama-dot"></span>
        <span id="ollama-label">Checking Ollama…</span>
      </div>
      <div class="model-switch-row">
        <label for="model-select">Model</label>
        <select id="model-select" onchange="switchModel(this.value)" title="Switch the local model used for SQL and narratives">
          <option>…</option>
        </select>
      </div>
      <div class="runtime" id="db-status">
        <span class="dot warn" id="db-dot"></span>
        <span id="db-label">Checking Databricks…</span>
      </div>
    </div>
  </aside>

  <!-- ── Main area (focused mode) ── -->
  <main class="main" id="focused-main">
    <header class="topbar">
      <div class="topbar-title">
        <strong id="convo-title">Fleet Intelligence</strong>
        <span>Powered by local AI + Databricks</span>
      </div>
      <div class="status-row" id="status-pills">
        <span class="pill" id="pill-model">⏳ Loading…</span>
        <span class="pill" id="pill-db">⏳ Databricks</span>
      </div>
    </header>

    <div class="chat" id="chat-area">
      <div class="welcome" id="welcome-msg">
        <h2>Ask your fleet data</h2>
        <p>I'll answer schema questions instantly, aviation knowledge from memory, and complex analytics by querying Databricks — all locally, no data leaves your machine.</p>
      </div>
    </div>

    <div class="prompt-shelf">
      <span class="prompt-shelf-label">Try asking</span>
      <div class="prompt-chips">
        <button class="prompt-chip" onclick="fillPrompt('What data is available?')">Available data</button>
        <button class="prompt-chip" onclick="fillPrompt('Profile the active dataset')">Profile active dataset</button>
        <button class="prompt-chip" onclick="fillPrompt('Run a data integrity check')">Data integrity</button>
        <button class="prompt-chip" onclick="fillPrompt(&quot;What's the spread across jobtype and removal reason?&quot;)">Job type × removal reason</button>
        <button class="prompt-chip" onclick="fillPrompt('What is MTBUR and why does it matter?')">Explain MTBUR</button>
      </div>
    </div>

    <div class="composer">
      <label for="main-prompt" style="display:none">Ask a question</label>
      <textarea id="main-prompt" placeholder="Ask about your fleet data, schema, or aviation reliability…" rows="3" onkeydown="handleKey(event)"></textarea>
      <div class="compose-foot">
        <span style="color:var(--muted);font-size:12px" id="active-table-label"></span>
        <div class="compose-actions">
          <button class="stop-btn" id="stop-btn" onclick="stopActiveRequest()" hidden>Stop ■</button>
          <button class="send-btn" id="send-btn" onclick="sendQuestion()">Send ↑</button>
        </div>
      </div>
    </div>
  </main>

  <!-- ── Analyst main (split view) ── -->
  <main class="main" id="analyst-main" style="display:none">
    <header class="topbar">
      <div class="topbar-title">
        <strong>Analyst Workspace</strong>
        <span>Chat + live canvas</span>
      </div>
      <div class="status-row" id="analyst-status-pills">
        <span class="pill" id="analyst-pill-model">⏳ Loading…</span>
        <span class="pill" id="analyst-pill-db">⏳ Databricks</span>
      </div>
    </header>
    <div class="analyst-body">
      <div class="analyst-chat main">
        <div class="chat" id="analyst-chat-area">
          <div class="welcome">
            <h2>Analyst mode</h2>
            <p>Results appear in the canvas panel on the right.</p>
          </div>
        </div>
        <div class="prompt-shelf">
          <span class="prompt-shelf-label">Try asking</span>
          <div class="prompt-chips">
            <button class="prompt-chip" onclick="fillPrompt('What data is available?')">Available data</button>
            <button class="prompt-chip" onclick="fillPrompt('Profile the active dataset')">Profile active dataset</button>
            <button class="prompt-chip" onclick="fillPrompt('Run a data integrity check')">Data integrity</button>
            <button class="prompt-chip" onclick="fillPrompt(&quot;What's the spread across jobtype and removal reason?&quot;)">Job type × removal reason</button>
          </div>
        </div>
        <div class="composer">
          <textarea id="analyst-prompt" placeholder="Continue the analysis…" rows="3" onkeydown="handleAnalystKey(event)"></textarea>
          <div class="compose-foot">
            <span></span>
            <div class="compose-actions">
              <button class="stop-btn" id="analyst-stop-btn" onclick="stopActiveRequest()" hidden>Stop ■</button>
              <button class="send-btn" id="analyst-send-btn" onclick="sendAnalystQuestion()">Send ↑</button>
            </div>
          </div>
        </div>
      </div>
      <div class="analyst-canvas">
        <div class="canvas-head">
          <h2 id="canvas-title">Canvas</h2>
          <p id="canvas-sub">Results will appear here</p>
        </div>
        <div class="canvas-body" id="canvas-body">
          <p style="color:var(--muted);font-size:13px">Send a question to see the chart and data here.</p>
        </div>
      </div>
    </div>
  </main>

  <!-- ── Context panel ── -->
  <aside class="context-panel">
    <h3>Context</h3>

    <div class="context-section">
      <div class="context-label">Catalog</div>
      <select class="dataset-select" id="catalog-select" onchange="changeCatalog(this.value)">
        <option>Loading…</option>
      </select>
      <div class="context-label">Schema</div>
      <select class="dataset-select" id="schema-select" onchange="changeSchema(this.value)">
        <option>Loading…</option>
      </select>
      <div class="context-label">Active table</div>
      <div class="context-value" id="ctx-table" style="font-size:12px;font-family:monospace;word-break:break-all">–</div>
      <div class="table-picker" id="table-picker">
        <!-- populated from /api/tables -->
      </div>
    </div>

    <div class="context-section">
      <div class="context-label">Dataset profile</div>
      <div class="profile-card" id="profile-card">
        <strong id="profile-title">Not profiled</strong>
        <span id="profile-detail">Generate a local statistical profile for this dataset.</span>
        <button class="profile-action" id="profile-action" onclick="buildDatasetProfile()">Generate profile</button>
      </div>
    </div>

    <div class="context-section">
      <div class="context-label">Integrity review</div>
      <div class="profile-card" id="integrity-card">
        <strong id="integrity-title">Not checked</strong>
        <span class="integrity-status" id="integrity-detail">Run the six-check evidence review for this dataset.</span>
        <button class="profile-action" id="integrity-action" onclick="runIntegrityReview()">Run review</button>
      </div>
    </div>

    <div class="context-section">
      <div class="context-label">Query protection</div>
      <div class="security-list">
        <div class="security-item">🔒 Read-only access</div>
        <div class="security-item">📋 500-row maximum</div>
        <div class="security-item">⏱ 60-second timeout</div>
        <div class="security-item">🏠 Local model only</div>
      </div>
    </div>

    <div class="context-section">
      <div class="context-label">Quick shortcuts</div>
      <div class="shortcuts-list" id="shortcuts-list">
        <!-- populated from /api/shortcuts -->
      </div>
    </div>
  </aside>

</div>

<script>
const SHORTCUTS = {shortcuts_json};

let currentMode = 'focused';
let activeTable = '';
let conversationCount = 0;
let lastResult = null;  // {{columns, rows, question}} of the most recent tabular result
let activeRequest = null;

// Detect a request to re-chart the LAST result (never hits the model).
// Returns 'pie' | 'bar' | 'line' | null.
function detectChartRequest(text) {{
  const t = text.toLowerCase();
  const isChartish = /\\b(chart|graph|plot|visuali[sz]e|pie|bar graph|bar chart|line graph|line chart|donut|percentage|percentages|%)\\b/.test(t);
  if (!isChartish) return null;
  // Must refer to existing data, not request new data
  const refersExisting = /\\b(this|that|it|these|the (result|results|data|numbers|above))\\b/.test(t)
                         || /\\b(as|into|in) a\\b/.test(t)
                         || /\\bpresent\\b/.test(t)
                         || /\\bshow\\b/.test(t);
  if (!refersExisting) return null;
  if (/\\bpie\\b|\\bdonut\\b/.test(t)) return 'pie';
  if (/\\bline\\b/.test(t)) return 'line';
  if (/\\bbar\\b/.test(t)) return 'bar';
  // generic "chart this" → pick based on data shape later; default pie if percentages mentioned
  if (/\\bpercentage|%\\b/.test(t)) return 'pie';
  return 'bar';
}}

// Build a Plotly spec client-side from cached rows/columns.
function buildChartSpecJS(columns, rows, type) {{
  const copper = '#B8864F', copper2 = '#CBA36A';
  const palette = ['#B8864F','#CBA36A','#8F6435','#D9B98A','#6E4B28','#E8D5B5','#A8763C'];
  // find first text column (labels) and first numeric column (values)
  let labelIdx = -1, valIdx = -1;
  for (let i=0;i<columns.length;i++) {{
    const v = rows[0][i];
    if (labelIdx<0 && (typeof v === 'string')) labelIdx = i;
    if (valIdx<0 && (typeof v === 'number')) valIdx = i;
  }}
  if (valIdx<0) valIdx = columns.length>1?1:0;
  if (labelIdx<0) labelIdx = 0;

  const labels = rows.map(r => String(r[labelIdx]));
  const values = rows.map(r => Number(r[valIdx]) || 0);

  const layout = {{
    paper_bgcolor:'rgba(0,0,0,0)', plot_bgcolor:'rgba(0,0,0,0)',
    font:{{color:'#FCFAF6', family:'Inter, ui-sans-serif, sans-serif'}},
    margin:{{l:40,r:20,t:30,b:40}}, height:300, showlegend:true
  }};
  let data;
  if (type === 'pie') {{
    data = [{{ type:'pie', labels, values, textinfo:'label+percent',
               hole:0, marker:{{colors:palette}}, sort:true }}];
    layout.showlegend = true;
  }} else if (type === 'line') {{
    data = [{{ type:'scatter', mode:'lines+markers', x:labels, y:values,
               line:{{color:copper,width:2}} }}];
    layout.xaxis_title = columns[labelIdx]; layout.yaxis_title = columns[valIdx];
  }} else {{
    data = [{{ type:'bar', x:labels, y:values, marker:{{color:copper}} }}];
    layout.xaxis_title = columns[labelIdx]; layout.yaxis_title = columns[valIdx];
    layout.showlegend = false;
  }}
  return {{ data, layout }};
}}

// ── Init ──
async function init() {{
  // loadStatus runs independently — it can be slow (Databricks cold start)
  // and must never block the UI from becoming interactive.
  loadStatus();
  loadModels();
  await Promise.all([loadCatalogs(), loadShortcuts()]);
  await Promise.all([loadProfile(), loadIntegrityHistory()]);
}}

async function loadModels() {{
  try {{
    const r = await fetch('/api/models');
    const d = await r.json();
    const sel = document.getElementById('model-select');
    if (!sel) return;
    const models = d.models || [];
    if (!models.length) {{ sel.innerHTML = '<option>no models</option>'; return; }}
    sel.innerHTML = models.map(m =>
      `<option value="${{escHtml(m)}}" ${{m === d.active ? 'selected' : ''}}>${{escHtml(m)}}</option>`
    ).join('');
  }} catch(e) {{
    const sel = document.getElementById('model-select');
    if (sel) sel.innerHTML = '<option>unavailable</option>';
  }}
}}

async function switchModel(name) {{
  if (!name) return;
  try {{
    const r = await fetch('/api/model', {{
      method:'POST', headers:{{'Content-Type':'application/json'}},
      body: JSON.stringify({{model: name}})
    }});
    const d = await r.json();
    if (d.ok) {{
      window._model = d.model;
      const olab = document.getElementById('ollama-label');
      if (olab) olab.textContent = d.model + ' · local';
    }}
  }} catch(e) {{ /* non-fatal */ }}
}}

async function loadStatus() {{
  try {{
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 6000);
    const r = await fetch('/api/status', {{ signal: controller.signal }});
    clearTimeout(timer);
    const d = await r.json();

    // Ollama
    const odot = document.getElementById('ollama-dot');
    const olab = document.getElementById('ollama-label');
    if (d.ollama.ok) {{
      odot.className = 'dot';
      olab.textContent = d.model + ' · local';
    }} else {{
      odot.className = 'dot bad';
      olab.textContent = 'Ollama offline';
    }}

    // Databricks
    const ddot = document.getElementById('db-dot');
    const dlab = document.getElementById('db-label');
    if (d.databricks.ok) {{
      ddot.className = 'dot';
      dlab.textContent = 'Databricks connected';
    }} else {{
      ddot.className = 'dot bad';
      dlab.textContent = 'Databricks error';
    }}

    // Status pills (focused)
    document.getElementById('pill-model').textContent = d.ollama.ok ? ('✦ ' + d.model) : '✗ Ollama offline';
    document.getElementById('pill-model').className = 'pill ' + (d.ollama.ok ? 'ok' : 'warn');
    document.getElementById('pill-db').textContent = d.databricks.ok ? '🗄 Databricks ready' : '✗ DB error';
    document.getElementById('pill-db').className = 'pill ' + (d.databricks.ok ? 'ok' : 'warn');

    // Analyst pills
    document.getElementById('analyst-pill-model').textContent = d.ollama.ok ? ('✦ ' + d.model) : '✗ Ollama offline';
    document.getElementById('analyst-pill-model').className = 'pill ' + (d.ollama.ok ? 'ok' : 'warn');
    document.getElementById('analyst-pill-db').textContent = d.databricks.ok ? '🗄 Databricks ready' : '✗ DB error';
    document.getElementById('analyst-pill-db').className = 'pill ' + (d.databricks.ok ? 'ok' : 'warn');

    updateActiveDatasetUI(d.table || '');
  }} catch(e) {{
    console.warn('Status check failed', e);
    document.getElementById('ollama-dot').className = 'dot warn';
    document.getElementById('ollama-label').textContent = 'Status check failed';
    document.getElementById('db-dot').className = 'dot warn';
    document.getElementById('db-label').textContent = 'Status check failed';
    document.getElementById('pill-model').textContent = '⚠ Status check failed';
    document.getElementById('pill-db').textContent = '⚠ Status check failed';
  }}
}}

function updateActiveDatasetUI(tableRef) {{
  activeTable = tableRef || '';
  document.getElementById('ctx-table').textContent = activeTable || '–';
  document.getElementById('active-table-label').textContent = activeTable
    ? ('Table: ' + activeTable.split('.').pop()) : '';
}}

async function loadCatalogs() {{
  const select = document.getElementById('catalog-select');
  try {{
    const r = await fetch('/api/catalogs');
    const d = await r.json();
    if (!r.ok || !d.ok) throw new Error((d.error && d.error.message) || 'Catalog discovery failed');
    select.innerHTML = d.catalogs.map(c =>
      `<option value="${{escHtml(c)}}" ${{c === d.active ? 'selected' : ''}}>${{escHtml(c)}}</option>`
    ).join('');
    await loadSchemas(d.active || d.catalogs[0]);
  }} catch(e) {{
    select.innerHTML = '<option>Unavailable</option>';
  }}
}}

async function loadSchemas(catalog) {{
  const select = document.getElementById('schema-select');
  if (!catalog) return;
  try {{
    const r = await fetch('/api/schemas?catalog=' + encodeURIComponent(catalog));
    const d = await r.json();
    if (!r.ok || !d.ok) throw new Error((d.error && d.error.message) || 'Schema discovery failed');
    const selected = d.active || d.schemas[0] || '';
    select.innerHTML = d.schemas.map(s =>
      `<option value="${{escHtml(s)}}" ${{s === selected ? 'selected' : ''}}>${{escHtml(s)}}</option>`
    ).join('');
    await loadTables(catalog, selected);
  }} catch(e) {{
    select.innerHTML = '<option>Unavailable</option>';
  }}
}}

async function changeCatalog(catalog) {{
  await loadSchemas(catalog);
}}

async function changeSchema(schema) {{
  const catalog = document.getElementById('catalog-select').value;
  await loadTables(catalog, schema);
}}

async function loadTables(catalog, schema) {{
  try {{
    const params = new URLSearchParams();
    if (catalog) params.set('catalog', catalog);
    if (schema) params.set('schema', schema);
    const r = await fetch('/api/tables?' + params.toString());
    const d = await r.json();
    if (!r.ok || !d.ok) throw new Error((d.error && d.error.message) || 'Table discovery failed');
    const picker = document.getElementById('table-picker');
    picker.innerHTML = '';
    d.tables.forEach(t => {{
      const div = document.createElement('div');
      div.className = 'table-item' + (t === d.active ? ' active' : '');
      const parts = t.split('.');
      const short = parts[parts.length - 1];
      div.innerHTML = `<span class="table-dot"></span><span title="${{t}}">${{short}}</span>`;
      div.title = t;
      div.onclick = () => switchDataset(t);
      picker.appendChild(div);
    }});
  }} catch(e) {{
    document.getElementById('table-picker').innerHTML = '<div style="color:var(--warn);font-size:12px">Unable to discover tables.</div>';
  }}
}}

async function switchDataset(tableRef) {{
  try {{
    const r = await fetch('/api/table', {{
      method:'POST',
      headers:{{'Content-Type':'application/json'}},
      body: JSON.stringify({{table: tableRef}}),
    }});
    const d = await r.json();
    if (!r.ok || !d.ok) throw new Error((d.error && d.error.message) || 'Dataset switch failed');
    updateActiveDatasetUI(d.active);
    lastResult = null;
    await loadTables(d.dataset.catalog, d.dataset.schema);
    await loadProfile();
    await loadIntegrityHistory();
    await loadShortcuts();
  }} catch(e) {{
    const chatArea = document.getElementById(currentMode === 'analyst' ? 'analyst-chat-area' : 'chat-area');
    appendErrorBubble(chatArea, e.message || 'Dataset switch failed.');
  }}
}}

function showProfileState(title, detail, actionLabel, disabled=false) {{
  document.getElementById('profile-title').textContent = title;
  document.getElementById('profile-detail').textContent = detail;
  const action = document.getElementById('profile-action');
  action.textContent = actionLabel;
  action.disabled = disabled;
}}

function renderProfileSummary(payload) {{
  if (!payload.available || !payload.profile) {{
    showProfileState('Not profiled', 'Generate a local statistical profile for this dataset.', 'Generate profile');
    return;
  }}
  const p = payload.profile;
  const flags = Object.values(p.anomaly_summary || {{}}).reduce((sum, value) => sum + Number(value || 0), 0);
  const records = Number(p.record_count || 0).toLocaleString();
  const detail = `${{records}} records · ${{p.column_count || 0}} columns · ${{flags}} review flags`;
  showProfileState('Profile ready', detail, 'Refresh profile');
}}

async function loadProfile() {{
  try {{
    showProfileState('Checking profile…', 'Matching the cache to the live schema.', 'Please wait', true);
    const response = await fetch('/api/profile');
    const payload = await response.json();
    if (!response.ok || !payload.ok) throw new Error((payload.error && payload.error.message) || 'Profile check failed');
    renderProfileSummary(payload);
  }} catch (error) {{
    showProfileState('Profile unavailable', error.message || 'Could not check the profile.', 'Try again');
  }}
}}

async function buildDatasetProfile() {{
  try {{
    showProfileState('Profiling…', 'Running bounded, read-only aggregate checks.', 'Working…', true);
    const response = await fetch('/api/profile', {{
      method:'POST',
      headers:{{'Content-Type':'application/json'}},
      body:JSON.stringify({{refresh:true, detail:false}}),
    }});
    const payload = await response.json();
    if (!response.ok || !payload.ok) throw new Error((payload.error && payload.error.message) || 'Profiling failed');
    renderProfileSummary(payload);
  }} catch (error) {{
    showProfileState('Profile failed', error.message || 'Could not generate the profile.', 'Try again');
  }}
}}

function showIntegrityState(title, detail, actionLabel='Run review', disabled=false) {{
  const heading = document.getElementById('integrity-title');
  const body = document.getElementById('integrity-detail');
  const action = document.getElementById('integrity-action');
  if (heading) heading.textContent = title;
  if (body) body.textContent = detail;
  if (action) {{ action.textContent = actionLabel; action.disabled = disabled; }}
}}

async function loadIntegrityHistory() {{
  try {{
    const response = await fetch('/api/integrity-history?limit=1');
    const payload = await response.json();
    if (!response.ok || !payload.ok) throw new Error('History unavailable');
    const latest = payload.latest;
    if (!latest) {{
      showIntegrityState('Not checked', 'Run the six-check evidence review for this dataset.');
      return;
    }}
    const statuses = latest.statuses || {{}};
    const checkedAt = new Date(latest.checked_at);
    const when = Number.isNaN(checkedAt.getTime()) ? latest.checked_at : checkedAt.toLocaleString();
    const detail = `${{statuses['Review'] || 0}} review · ${{statuses['No flags'] || 0}} no flags · ${{latest.origin || 'interactive'}}`;
    showIntegrityState('Last checked ' + when, detail, 'Run again');
  }} catch (error) {{
    showIntegrityState('History unavailable', 'The review can still be run manually.', 'Run review');
  }}
}}

function runIntegrityReview() {{
  if (activeRequest) return;
  showIntegrityState('Review running…', 'Executing bounded, read-only evidence checks.', 'Working…', true);
  executeQuery('', 'integrity_check', currentMode);
}}

async function loadShortcuts() {{
  const list = document.getElementById('shortcuts-list');
  list.innerHTML = '';
  let available = SHORTCUTS;
  try {{
    const response = await fetch('/api/shortcuts');
    const payload = await response.json();
    if (response.ok) available = payload;
  }} catch (error) {{
    console.warn('Shortcut compatibility check failed', error);
  }}
  Object.entries(available).forEach(([name, value]) => {{
    const desc = (value && value.description) ? value.description : value;
    const btn = document.createElement('button');
    btn.className = 'shortcut-btn';
    btn.textContent = desc;
    btn.onclick = () => runShortcut(name, desc);
    list.appendChild(btn);
  }});
}}

// ── Mode ──
function setMode(mode) {{
  currentMode = mode;
  document.getElementById('focused-main').style.display = mode === 'focused' ? 'flex' : 'none';
  document.getElementById('analyst-main').style.display  = mode === 'analyst'  ? 'flex' : 'none';
  document.getElementById('focused-main').style.flexDirection = 'column';
  document.getElementById('analyst-main').style.flexDirection = 'column';
  document.getElementById('mode-focused').className = 'mode-btn' + (mode === 'focused' ? ' active' : '');
  document.getElementById('mode-analyst').className  = 'mode-btn' + (mode === 'analyst'  ? ' active' : '');
}}

// ── Conversation ──
function newConversation() {{
  if (activeRequest) {{
    activeRequest.silent = true;
    activeRequest.controller.abort();
  }}
  fetch('/api/clear', {{method:'POST'}});
  document.getElementById('chat-area').innerHTML = document.getElementById('welcome-msg')?.outerHTML || '';
  document.getElementById('analyst-chat-area').innerHTML = '<div class="welcome"><h2>Analyst mode</h2><p>Results appear in the canvas panel on the right.</p></div>';
  document.getElementById('canvas-body').innerHTML = '<p style="color:var(--muted);font-size:13px">Send a question to see the chart and data here.</p>';
  document.getElementById('main-prompt').value = '';
  document.getElementById('analyst-prompt').value = '';
  conversationCount = 0;
}}

function addThread(text) {{
  const list = document.getElementById('thread-list');
  const btn = document.createElement('button');
  btn.className = 'thread-btn active';
  btn.textContent = text.length > 36 ? text.slice(0,34)+'…' : text;
  list.querySelectorAll('.thread-btn').forEach(b => b.classList.remove('active'));
  list.prepend(btn);
}}

// ── Input helpers ──
function fillPrompt(text) {{
  const ta = currentMode === 'focused' ? document.getElementById('main-prompt') : document.getElementById('analyst-prompt');
  ta.value = text;
  ta.focus();
  hideWelcome();
}}

function handleKey(e) {{
  if (e.key === 'Enter' && !e.shiftKey) {{ e.preventDefault(); sendQuestion(); }}
}}
function handleAnalystKey(e) {{
  if (e.key === 'Enter' && !e.shiftKey) {{ e.preventDefault(); sendAnalystQuestion(); }}
}}

function hideWelcome() {{
  const w = document.getElementById('welcome-msg');
  if (w) w.style.display = 'none';
}}

// ── Send (focused) ──
async function sendQuestion() {{
  const ta = document.getElementById('main-prompt');
  const q = ta.value.trim();
  if (!q) return;
  ta.value = '';
  hideWelcome();
  await executeQuery(q, null, 'focused');
}}

async function sendAnalystQuestion() {{
  const ta = document.getElementById('analyst-prompt');
  const q = ta.value.trim();
  if (!q) return;
  ta.value = '';
  await executeQuery(q, null, 'analyst');
}}

async function runShortcut(name, desc) {{
  hideWelcome();
  const chatEl = currentMode === 'focused' ? 'chat-area' : 'analyst-chat-area';
  await executeQuery(desc, name, currentMode);
}}

function setRequestState(mode, running) {{
  const send = document.getElementById('send-btn');
  const analystSend = document.getElementById('analyst-send-btn');
  const stop = document.getElementById('stop-btn');
  const analystStop = document.getElementById('analyst-stop-btn');
  if (send) send.disabled = running;
  if (analystSend) analystSend.disabled = running;
  if (stop) stop.hidden = !(running && mode === 'focused');
  if (analystStop) analystStop.hidden = !(running && mode === 'analyst');
}}

function stopActiveRequest() {{
  if (activeRequest && !activeRequest.controller.signal.aborted) {{
    activeRequest.controller.abort();
  }}
}}

// ── Core query executor ──
async function executeQuery(question, shortcut, mode) {{
  const chatArea = document.getElementById(mode === 'analyst' ? 'analyst-chat-area' : 'chat-area');
  if (activeRequest) {{
    appendErrorBubble(chatArea, 'A request is already running. Stop it before starting another.');
    return;
  }}

  // Add user bubble
  const displayedQuestion = question || (shortcut === 'integrity_check' ? 'Data integrity check' : (shortcut || 'Run analysis'));
  appendUserBubble(chatArea, displayedQuestion);
  if (conversationCount === 0) addThread(displayedQuestion);
  conversationCount++;

  // ── Chart request on existing data: re-render locally, skip the model ──
  if (!shortcut) {{
    const chartType = detectChartRequest(question);
    if (chartType && lastResult && lastResult.rows && lastResult.rows.length) {{
      appendChartBubble(chatArea, lastResult, chartType, mode);
      chatArea.scrollTop = chatArea.scrollHeight;
      return;
    }}
    if (chartType && (!lastResult || !lastResult.rows || !lastResult.rows.length)) {{
      appendErrorBubble(chatArea, 'No results to chart yet — run a query first, then ask me to chart it.');
      chatArea.scrollTop = chatArea.scrollHeight;
      return;
    }}
  }}

  // One request at a time, with a browser-side Stop control.
  const controller = new AbortController();
  const requestHandle = {{controller, mode, silent:false}};
  activeRequest = requestHandle;
  setRequestState(mode, true);

  // Show thinking indicator
  const thinkId = 'think-' + Date.now();
  chatArea.insertAdjacentHTML('beforeend', `
    <div class="thinking" id="${{thinkId}}">
      <div class="avatar">✦</div>
      <div class="bubble" style="padding:14px 18px">
        <div class="thinking-dots"><span></span><span></span><span></span></div>
      </div>
    </div>`);
  chatArea.scrollTop = chatArea.scrollHeight;

  try {{
    const resp = await fetch('/api/query', {{
      method: 'POST',
      headers: {{'Content-Type': 'application/json'}},
      body: JSON.stringify({{question, shortcut}}),
      signal: controller.signal,
    }});
    const contentType = resp.headers.get('content-type') || '';
    let data;
    if (contentType.includes('application/json')) {{
      data = await resp.json();
    }} else {{
      const body = await resp.text();
      throw new Error(body ? 'The server returned a non-JSON error response.' : 'The server returned an empty response.');
    }}

    // Remove thinking indicator
    document.getElementById(thinkId)?.remove();

    if (!resp.ok || data.ok === false || data.error) {{
      const err = data.error;
      const message = typeof err === 'string'
        ? err
        : (err && err.message) || data.answer || `Request failed (HTTP ${{resp.status}})`;
      const detail = err && typeof err === 'object' ? err.detail : '';
      const fullMessage = detail && detail !== message
        ? `${{message}}\n\nDatabricks detail: ${{detail}}`
        : message;
      appendErrorBubble(chatArea, fullMessage);
    }} else {{
      appendAssistantBubble(chatArea, data, mode);
      // In analyst mode, also update canvas
      if (mode === 'analyst') updateCanvas(data);
      if (data.intent === 'overview') loadProfile();
    }}
  }} catch(e) {{
    document.getElementById(thinkId)?.remove();
    if (e.name === 'AbortError') {{
      if (!requestHandle.silent) {{
        appendErrorBubble(
          chatArea,
          'Request stopped in this view. If Databricks had already accepted the SQL, that server-side operation may still finish in the background.'
        );
      }}
    }} else {{
      appendErrorBubble(chatArea, 'Network error: ' + e.message);
    }}
  }} finally {{
    if (activeRequest === requestHandle) activeRequest = null;
    setRequestState(mode, false);
    if (shortcut === 'integrity_check') loadIntegrityHistory();
    chatArea.scrollTop = chatArea.scrollHeight;
  }}
}}

// ── Bubble builders ──
function appendUserBubble(chatArea, text) {{
  const div = document.createElement('div');
  div.className = 'message user';
  div.innerHTML = `<div class="bubble"><p>${{escHtml(text)}}</p></div>`;
  chatArea.appendChild(div);
}}

function appendErrorBubble(chatArea, msg) {{
  const div = document.createElement('div');
  div.className = 'message';
  div.innerHTML = `<div class="avatar">✦</div><div class="error-bubble">${{escHtml(msg)}}</div>`;
  chatArea.appendChild(div);
}}

function appendAssistantBubble(chatArea, data, mode) {{
  const hasData   = data.columns && data.rows && data.rows.length > 0;
  const hasSql    = !!data.sql;
  const hasChart  = !!data.chart;
  const charts    = Array.isArray(data.charts) ? data.charts : [];
  const integrityDetails = Array.isArray(data.integrity_details) ? data.integrity_details : [];

  // Cache the latest tabular result so chart requests can re-render it
  // without going back to the model.
  if (hasData) {{
    lastResult = {{ columns: data.columns, rows: data.rows, question: data.question || '' }};
  }}
  const sqlId     = 'sql-' + Date.now();
  const tableId   = 'tbl-' + Date.now();
  const chartId   = 'ch-'  + Date.now();
  const actionId  = 'act-' + Date.now();
  const overviewChartIds = charts.map((_, index) => chartId + '-multi-' + index);
  const suggestedQuestions = Array.isArray(data.suggested_questions) ? data.suggested_questions.slice(0,3) : [];
  const provenance = data.provenance || {{}};
  const sourceLabels = {{
    local_model: 'Local model · live schema grounded',
    semantic_template: 'Verified semantic template',
    named_shortcut: 'Compatible named analysis',
    integrity_framework: 'Generic integrity framework · live schema grounded',
  }};
  const sourceLabel = sourceLabels[provenance.sql_source] || 'Read-only analytical query';
  const fingerprint = provenance.schema_fingerprint
    ? provenance.schema_fingerprint.slice(0, 12) + '…'
    : 'not recorded';
  const profileLabel = provenance.profile_used
    ? ('Profile used' + (provenance.profile_generated_at ? ' · ' + provenance.profile_generated_at : ''))
    : 'Live schema only · no matching cached profile';
  const repairLabel = provenance.repair_attempted
    ? (provenance.repair_succeeded ? 'One SQL correction applied successfully' : 'One SQL correction attempted')
    : 'No SQL correction required';

  // Intent badge colour
  const intentMap = {{
    meta:      ['#4A90D9', 'Schema'],
    domain:    ['#7B68EE', 'Domain knowledge'],
    integrity: ['#2E9E83', 'Data integrity'],
    profile:   ['#5B8DB8', 'Dataset profile'],
    overview:  ['#C77D3A', 'Overview'],
    clarification:['#D69A54', 'Clarification'],
    analytical:['var(--copper)', 'Live query'],
  }};
  const [intentColor, intentLabel] = intentMap[data.intent] || ['var(--copper)', 'Live query'];

  // Build result tabs if we have data
  let tabsHtml = '';
  if (hasData || hasSql) {{
    const tabs = [];
    const panels = [];
    if (hasData) {{
      const tableLabel = data.intent === 'integrity' ? 'Scorecard' : 'Table';
      tabs.push(`<button class="result-tab-btn active" data-tab="${{tableId}}" onclick="switchTab(this,'${{tableId}}')">${{tableLabel}} (${{data.total_rows}} rows)</button>`);
      panels.push(`<div id="${{tableId}}" class="result-panel">${{buildTable(data.columns, data.rows, data.total_rows)}}</div>`);
    }}
    integrityDetails.forEach((detail, index) => {{
      if (!detail || !Array.isArray(detail.columns) || !Array.isArray(detail.rows)) return;
      const detailId = `${{tableId}}-integrity-${{index}}`;
      const detailName = escHtml(detail.name || `Detail ${{index + 1}}`);
      tabs.push(`<button class="result-tab-btn" data-tab="${{detailId}}" onclick="switchTab(this,'${{detailId}}')">${{detailName}} (${{detail.rows.length}})</button>`);
      panels.push(`<div id="${{detailId}}" class="result-panel" hidden>${{buildTable(detail.columns, detail.rows, detail.rows.length)}}</div>`);
    }});
    if (hasSql) {{
      tabs.push(`<button class="result-tab-btn" data-tab="${{sqlId}}" onclick="switchTab(this,'${{sqlId}}')">SQL</button>`);
      panels.push(`<div id="${{sqlId}}" class="result-panel" hidden><div class="sql-block open"><code>${{escHtml(data.sql)}}</code></div></div>`);
    }}
    if (hasData) {{
      const sourceId = `${{tableId}}-src`;
      tabs.push(`<button class="result-tab-btn" data-tab="${{sourceId}}" onclick="switchTab(this,'${{sourceId}}')">Sources</button>`);
      panels.push(`<div id="${{sourceId}}" class="result-panel" hidden><div style="color:var(--muted);font-size:12px;padding:8px 0">
        <div class="security-item" style="margin-bottom:6px">🗄 ${{escHtml((data.dataset && data.dataset.table_ref) || activeTable)}}</div>
        <div class="security-item">🔒 Read-only Databricks query</div>
        <div class="security-item">🧭 ${{escHtml(sourceLabel)}}</div>
        <div class="security-item"># Schema ${{escHtml(fingerprint)}}</div>
        <div class="security-item">◫ ${{escHtml(profileLabel)}}</div>
        <div class="security-item">↻ ${{escHtml(repairLabel)}}</div>
      </div></div>`);
    }}
    tabsHtml = `<div class="result-tabs-row">${{tabs.join('')}}</div>${{panels.join('')}}`;
  }}

  // Chart section (focused mode inline, analyst mode goes to canvas)
  let chartHtml = '';
  if (hasChart && mode === 'focused') {{
    chartHtml = `<div class="chart-wrap" id="${{chartId}}"></div>`;
  }}
  if (charts.length && mode === 'focused') {{
    chartHtml += overviewChartIds.map(id => `<div class="chart-wrap" id="${{id}}"></div>`).join('');
  }}

  const nextQuestionsHtml = suggestedQuestions.length ? `
    <div class="next-questions">
      <div class="next-questions-label">Ask next</div>
      <div class="next-questions-list">
        ${{suggestedQuestions.map(question =>
          `<button class="next-question-btn" data-next-question="${{escHtml(question)}}">${{escHtml(question)}}</button>`
        ).join('')}}
      </div>
    </div>` : '';
  const resultActionsHtml = (hasData || hasSql) ? `
    <div class="result-actions">
      ${{hasData ? `<button class="result-action" id="${{actionId}}-export">Export report</button>` : ''}}
      ${{hasSql ? `<button class="result-action" id="${{actionId}}-lock">Lock methodology</button>` : ''}}
    </div>` : '';

  const div = document.createElement('div');
  div.className = 'message';
  div.innerHTML = `
    <div class="avatar">✦</div>
    <div class="bubble">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
        <span style="font-size:11px;padding:2px 8px;border-radius:10px;background:color-mix(in srgb,${{intentColor}} 20%,transparent);color:${{intentColor}}">${{intentLabel}}</span>
        <span style="font-size:11px;color:var(--muted)">${{data.timestamp}}</span>
      </div>
      <div class="answer-lead">${{markdownToHtml(data.answer)}}</div>
      ${{chartHtml}}
      ${{tabsHtml}}
      ${{resultActionsHtml}}
      ${{nextQuestionsHtml}}
    </div>`;
  chatArea.appendChild(div);

  div.querySelectorAll('[data-next-question]').forEach(button => {{
    button.addEventListener('click', () => fillPrompt(button.dataset.nextQuestion || ''));
  }});
  const exportButton = document.getElementById(`${{actionId}}-export`);
  if (exportButton) exportButton.addEventListener('click', () => downloadMarkdownReport(data));
  const lockButton = document.getElementById(`${{actionId}}-lock`);
  if (lockButton) lockButton.addEventListener('click', () => lockMethodology(data, lockButton));

  // Render Plotly chart if in focused mode
  if (hasChart && mode === 'focused') {{
    const chartEl = document.getElementById(chartId);
    if (chartEl) renderChart(chartEl, data.chart);
  }}
  if (charts.length && mode === 'focused') {{
    charts.forEach((spec, index) => {{
      const chartEl = document.getElementById(overviewChartIds[index]);
      if (chartEl) renderChart(chartEl, spec);
    }});
  }}
}}

function appendChartBubble(chatArea, result, type, mode) {{
  const chartId = 'rech-' + Date.now();
  const label = type.charAt(0).toUpperCase() + type.slice(1);
  const div = document.createElement('div');
  div.className = 'message';
  div.innerHTML = `
    <div class="avatar">✦</div>
    <div class="bubble">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
        <span style="font-size:11px;padding:2px 8px;border-radius:10px;background:color-mix(in srgb,var(--copper) 20%,transparent);color:var(--copper)">${{label}} chart</span>
      </div>
      <div class="answer-lead">Here's the previous result as a ${{label.toLowerCase()}} chart.</div>
      <div class="chart-wrap" id="${{chartId}}"></div>
    </div>`;
  chatArea.appendChild(div);
  const spec = buildChartSpecJS(result.columns, result.rows, type);
  const el = document.getElementById(chartId);
  if (el) renderChart(el, spec);
  // In analyst mode, also drop it on the canvas
  if (mode === 'analyst') {{
    const body = document.getElementById('canvas-body');
    if (body) {{
      const wrap = document.createElement('div');
      wrap.className = 'canvas-chart-panel';
      wrap.id = 'canvas-rech-' + Date.now();
      body.insertBefore(wrap, body.firstChild);
      renderChart(wrap, spec);
    }}
  }}
}}

function markdownCell(value) {{
  return String(value ?? '').replace(/\|/g, '\\\\|').replace(/[\\r\\n]+/g, ' ');
}}

function markdownTable(title, columns, rows) {{
  if (!Array.isArray(columns) || !columns.length || !Array.isArray(rows)) return '';
  const heading = title ? `## ${{title}}\n\n` : '';
  const header = '| ' + columns.map(markdownCell).join(' | ') + ' |';
  const divider = '| ' + columns.map(() => '---').join(' | ') + ' |';
  const body = rows.map(row => '| ' + columns.map((_, index) => markdownCell(row[index])).join(' | ') + ' |').join('\\n');
  return `${{heading}}${{header}}\n${{divider}}\n${{body}}\n`;
}}

function downloadMarkdownReport(data) {{
  const dataset = (data.dataset && data.dataset.table_ref) || activeTable || 'dataset';
  const lines = [
    `# ${{data.question || 'AvTrix analysis'}}`,
    '',
    `- Dataset: \`${{dataset}}\``,
    `- Exported: ${{new Date().toISOString()}}`,
    `- Intent: ${{data.intent || 'analysis'}}`,
    '',
    data.answer || '',
    '',
  ];
  if (data.columns && data.rows) lines.push(markdownTable('Result', data.columns, data.rows));
  (data.integrity_details || []).forEach(detail => {{
    lines.push(markdownTable(detail.name || 'Integrity evidence', detail.columns || [], detail.rows || []));
  }});
  const statements = data.sql_statements || {{}};
  if (Object.keys(statements).length) {{
    Object.entries(statements).forEach(([name, sql]) => {{
      lines.push(`## Read-only SQL — ${{name}}\n\n\`\`\`sql\n${{sql}}\n\`\`\`\n`);
    }});
  }} else if (data.sql) {{
    lines.push('## Read-only SQL\\n\\n```sql\\n' + data.sql + '\\n```\\n');
  }}
  const blob = new Blob([lines.join('\\n')], {{type:'text/markdown;charset=utf-8'}});
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  const shortDataset = dataset.split('.').pop().replace(/[^A-Za-z0-9_.-]+/g, '-');
  anchor.href = url;
  anchor.download = `avtrix-${{shortDataset}}-${{new Date().toISOString().slice(0,10)}}.md`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}}

async function lockMethodology(data, button) {{
  const original = button.textContent;
  button.disabled = true;
  button.textContent = 'Locking…';
  try {{
    const response = await fetch('/api/methodology', {{
      method:'POST',
      headers:{{'Content-Type':'application/json'}},
      body:JSON.stringify({{
        question:data.question,
        intent:data.intent,
        sql:data.sql,
        sql_statements:data.sql_statements,
        dataset:data.dataset,
        provenance:data.provenance,
        integrity_plan:data.integrity_plan,
      }}),
    }});
    const payload = await response.json();
    if (!response.ok || !payload.ok) throw new Error((payload.error && payload.error.message) || 'Could not lock methodology');
    button.textContent = 'Locked ✓';
    button.title = payload.methodology.filename + ' · no result rows stored';
  }} catch (error) {{
    button.textContent = 'Lock failed';
    button.title = error.message || 'Could not lock methodology';
    setTimeout(() => {{ button.textContent = original; button.disabled = false; }}, 2500);
  }}
}}

function buildTable(columns, rows, totalRows) {{
  const thead = '<tr>' + columns.map(c => `<th>${{escHtml(c)}}</th>`).join('') + '</tr>';
  const tbody = rows.slice(0,100).map(row =>
    '<tr>' + row.map(v => `<td>${{escHtml(String(v ?? ''))}}</td>`).join('') + '</tr>'
  ).join('');
  const note = totalRows > 100 ? `<div class="row-count">Showing 100 of ${{totalRows}} rows</div>` : '';
  return `<div style="overflow-x:auto"><table class="mini-table"><thead>${{thead}}</thead><tbody>${{tbody}}</tbody></table></div>${{note}}`;
}}

// ── Analyst canvas ──
function updateCanvas(data) {{
  const title   = document.getElementById('canvas-title');
  const sub     = document.getElementById('canvas-sub');
  const body    = document.getElementById('canvas-body');

  title.textContent = data.question.length > 60 ? data.question.slice(0,58)+'…' : data.question;
  sub.textContent   = data.timestamp + ' · ' + (data.total_rows || 0) + ' rows';
  body.innerHTML    = '';

  // Chart
  if (data.chart) {{
    const chartWrap = document.createElement('div');
    chartWrap.className = 'canvas-chart-panel';
    chartWrap.id = 'canvas-chart-' + Date.now();
    body.appendChild(chartWrap);
    renderChart(chartWrap, data.chart);
  }}
  if (Array.isArray(data.charts)) {{
    data.charts.forEach((spec, index) => {{
      const chartWrap = document.createElement('div');
      chartWrap.className = 'canvas-chart-panel';
      chartWrap.id = 'canvas-overview-chart-' + Date.now() + '-' + index;
      body.appendChild(chartWrap);
      renderChart(chartWrap, spec);
    }});
  }}

  // Result panel with tabs
  if (data.columns && data.rows) {{
    const panel = document.createElement('div');
    panel.className = 'canvas-result-panel';
    const tabId = 'ct-' + Date.now();
    const integrityDetails = Array.isArray(data.integrity_details) ? data.integrity_details : [];
    const detailTabs = integrityDetails.map((detail, index) => {{
      const detailId = `${{tabId}}-detail-${{index}}`;
      return `<button class="result-tab-btn" onclick="switchTab(this,'${{detailId}}')">${{escHtml(detail.name || `Detail ${{index + 1}}`)}} (${{(detail.rows || []).length}})</button>`;
    }}).join('');
    const detailPanels = integrityDetails.map((detail, index) => {{
      const detailId = `${{tabId}}-detail-${{index}}`;
      return `<div id="${{detailId}}" class="result-panel" hidden style="padding:12px">${{buildTable(detail.columns || [], detail.rows || [], (detail.rows || []).length)}}</div>`;
    }}).join('');
    const tableLabel = data.intent === 'integrity' ? 'Scorecard' : 'Table';
    panel.innerHTML = `
      <div class="canvas-result-head">
        <button class="result-tab-btn active" onclick="switchTab(this,'${{tabId}}-table')">${{tableLabel}} (${{data.total_rows}} rows)</button>
        ${{detailTabs}}
        ${{data.sql ? `<button class="result-tab-btn" onclick="switchTab(this,'${{tabId}}-sql')">SQL</button>` : ''}}
      </div>
      <div id="${{tabId}}-table" class="result-panel" style="padding:12px">${{buildTable(data.columns, data.rows, data.total_rows)}}</div>
      ${{detailPanels}}
      ${{data.sql ? `<div id="${{tabId}}-sql" class="result-panel" hidden style="padding:12px"><div class="sql-block open"><code>${{escHtml(data.sql)}}</code></div></div>` : ''}}
    `;
    body.appendChild(panel);
  }}
}}

// ── Tab switcher ──
function switchTab(btn, panelId) {{
  const container = btn.closest('.result-tabs-row, .canvas-result-head');
  if (!container) return;
  container.querySelectorAll('.result-tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  // Find sibling panels — look in the bubble or canvas panel
  const scope = btn.closest('.bubble') || btn.closest('.canvas-result-panel');
  if (!scope) return;
  scope.querySelectorAll('.result-panel').forEach(p => {{ p.hidden = (p.id !== panelId); }});
}}

// ── Chart rendering ──
function renderChart(el, chartSpec) {{
  if (!window.Plotly) return;
  try {{
    Plotly.react(el, chartSpec.data, chartSpec.layout, {{responsive:true, displayModeBar:false}});
  }} catch(e) {{ console.warn('Chart render error', e); }}
}}

// ── Utilities ──
function escHtml(str) {{
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}}

function markdownToHtmlLegacy(text) {{
  if (!text) return '';
  return text
    .replace(/[*][*]([^*]+)[*][*]/g, '<strong>$1</strong>')
    .replace(/`([^`]+)`/g, '<code style="background:var(--panel2);padding:1px 5px;border-radius:4px">$1</code>')
    .replace(/\\n\\n/g, '</p><p>')
    .replace(/\\n•/g, '<br>•')
    .replace(/\\n/g, '<br>');
}}

function inlineMarkdown(text) {{
  return escHtml(text)
    .replace(/`([^`]+)`/g, '<code style="background:var(--panel2);padding:1px 5px;border-radius:4px">$1</code>')
    .replace(/[*][*]([^*]+)[*][*]/g, '<strong>$1</strong>')
    .replace(/(^|\s)[*]([^*]+)[*](?=\s|$|[.,;:])/g, '$1<em>$2</em>');
}}

function markdownToHtml(text) {{
  if (!text) return '';
  const lines = String(text).replace(/\\r/g, '').split('\\n');
  const html = [];
  let paragraph = [];
  let listType = null;

  const flushParagraph = () => {{
    if (paragraph.length) {{
      html.push('<p>' + inlineMarkdown(paragraph.join(' ')) + '</p>');
      paragraph = [];
    }}
  }};
  const closeList = () => {{
    if (listType) {{ html.push('</' + listType + '>'); listType = null; }}
  }};
  const splitTableRow = line => line.trim().replace(/^\|/, '').replace(/\|$/, '')
    .split('|').map(cell => cell.trim());
  const isTableSeparator = line =>
    line.includes('-') && /^\s*\|?[\s:|\-]+\|?\s*$/.test(line);

  for (let i = 0; i < lines.length; i++) {{
    const line = lines[i].replace(/\\\\$/, '').trimEnd();

    if (line.includes('|') && i + 1 < lines.length && isTableSeparator(lines[i + 1])) {{
      flushParagraph(); closeList();
      const headers = splitTableRow(line);
      const body = [];
      i += 2;
      while (i < lines.length && lines[i].includes('|') && lines[i].trim()) {{
        body.push(splitTableRow(lines[i]));
        i++;
      }}
      i--;
      const headHtml = headers.map(cell => '<th>' + inlineMarkdown(cell) + '</th>').join('');
      const bodyHtml = body.map(row =>
        '<tr>' + headers.map((_, index) => '<td>' + inlineMarkdown(row[index] || '') + '</td>').join('') + '</tr>'
      ).join('');
      html.push('<div class="answer-table-wrap"><table class="answer-table"><thead><tr>' +
        headHtml + '</tr></thead><tbody>' + bodyHtml + '</tbody></table></div>');
      continue;
    }}

    const heading = line.match(/^(#{{1,3}})\s+(.+)$/);
    if (heading) {{
      flushParagraph(); closeList();
      const level = Math.min(3, Math.max(2, heading[1].length));
      html.push('<h' + level + '>' + inlineMarkdown(heading[2]) + '</h' + level + '>');
      continue;
    }}

    if (/^\s*---+\s*$/.test(line)) {{
      flushParagraph(); closeList(); html.push('<hr>'); continue;
    }}

    const bullet = line.match(/^\s*[-*•]\s+(.+)$/);
    const numbered = line.match(/^\s*\d+[.)]\s+(.+)$/);
    if (bullet || numbered) {{
      flushParagraph();
      const wanted = bullet ? 'ul' : 'ol';
      if (listType !== wanted) {{ closeList(); html.push('<' + wanted + '>'); listType = wanted; }}
      html.push('<li>' + inlineMarkdown((bullet || numbered)[1]) + '</li>');
      continue;
    }}

    if (!line.trim()) {{ flushParagraph(); closeList(); continue; }}
    closeList();
    paragraph.push(line.trim());
  }}

  flushParagraph(); closeList();
  return html.join('');
}}

// ── Boot ──
window._model = '';
init().then(() => {{
  // Store model name for source attribution
  fetch('/api/status').then(r=>r.json()).then(d=>{{ window._model = d.model||'Ollama'; }});
}});
</script>
</body>
</html>"""


# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    missing = [v for v in [DATABRICKS_HOST, DATABRICKS_HTTP_PATH, DATABRICKS_TOKEN] if not v]
    if missing:
        print("⚠  Missing Databricks credentials in .env")
        print("   Copy .env.template to .env and fill in your values.")

    print("🔍  Discovering tables in Databricks catalog…")
    threading.Thread(target=discover_tables, daemon=True).start()

    integrity_scheduler = IntegrityScheduler(scheduler_config, _run_scheduled_integrity)
    scheduler_started = integrity_scheduler.start()
    if scheduler_config_error:
        print(f"⚠  Scheduler config: {scheduler_config_error}")
    elif scheduler_started:
        print(
            f"⏱  Integrity scheduler enabled for {len(scheduler_config.tables)} table(s) "
            f"every {scheduler_config.interval_minutes} minutes"
        )

    PORT = 5001

    print(f"✦  AvTrix Fleet Intelligence")
    print(f"   Model : {OLLAMA_MODEL}")
    print(f"   Table : {active_table()}")
    print(f"   URL   : http://127.0.0.1:{PORT}")
    print()

    threading.Timer(1.5, lambda: webbrowser.open(f"http://127.0.0.1:{PORT}")).start()
    app.run(host="0.0.0.0", port=PORT, debug=False, threaded=True)

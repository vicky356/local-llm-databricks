# AvTrix Analyst Build Log

This is the authoritative running record for the AvTrix local-LLM and
Databricks application. Update it whenever a phase is completed, a material
architecture decision is made, a milestone is tested, or a known limitation is
introduced or resolved.

## Project objective

Build a dataset-agnostic analytical agent that can connect to an unfamiliar
Databricks dataset, discover and profile it at runtime, generate safe SQL, and
provide evidence-based answers without training or hardcoding the model for a
specific table.

## Core principles

- Dataset knowledge is discovered at runtime, not fine-tuned into the model.
- Live Databricks metadata takes precedence over stored descriptions.
- Queries are read-only, bounded and auditable.
- Business methodology must be explicitly defined or approved.
- Inference is labelled as inference; uncertainty triggers clarification.
- Dataset-specific analysis packs remain optional and separate from the core.
- No credentials, tokens or complete connection strings are written to logs.

## Current milestone

**Milestone 6 — Operational release candidate**

Status: **All seven planned phases implemented locally; live release acceptance pending.**

Included phases:

- Phase 1 — Databricks connector hardening
- Phase 2 — Dataset discovery and server-side table switching
- Phase 3 — Schema-agnostic profiling and fingerprinted profile storage
- Phase 4 — Profile-informed SQL and bounded correction
- Phase 5 — Schema-grounded temporal, ranking and comparison plans
- Phase 6 — Generic six-check data-integrity framework
- Phase 7 — Operational history, methodology locking, exports and opt-in scheduling

Packaged build:

`outputs/avtrix_analyst-v1-release-candidate.zip`

## Seven-phase roadmap

1. Databricks connector reliability.
2. Dataset discovery and server-side table switching.
3. Schema-agnostic profiling and semantic foundations.
4. Profile-informed SQL generation and bounded correction.
5. Cross-dataset analytical planning for trends, rankings and comparisons.
6. Generic data-integrity framework: monotonicity, uniqueness, consistency and
   date coverage.
7. Operational productisation: history, scheduling, methodology locking and
   monitoring.

---

## Phase 1 — Databricks connector hardening

Status: **Implemented**

### Problem addressed

The original web application retained one global Databricks connection. The UI
reported that Databricks was connected when the Python object existed, even if
the underlying server session had expired. Queries then failed with:

`INVALID_STATE: Invalid SessionHandle`

Unhandled server exceptions could also return Flask HTML to a browser expecting
JSON, producing messages such as:

`Unexpected token '<', "<!doctype "... is not valid JSON`

### Changes implemented

- Added `databricks_client.py`.
- Replaced shared cursors with managed, short-lived query connections.
- Added a real `SELECT 1` health check.
- Added one controlled reconnect after an expired session.
- Prevented unlimited retry loops.
- Added structured query outcomes and error categories.
- Redacted credentials and connection details from errors and logs.
- Added read-only SQL validation.
- Added a configurable 500-row result maximum.
- Added a configurable 60-second query timeout.
- Made web API failures consistently JSON-shaped.
- Applied the query client to both the browser and CLI paths.

### Configuration introduced

```text
DATABRICKS_QUERY_TIMEOUT_SECONDS=60
DATABRICKS_MAX_ROWS=500
DATABRICKS_SESSION_RETRIES=1
AVTRIX_LOG_LEVEL=INFO
```

### Verification

- Python compilation: passed.
- Connector unit tests: passed.
- Expired-session reconnect test: passed.
- Retry-limit test: passed.
- Timeout test: passed.
- Credential-redaction test: passed.
- Read-only SQL validation tests: passed.

### Live verification outstanding

- Deploy on the Mac.
- Confirm health check against the live Databricks warehouse.
- Confirm a query succeeds after an expired or restarted session.
- Confirm browser failures remain valid JSON.

---

## Phase 2 — Dataset discovery and selection

Status: **Implemented**

### Problem addressed

The interface displayed discovered tables, but clicking a table did not change
the server-side query target. The application continued to rely on the startup
`HISTORY_TABLE`, allowing the displayed dataset and queried dataset to diverge.

### Changes implemented

- Added `dataset_registry.py`.
- Added lazy catalog discovery.
- Added lazy schema discovery.
- Added table and view discovery within the selected schema.
- Added catalog and schema selectors to the web interface.
- Made table selection a server-side action through `POST /api/table`.
- Validated each selected dataset using a live `DESCRIBE TABLE`.
- Stored the active dataset in a thread-safe runtime registry.
- Captured the active dataset at the beginning of every query request.
- Refreshed the model's column context from live metadata.
- Added column names, data types and comments to dataset metadata.
- Added a SHA-256 schema fingerprint.
- Included source-dataset metadata in analytical responses.
- Cleared cached chart results when switching datasets.
- Changed `HISTORY_TABLE` into a startup default rather than a permanent target.
- Replaced the FB-specific default overview with a structural overview that is
  valid for any dataset.

### Discovery endpoints

```text
GET  /api/catalogs
GET  /api/schemas?catalog=<catalog>
GET  /api/tables?catalog=<catalog>&schema=<schema>
POST /api/table
```

### Verification

- Total automated tests: 11 passed.
- Python compilation: passed.
- Rendered web page generation: passed.
- Embedded JavaScript syntax validation: passed.
- Dataset discovery tests: passed.
- Schema-fingerprint repeatability test: passed.

### Live verification outstanding

- Confirm catalog and schema permissions against the live account.
- Switch between the two existing fleet tables in the browser.
- Confirm the displayed table and SQL source always match.
- Confirm the schema fingerprint changes when a schema changes.

---

## Phase 3 — Schema-agnostic dataset profiling

Status: **Implemented locally**

### Problem addressed

Live column names alone do not give the model enough context to reason reliably
about an unfamiliar dataset. A generic profiling layer was needed to establish
the dataset's shape, completeness, cardinality, ranges and likely analytical
roles without hardcoding field names from one aviation table.

### Changes implemented

- Added `dataset_profiler.py`.
- Added record and column counts.
- Added null, blank and placeholder counts and rates.
- Added approximate distinct counts and uniqueness ratios.
- Added numeric and date ranges.
- Added bounded representative values for low-cardinality columns.
- Suppressed representative-value sampling for sensitive-looking fields such
  as names, email, phone, address, notes, contact, account and token fields.
- Added inferred roles: identifier, dimension, measure, date, attribute and
  complex field.
- Added cumulative-field candidates based on neutral naming heuristics.
- Added candidate single-column identifiers.
- Added possible composite natural-key components, explicitly marked as
  unverified until an exact duplicate check is performed.
- Added structural review flags for missingness, constants, placeholders and
  numeric/date-like values stored in text fields.
- Added bounded query batching so wide schemas do not produce one unbounded
  aggregate statement.
- Added local JSON profile storage with restrictive file permissions where the
  operating system supports them.
- Keyed every stored profile to both dataset reference and schema fingerprint.
- Added live metadata refresh before profile lookup or creation so a changed
  schema cannot reuse stale context.
- Added `GET /api/profile` for cache lookup and `POST /api/profile` for explicit
  generation or refresh.
- Added a profile status card and Generate/Refresh control to the browser.
- Made the general overview use the generic profile.
- Added natural-language routing for requests such as “profile the active
  dataset”.
- Added profile configuration and privacy controls to `.env.template`.
- Excluded `.avtrix_profiles/` from Git.
- Corrected the read-only validator so quoted columns named after SQL verbs do
  not create false positives.

### Safety and interpretation

- All profile queries are read-only.
- Distinct counts are approximate to reduce cost.
- Candidate keys require exact validation before use.
- Review flags are evidence for review, not proof of bad data.
- Low-cardinality samples are local, bounded and suppress sensitive-looking
  fields by default.
- `AVTRIX_PROFILE_SAMPLE_VALUES=false` disables all representative-value
  storage while retaining counts, ranges and classifications.

### Verification

- Total automated tests: 15 passed.
- Python compilation: passed.
- Unfamiliar-schema profiling test: passed.
- Schema-fingerprint cache isolation test: passed.
- Sensitive-value suppression test: passed.
- Unverified natural-key suggestion test: passed.
- Quoted SQL-keyword identifier test: passed.
- Rendered web page generation: passed.
- Embedded JavaScript syntax validation: passed.

### Live verification outstanding

- Generate profiles for both current fleet tables on the Mac.
- Compare record counts, missingness and ranges with direct Databricks results.
- Profile at least one structurally different non-FB dataset.
- Confirm a second request uses the matching cached profile.
- Confirm profile runtime is acceptable on the free-tier warehouse.
- Confirm sensitive-looking columns contain no representative values in the
  local profile JSON.

---

## Phase 3.1 — MTBUR intent-routing hotfix

Date: **11 October 2026**  
Status: **Deployed and verified on the Mac**

### Incident

Asking “What's MTBUR?” or “Whats MTBUR?” returned the generic unexpected
application error. Separately, the deployed LAN URL timed out and did not
return a page.

### Root cause

- `_SHORTCUT_PATTERNS` still contained `mtbur_by_part` after that shortcut had
  been removed from `NAMED_QUERIES`.
- The web route trusted the matcher result and indexed
  `NAMED_QUERIES['mtbur_by_part']`, raising a `KeyError`.
- The domain classifier recognised “what is” but not the common “what's” or
  “whats” forms.
- The page timeout is a separate operational condition: no service responded
  at `192.168.0.197:5001` during inspection. It is not caused by the MTBUR
  routing exception.

### Changes implemented

- Intent matching now ignores patterns whose shortcut is unavailable.
- The web route defensively confirms a shortcut exists before indexing it.
- Web and CLI domain patterns now recognise “what is”, “what's” and “whats”.
- Added regression coverage for stale patterns and both MTBUR question forms.

### Verification

- Total automated tests: 17 passed.
- Python compilation: passed.
- Direct `/api/query` routing simulation: passed for both “What's MTBUR?” and
  “Whats MTBUR?”.
- Live page check at `192.168.0.201:5001`: passed (HTTP 200).
- Live `/api/query` checks: both “What's MTBUR?” and “Whats MTBUR?” returned
  HTTP 200, routed as domain questions and produced an MTBUR explanation.
- No `KeyError` or unexpected application error was reproduced after deployment.

---

## Live milestone acceptance — Mac deployment

Date: **11 October 2026**  
Status: **Core service passed; free-text SQL quality gap confirmed**

### Environment observed

- Active model: `ministral-3:8b`.
- Active dataset: `poc.avtrix_fb.fb_camp_fleet_history_join`.
- Live schema: 71 columns, fingerprint `8300218b3a16`.
- Ollama health: passed.
- Databricks health: first eight-second check timed out while the warehouse was
  cold; the warm-state check then passed in 1.2 seconds.

### Passed live checks

- Main page: HTTP 200.
- Capabilities question: HTTP 200, routed locally as `meta` in 0.15 seconds.
- Table-discovery question: HTTP 200, returned 14 tables in 0.03 seconds.
- “What's MTBUR?”: HTTP 200, `domain`, 22.76 seconds.
- “Whats MTBUR?”: HTTP 200, `domain`, 25.50 seconds.
- Generic overview: HTTP 200, returned the cached 27,311-row, 71-column
  fingerprinted profile in 3.96 seconds.
- Named categorical query (`jobtype_distribution`): HTTP 200, returned three
  rows from Databricks with a chart payload in 16.81 seconds.
- The deployed page includes the client-side last-result re-chart path, so a
  chart follow-up does not need to regenerate SQL. Interactive browser clicking
  was not exercised because the test browser cannot route to the private LAN.

### Failed live check and evidence

The free-text question “Which aircraft have the most component removals? Show
the top five.” reached the service, but `ministral-3:8b` produced invalid SQL:

- It invented `AC_Registration_Number` instead of using the live `AC_REG`
  column.
- It selected `COUNT(*) AS sample_size` after the aggregate CTE without a
  corresponding `GROUP BY`.
- Databricks rejected the query with `MISSING_GROUP_BY`.

This is a response-quality failure, not a speed or availability failure. It is
direct evidence for Milestone 3: validate generated identifiers before
execution, include the compact active profile in model context, and make one
bounded repair attempt using the real Databricks error.

### Model comparison

The same failed free-text question was repeated with the already-installed
`qwen3.5:latest` model. It reached the application's 120-second Ollama timeout
without producing SQL. The service was then restored to `ministral-3:8b`.

This single A/B test does not rank the models generally, but it does show that a
model swap alone does not solve the current problem on this hardware. The next
step remains deterministic validation and bounded repair, followed by a small,
repeatable cross-model evaluation set.

---

## Phase 3.2 — Evidence-led distribution stories

Date: **11 October 2026**  
Status: **Implemented locally; Mac deployment verification pending**

### Incident

The question “whats the spread across jobtype and also across removal reason?”
was classified as generic domain knowledge because it began with “whats”. The
application did not query Databricks, returned invented generic percentages and
ATA examples, and had no result rows from which to build a visual.

### Changes implemented

- Analytical cues such as spread, distribution, breakdown, mix, percentage and
  trend now take precedence over conversational domain openers.
- A combined JOBTYPE and REASON question routes to the existing read-only
  `reason_by_jobtype` analytical shortcut.
- The query now calculates full-population job-type totals and percentages while
  returning the leading removal reasons for display.
- Scheduled, unscheduled, other and missing job types are kept distinct.
- Missing and placeholder reason codes are quantified as a visibility gap, not
  presented as an operational cause.
- The answer is generated deterministically from returned figures and leads with
  the actual split, leading valid reasons and a data-quality warning.
- The browser receives a two-panel Plotly.js specification: an overall job-type
  donut and a stacked horizontal chart of the top removal reasons by job type.
- Visual-story generation was isolated in a dependency-free module so it can be
  tested without starting Flask, Databricks or Plotly's Python package.

### Verification

- Total automated tests: 20 passed.
- Python compilation: passed.
- Exact reported question routes to `reason_by_jobtype`: passed in web and CLI
  routing tests.
- Read-only SQL validation: passed.
- Evidence-only summary totals and quality warning: passed.
- Donut plus stacked-bar Plotly specification: passed.
- Live test of the new build: pending. The previously running Mac service
  actively refused the final connection attempt before this local build was
  deployed.

---

## Phase 3.3 — Guided analysis and dataset-portfolio routing

Date: **11 October 2026**  
Status: **Implemented locally; batched with Phase 3.2 for the next Mac push**

### Incidents

- “Give me a general summary of the datasets” fell through to model-generated
  SQL instead of a deterministic overview. One attempt produced SQL that
  Databricks rejected; another reached the Ollama generation timeout.
- The two visible outcomes differed between Focused and Analyst views even
  though both views use the same API route, making the behaviour appear
  view-dependent.
- Example questions existed only in the initial Focused welcome panel and
  disappeared after interaction. Analyst mode had no equivalent examples.
- Successful responses did not guide the user towards useful next questions.
- “What data is available?” matched the broad capabilities rule and returned a
  feature list instead of the discovered data portfolio.

### Changes implemented

- Plural dataset-summary wording now has a dedicated deterministic route and
  never invokes Ollama or generates SQL.
- Data-availability wording now has its own route to the same portfolio. The
  capabilities trigger is limited to explicit feature questions such as “what
  can you do?” and can no longer capture “what data is available?”.
- The portfolio response lists every discovered table, the active table, active
  schema width and conservative indicative coverage derived from table names.
  It explicitly states that content and quality require a verified profile.
- Singular active-dataset overview behaviour remains separate.
- Focused and Analyst views continue to call the same `/api/query` route, so the
  overview decision is identical in both modes.
- A persistent “Try asking” shelf now remains above both composers after the
  welcome panel disappears.
- Every successful response now includes up to three deterministic “Ask next”
  questions appropriate to its response type or shortcut.
- Follow-up chart suggestions reuse the last result locally and do not ask the
  model to regenerate SQL.

### Verification

- Total automated tests: 23 passed.
- Python compilation: passed.
- Exact plural-summary phrase recognised without model/SQL: passed.
- Exact data-availability phrase is not classified as capabilities: passed.
- Dataset-portfolio response generation: passed.
- Persistent prompt shelves present in both rendered modes: passed.
- Follow-up question rendering path present: passed.
- Rendered inline JavaScript syntax check with Node: passed.
- Live Mac verification: pending until the combined next-push package is
  deployed.

---

## Phase 3.4 — Distribution reliability and query control

Date: **11 October 2026**  
Status: **Implemented locally; batched with Phases 3.2/3.3 for the next Mac push**

### Incidents

- “Show me a yearly distribution of job types” fell through to generated SQL
  and Databricks rejected the request.
- Reversing the wording to “overall distribution of jobtype” bypassed the
  trusted shortcut, and the improvised result omitted missing JOBTYPE values.
- “Show me the same distribution including null” was treated as a new request
  because the server did not retain the last successful shortcut as structured
  context.
- “Distribution of year type” was ambiguous but still sent to SQL generation.
- A component-type distribution received an overconfident narrative that
  inferred causes, maintenance strategy and operational risk not established by
  the returned counts.
- A mistaken or slow prompt could not be stopped from the browser.
- The browser hid the detailed Databricks error when the API returned one.

### Changes implemented

- Added symmetric intent phrases for “distribution of jobtype” and routed
  yearly JOBTYPE wording before the overall-distribution rule.
- Hardened the yearly query with `TRY_CAST(... AS TIMESTAMP)`, removed the stale
  2025 ceiling, and made missing and non-standard labels visible.
- Normalised overall JOBTYPE labels using trim/case handling and always exposes
  null or blank labels as `(Missing)`.
- Stored the last successful named shortcut as structured server context. A
  “same/previous distribution” follow-up reruns that trusted query rather than
  asking the model to reconstruct SQL. Context resets when the table or
  conversation changes.
- Ambiguous “year type” wording now asks whether the user means job, component
  or aircraft type instead of attempting SQL.
- Trusted JOBTYPE summaries are deterministic and distinguish record shares
  from reliability conclusions.
- Generic categorical distribution questions now receive a schema-agnostic,
  deterministic summary of returned category counts and shares. This avoids
  model-authored causal narratives for simple descriptive results.
- Tightened the remaining model interpretation prompt: it must distinguish
  record/event/entity counts and cannot infer causes, criticality, maintenance
  maturity or operational impact without direct evidence.
- Added Stop controls to both views. Stop aborts the active browser request and
  clearly warns that an operation already accepted by Databricks may still
  complete server-side.
- The UI now displays structured Databricks error detail returned by the API.
- Yearly visualisation excludes total and percentage denominator fields when
  category-count series are available, reducing chart noise.

### Verification

- Total automated tests: 29 passed.
- Python compilation: passed.
- Rendered inline JavaScript syntax check with Node: passed.
- Exact failed phrasings route deterministically: passed.
- Hardened yearly and overall SQL pass read-only validation: passed.
- Missing-label inclusion and generic grounded component summary: passed.
- Stop controls, browser abort path and detailed-error rendering: present in
  both rendered modes.
- Live Mac/Databricks verification: pending deployment of the combined build.

---

## Phase 3.5 — Domain accuracy and response presentation

Date: **11 October 2026**  
Status: **Implemented locally; included in the next Mac push**

### Incident

A multi-topic reliability question was displayed as a dense, almost entirely
bold block. Headings and comparison tables were not rendered, and nearly every
line was presented as a bullet. The generated content also incorrectly expanded
TSI and TSN as regulatory standards, confused the maintenance-record meaning of
TSO with FAA Technical Standard Order, and made unsupported claims about MTBF
and aircraft utilisation.

### Changes implemented

- Removed the interface-level bold font weight previously applied to every
  answer.
- Replaced the line-break-only Markdown converter with a safe structured
  renderer for headings, paragraphs, genuine bullet/numbered lists, horizontal
  rules, inline emphasis, code and comparison tables.
- Added spacing, hierarchy and responsive table styling for answer content.
- Tightened the general domain prompt: direct answer first, short headings,
  bullets only for lists, restrained emphasis and no invented acronym
  expansions.
- Added explicit terminology safeguards for TSI (Time Since Installation), TSN
  (Time Since New), maintenance-record TSO (Time Since Overhaul) and the separate
  certification meaning, FAA Technical Standard Order.
- Added safeguards distinguishing removals from confirmed failures and
  utilisation exposure from turnaround time.
- Added a deterministic, model-independent knowledge card for combined
  reliability, time-status and aircraft-utilisation questions.
- Domain responses now offer relevant follow-up questions rather than generic
  dataset-navigation prompts.
- Mirrored the terminology and presentation guardrails in the CLI prompt.

### Verification

- Total automated tests: 31 passed.
- Python compilation: passed.
- Rendered inline JavaScript syntax check with Node: passed.
- Exact reported multi-topic question selects the deterministic knowledge card:
  passed.
- The card contains the four intended acronym meanings and excludes the
  invented “Technical Standard Notice” expansion: passed.
- Structured headings, table renderer and normal answer font weight are present:
  passed.
- Live browser verification: pending Mac deployment.

---

## Phase 3.6 — Semantic grouped distributions and statistical overview

Date: **11 October 2026**  
Status: **Implemented locally; included in the next Mac push**

### Incidents

- “General overview” reused the dataset-profile response, so it resembled the
  field-by-field integrity output instead of providing descriptive statistics
  and visual context.
- “Distribution of removal reason by aircraft” relied on generated SQL and
  Databricks rejected it with `MISSING_GROUP_BY`.
- “Distribution of jobtype by aircraft” matched the single-field JOBTYPE
  shortcut. The grouping phrase was discarded, returning only the overall
  JOBTYPE mix.

### Changes implemented

- Separated the three concepts in the UI and API: Overview, Dataset profile and
  Data integrity now have distinct response types and purposes.
- Profile version 2 adds mean and sample standard deviation to the existing
  numeric min/max, distinctness and completeness statistics. Old cached
  profiles are invalidated safely by profile version.
- General overview now reports record/column counts, inferred measure and
  dimension counts, typed date coverage, key categorical fields and a concise
  quality context.
- General overview returns a numerical summary table containing population,
  missing rate, approximate distinct count, minimum, mean, maximum and standard
  deviation for up to twelve measures.
- Overview visuals are derived from the active dataset profile: a column-role
  composition chart plus up to two low-cardinality categorical distributions,
  including a visible missing category.
- Added a table-agnostic semantic layer for “distribution of X by Y” wording.
  It parses the two requested dimensions, resolves them against live column
  names/comments, and asks for clarification on missing or tied matches.
- Aviation synonyms help map natural phrases such as aircraft, jobtype and
  removal reason, but no table name or generated column is hardcoded.
- The semantic layer builds one bounded, read-only Spark SQL query with explicit
  grouping, top-category control, `(Missing)` handling and within-group
  percentages.
- Grouped distributions receive a deterministic evidence-only summary and a
  stacked multi-series chart. They no longer depend on the model for SQL or
  narrative generation.
- Focused and Analyst views now support multiple chart payloads for overview
  responses.

### Verification

- Total automated tests: 37 passed.
- Python compilation: passed.
- Rendered inline JavaScript syntax check with Node: passed.
- Both reported grouped-distribution prompts parse correctly: passed.
- Live-column resolution maps removal reason → `REASON`, jobtype → `JOBTYPE`
  and aircraft → `AC_REG` in a representative live-schema fixture: passed.
- Generated grouped SQL passes the read-only validator and contains explicit
  grouped and windowed percentage stages: passed.
- Overview statistics and three profile-driven chart payloads: passed against
  an unfamiliar synthetic profile.
- Live Mac/Databricks verification: pending deployment.

---

## Phase 4 — Profile-informed SQL and bounded correction

Date: **11 October 2026**  
Status: **Implemented locally; ready for the next Mac push**

Package: `outputs/avtrix_analyst-phase4-profile-informed-reasoning.zip`

### Scope decision

Phase 3.6 was frozen without further response-format polishing. This phase is a
small reasoning vertical slice intended to improve cross-dataset performance
before more interface work is considered.

### Changes implemented

- Added a schema-agnostic reasoning context built from the active dataset's live
  column names, Databricks types, comments and schema fingerprint.
- When an exact fingerprint-matched profile exists, the model receives a compact
  subset of relevant roles, completeness rates, distinct counts, ranges, means,
  quality flags and safe low-cardinality values.
- Sensitive-looking fields never contribute representative values to the model
  context; when no matching profile exists, generation falls back to live schema
  metadata without silently using a stale profile.
- Reworked the SQL prompt so every physical source column must use its exact live
  name in backticks and the selected dataset must be referenced explicitly.
- Added conservative pre-execution validation for read-only status, active-table
  identity and unknown quoted identifiers. Databricks remains the final semantic
  authority rather than relying on a home-grown SQL parser.
- Added one evidence-based correction attempt for either a local schema conflict
  or a repairable Databricks SQL error. There is no correction loop.
- Authentication, timeout and non-SQL failures never trigger model correction.
- Expanded Databricks error classification to recognise `MISSING_GROUP_BY`,
  `GROUP_BY_AGGREGATE`, `DATATYPE_MISMATCH` and `AMBIGUOUS_REFERENCE` as SQL
  errors.
- Added explicit required-column manifests to legacy named analyses. The web app
  now hides incompatible shortcuts after a dataset switch and blocks stale direct
  calls before they reach Databricks.
- Added query provenance to API responses and the Sources tab: active dataset,
  schema fingerprint, profile identity, SQL source and correction outcome.
- The deterministic semantic distribution path also reports provenance, keeping
  generated and non-generated analyses distinguishable.

### Verification

- Total automated tests: 47 passed.
- Python compilation: passed.
- Rendered inline JavaScript syntax check with Node: passed.
- Unfamiliar synthetic schema receives relevant profile evidence and never
  receives suppressed representative values: passed.
- Invented quoted columns are blocked before execution: passed.
- A simulated `MISSING_GROUP_BY` error triggers exactly one correction and one
  second execution: passed.
- A simulated timeout does not trigger SQL regeneration: passed.
- An incompatible JOBTYPE shortcut is blocked before Databricks execution:
  passed.
- Live Mac/Databricks verification: pending deployment.

---

## Phase 5 — Cross-dataset analytical plans

Date: **11 October 2026**  
Status: **Implemented locally; ready for the next Mac push**

Package: `outputs/avtrix_analyst-phase5-analytical-plans.zip`

### Scope decision

Phase 5 adds deterministic plans only for repeated, high-value analytical
shapes. Unsupported questions still use the Phase 4 profile-informed model
path. This avoids building a large bespoke query language before live evidence
shows it is needed.

### Changes implemented

- Added table-agnostic parsing for yearly/monthly distributions and record
  trends.
- Temporal field selection uses live names, comments and Databricks data types.
  Equally plausible date fields trigger clarification rather than an arbitrary
  choice.
- Added bounded temporal SQL for record counts and multi-category trends,
  including top-category control, missing-category visibility and within-period
  percentages.
- Added evidence-only temporal narratives that distinguish record volume from
  reliability or utilisation rates.
- Added a multi-series temporal chart generated directly from returned rows.
- Added table-agnostic parsing for top/bottom rankings and aggregate comparisons.
- Ranking plans support count, sum, average, minimum and maximum. Non-count
  aggregations require a live numeric type or a matching profile showing at
  least 90% numeric-like populated values.
- Ranking SQL includes `group_records` so the sample size remains visible beside
  the requested aggregate.
- Temporal, ranking and comparison plans are routed before free-form model SQL
  and identify themselves as verified semantic templates in Sources.
- Added context-specific suggested next questions for temporal and ranking
  results.
- Added `PHASE5_ACCEPTANCE.md`, a repeatable three-dataset live test with explicit
  pass/fail evidence and response-time capture.

### Verification

- Total automated tests: 54 passed.
- Python compilation: passed.
- Rendered inline JavaScript syntax check with Node: passed.
- Yearly and monthly request parsing: passed.
- Typed date resolution plus ambiguous-date clarification: passed.
- Temporal SQL grouping, window percentage and read-only validation: passed.
- Ranking and comparison parsing: passed.
- Numeric aggregation, sample-size output and bounded ranking SQL: passed.
- Temporal answer and multi-series visual against an unfamiliar synthetic
  schema: passed.
- Numeric ranking against an unfamiliar synthetic schema: passed.
- Live three-dataset Mac/Databricks acceptance: pending deployment.

---

## Phase 6 — Generic data-integrity framework

Date: **12 October 2026**  
Status: **Implemented locally; ready for the next Mac push**

Package: `outputs/avtrix_analyst-phase6-integrity-framework.zip`

### Scope decision

Phase 6 adds a read-only, evidence-led integrity review to the browser. It uses
live metadata plus the exact schema-fingerprinted profile rather than assuming
one table's field names. Business-owned overrides are optional and apply only
to an exact fully qualified dataset reference.

### Changes implemented

- Added `integrity_framework.py` with a portable integrity plan and four
  read-only SQL builders.
- Added a decimal/`H:MM` operational-number normaliser used by cumulative and
  cross-column checks.
- Added exact candidate-key uniqueness; null/placeholder keys are excluded from
  duplicate groups and remain visible in completeness evidence.
- Added cumulative monotonicity by entity and time. Records at the same entity
  and timestamp are collapsed before comparison so arbitrary row order cannot
  manufacture a decrease.
- Added event-versus-cumulative consistency checks, capped at eight inferred
  pairs to keep the generic scan bounded.
- Added date coverage per entity, including first/last date, active dates and
  largest/total observed calendar gaps.
- Added metadata completeness using inferred/configured identifier and
  descriptor fields.
- Kept TSI, TSN and TSO out of automatic cumulative-field inference because
  their operational meaning and reset behaviour require dataset methodology.
- Added `integrity_config.json.example`. Exact overrides can define or
  deliberately disable individual checks; unknown live fields are ignored and
  disclosed in planning notes.
- Replaced the old completeness-only browser response with a six-row scorecard
  and per-check evidence tabs in Focused and Analyst views.
- Corrected result-tab target IDs while adding integrity drill-down tabs.
- Added provenance identifying the generic integrity framework, live schema
  fingerprint and matching profile.
- Added `PHASE6_ACCEPTANCE.md` for three-dataset live validation.
- Kept the terminal `check` command as the lightweight completeness-only path;
  full Phase 6 review is a browser feature in this release.

### Verification

- Total automated tests: 62 passed.
- Python compilation: passed.
- Rendered inline JavaScript syntax check with Node: passed.
- Decimal, positive/negative `H:MM` and invalid-minute parsing: passed.
- Unfamiliar synthetic schema plan inference: passed.
- TSI exclusion from inferred cumulative fields: passed.
- Exact configured overrides and deliberate check disabling: passed.
- Ambiguous typed dates are skipped rather than guessed: passed.
- All generated integrity SQL passes the single-statement read-only validator:
  passed.
- Simulated six-check browser scorecard and drill-down response: passed.
- Live three-dataset Mac/Databricks acceptance: pending deployment.

---

## Phase 7 — Operational productisation

Date: **12 October 2026**  
Status: **Implemented locally; Version 1 release candidate ready**

Package: `outputs/avtrix_analyst-v1-release-candidate.zip`

### Scope decision

Phase 7 completes the planned build without adding autonomous source-data
changes. Operational persistence is deliberately summary-only. Report export
and methodology locking require a direct user action, while background
scheduling requires dual opt-in and an exact table allowlist.

### Changes implemented

- Added `operational_store.py` with atomic, permission-restricted local JSON
  writes.
- Added per-dataset integrity history with configurable 90-day and 500-entry
  defaults.
- Integrity history stores only the scorecard, dataset, schema fingerprint,
  timestamp, origin and plan source; raw query-result rows are excluded.
- Added a context-panel integrity card showing the selected dataset's latest
  review and a one-click Run review action.
- Added explicit methodology locking for read-only SQL, schema fingerprint,
  provenance and integrity plan. Result rows are never stored.
- Stale table/fingerprint locks and write SQL are rejected.
- Added browser-generated Markdown export for analytical and integrity
  responses. No server-side report copy is created.
- Added `integrity_scheduler.py` and `scheduler_config.json.example`.
- Scheduling is disabled by default and requires both an environment flag and
  file setting plus a fully qualified table allowlist. The minimum interval is
  15 minutes and `run_on_start` defaults to false.
- Added scheduler state to `/api/status`, summary history through
  `/api/integrity-history`, and methodology locking through `/api/methodology`.
- Added `.avtrix_state/` and live operational config files to `.gitignore`.
- Added `PHASE7_ACCEPTANCE.md` covering history isolation, retention, exports,
  methodology locks, scheduler safety and release security.

### Verification

- Total automated tests: 69 passed.
- Python compilation: passed.
- Rendered inline JavaScript syntax check with Node: passed.
- Summary-only history and raw-value exclusion: passed.
- Retention age and entry-cap pruning: passed.
- Methodology snapshot excludes result rows: passed.
- Write SQL methodology rejection: passed.
- Scheduler dual opt-in, minimum interval and allowlist execution: passed.
- Phase 7 controls render in the browser: passed.
- Live Mac/Databricks release acceptance: pending deployment.

---

## Architecture decisions

### ADR-001 — No table-specific model fine-tuning

Decision: dataset adaptability will be achieved through runtime discovery,
profiling, semantic manifests and retrieval. The model remains replaceable.

### ADR-002 — Short-lived Databricks query connections

Decision: the threaded web application will not share a long-lived Databricks
cursor or connection across requests. Reliability and isolation take precedence
over avoiding connection setup time.

### ADR-003 — Startup default versus active dataset

Decision: `HISTORY_TABLE` identifies only the startup dataset. Runtime queries
use the active dataset stored by the dataset registry.

### ADR-004 — Schema fingerprinting

Decision: column names, data types and comments are canonicalised and hashed.
Stored profiles will be keyed by this fingerprint so schema changes invalidate
stale context automatically.

### ADR-005 — Generic overview replaces default FB overview

Decision: the default overview may only report facts available for any dataset.
Richer statistics will come from the generic profiler rather than hardcoded
aviation columns.

### ADR-006 — Approximate discovery, exact confirmation

Decision: generic profiling uses approximate distinct counts for efficient
discovery. Any candidate identifier or natural key remains unverified until a
separate exact duplicate check confirms it.

### ADR-007 — Profiles are schema-fingerprint scoped

Decision: cached profiles are addressed by dataset reference and live schema
fingerprint. A profile for an older schema is never silently loaded for a newer
schema.

### ADR-008 — Sensitive representative values are suppressed

Decision: representative values may improve semantic understanding, but are
only sampled from bounded low-cardinality fields. Sensitive-looking fields are
excluded, and all value sampling can be disabled by configuration.

### ADR-009 — Deterministic semantic plans before generated SQL

Decision: when an analytical intent can be represented by a verified template,
the application resolves user concepts against live metadata and builds the
query deterministically. Model-generated SQL is a fallback for unsupported
intents, not the first choice for common grouped distributions.

### ADR-010 — One evidence-based SQL correction

Decision: generated SQL may be corrected once using either local schema
validation evidence or the real Databricks SQL error. Authentication, timeout
and connection failures are not model-repair problems, and no recursive retry
loop is permitted.

### ADR-011 — Deterministic plans for recurring analytical shapes

Decision: distributions, temporal trends, rankings and aggregate comparisons
are resolved against live metadata and compiled into bounded SQL before the
model path is considered. The model remains the fallback for unsupported
questions; ambiguity produces clarification instead of a guessed field.

### ADR-012 — Integrity checks are evidence, with configuration outranking inference

Decision: the generic framework may infer conservative candidate fields from
live metadata and an exact matching profile, but an exact per-dataset business
configuration takes precedence. Ambiguous or unavailable roles cause a check to
be skipped. Results use Review/No flags/Not run/Unavailable rather than
Pass/Fail, and no repair or data mutation is performed.

### ADR-013 — Operational persistence is summary-only by default

Decision: integrity history stores scorecards and provenance, not detailed
query rows. Methodology snapshots require an explicit user action and store
read-only SQL without results. Full report content exists only in a manual
browser download unless the user separately chooses to retain it.

### ADR-014 — Scheduling requires dual opt-in and an allowlist

Decision: no background query runs from a configuration file alone. Scheduling
requires an environment flag, an enabled local configuration and explicit fully
qualified tables. It is disabled in the release candidate until live
interactive acceptance is complete.

---

## Known limitations and technical debt

- Existing named shortcuts remain FB-specific analysis packs. The web app hides
  or blocks incompatible shortcuts, but CLI shortcut execution is not yet
  schema-gated.
- Dataset identifiers containing dots, backticks or spaces are not yet supported.
- Discovered objects are currently labelled `TABLE_OR_VIEW`; exact object type
  classification is not yet populated on every Databricks surface.
- Relationships between tables have not yet been inferred.
- Candidate keys receive exact confirmation only when the full browser
  integrity review runs; the structural profiler alone remains approximate.
- Complex columns currently receive null/completeness statistics only.
- Type-format flags use conservative heuristics and may include legitimate
  operational formats; they require review.
- Generic profile performance has not yet been measured against the live
  free-tier warehouse.
- Pre-execution identifier validation is deliberately conservative rather than a
  complete SQL parser. Obvious invented quoted columns are blocked locally;
  remaining Spark semantic errors rely on Databricks evidence and the single
  bounded correction.
- The CLI still starts from its configured table and does not yet expose the
  browser's full catalog/schema selection workflow.
- The CLI `check` command remains completeness-only; the full six-check
  integrity scorecard and drill-downs are currently browser-only.
- Live testing has covered the active dataset only; cross-dataset acceptance on
  at least two structurally different tables is still pending.
- The Stop control currently aborts the browser request. A Databricks statement
  already submitted may continue because the HTTP route does not yet expose a
  cancellable server-side operation handle.
- Semantic plans now cover grouped categorical distributions, temporal trends,
  rankings and aggregate comparisons. Multi-table joins, cohort logic and
  domain-specific rate denominators still require an approved methodology or
  profile-informed model generation.
- A temporal question with equally plausible date fields deliberately requires
  clarification. The system does not yet remember a user-approved preferred
  date field per dataset.
- Date coverage reports observed calendar gaps without knowing the expected
  recording cadence. It cannot independently distinguish a legitimate quiet
  period from missing source records.
- Inferred monotonicity compares the maximum value per entity/timestamp. This
  avoids arbitrary tie ordering but deliberately does not inspect within-time
  sequence when no finer ordering field exists.
- Local state is permission-restricted but not application-encrypted. Protect
  the Mac account and avoid placing `.avtrix_state/` in a shared cloud folder.
- Manual Markdown exports contain the rows visible in the browser. The user
  controls the downloaded file and its onward handling.
- The scheduler is an in-process daemon: it runs only while the web application
  is open, does not backfill missed runs and is not an operating-system service.
- Methodology locking preserves the method and schema identity, not an immutable
  copy or cryptographic hash of the Databricks query result.

---

## Post-build stage — Live acceptance and evidence-led refinement

The seven-phase build is complete locally. The next stage is deliberately not
another construction phase. It is a live acceptance cycle that establishes a
stable V1 baseline before targeted refinement.

Planned outcomes:

- Deploy the V1 release candidate to the Mac.
- Complete the Phase 5, Phase 6 and Phase 7 acceptance sheets against the
  history join, detailed-utilisation table and one unrelated dataset.
- Freeze the accepted behaviour as the V1 baseline.
- Capture failed questions, incorrect field choices, skipped checks, slow
  operations and weak narratives as evidence.
- Refine semantic mappings, routing, prompts, deterministic plans and model
  choice only where the evidence shows a repeatable gap.
- Consider model fine-tuning only if the remaining failures cannot be solved
  reliably through schema discovery, deterministic logic or prompting.

---

## Milestone acceptance checklist

### Milestone 1

- [x] Expired-session recovery implemented.
- [x] Read-only query client implemented.
- [x] Structured API errors implemented.
- [x] Catalog/schema/table discovery implemented.
- [x] Server-side table switching implemented.
- [x] Live schema metadata captured.
- [x] Schema fingerprint implemented.
- [x] Automated tests passed locally.
- [x] Deployed to the Mac.
- [x] Verified against live Databricks.

### Milestone 2

- [x] Generic profiler implemented.
- [x] Profiles cached by schema fingerprint.
- [x] Profile visible in the web interface.
- [x] Offline tests use an unfamiliar synthetic schema.
- [x] No FB-specific field names required by the profiler.
- [ ] Tested live against at least three structurally different datasets.

### Milestone 3

- [x] Compact profile included in model context.
- [x] Generated column references validated before execution.
- [x] Incompatible table-specific shortcuts blocked or hidden.
- [x] One bounded, evidence-based SQL repair attempt implemented.
- [x] Answer provenance includes active dataset and profile identity.
- [ ] Tested with questions across three different dataset structures.

### Milestone 4

- [x] Generic yearly/monthly trend plan implemented.
- [x] Ambiguous temporal fields trigger clarification.
- [x] Generic top/bottom ranking plan implemented.
- [x] Aggregate comparison plan implemented.
- [x] Temporal and ranking results produce evidence-led narratives and visuals.
- [x] Repeatable three-dataset acceptance sheet created.
- [ ] Phase 5 deployed to the Mac.
- [ ] Phase 5 accepted against three different dataset structures.

### Milestone 5

- [x] Decimal and `H:MM` operational-number normaliser implemented.
- [x] Generic exact uniqueness check implemented.
- [x] Generic cumulative monotonicity check implemented.
- [x] Generic event/cumulative consistency check implemented.
- [x] Generic date-coverage check implemented.
- [x] Generic metadata-completeness check implemented.
- [x] Six-check scorecard and evidence tabs implemented.
- [x] Exact per-dataset overrides and ambiguity safeguards implemented.
- [x] Repeatable three-dataset acceptance sheet created.
- [ ] Phase 6 deployed to the Mac.
- [ ] Phase 6 accepted against three different dataset structures.

### Milestone 6

- [x] Summary-only integrity history implemented with bounded retention.
- [x] One-click browser integrity review implemented.
- [x] Methodology locking implemented without persisting result rows.
- [x] User-triggered Markdown report export implemented.
- [x] Retention and sensitive-output controls documented.
- [x] Dual-opt-in, table-allowlisted scheduler implemented and disabled by
  default.
- [x] Repeatable Phase 7 acceptance sheet created.
- [ ] V1 release candidate deployed to the Mac.
- [ ] Phase 7 accepted against three different dataset structures.

---

## Build-log update rules

At every material change:

1. Update the current milestone and phase status.
2. Record what changed and why.
3. Record tests run and their results.
4. Record live verification separately from local automated verification.
5. Add or update an architecture decision when a durable design choice is made.
6. Record known limitations without presenting them as completed work.
7. Update the next action so another session can resume without reconstruction.

## Next action

Deploy the V1 release candidate to the Mac, then complete
`PHASE5_ACCEPTANCE.md`, `PHASE6_ACCEPTANCE.md` and `PHASE7_ACCEPTANCE.md`
against the history join, detailed-utilisation table and one unrelated table.
Record failures and weak outputs without changing the build during the first
pass; use that evidence to prioritise the refinement backlog.

"""Small, deterministic semantic layer for grouped distribution questions.

The layer is table-agnostic: it resolves user phrases against live column
metadata, then builds one read-only aggregate query.  Aviation vocabulary is a
synonym aid, not a table schema or a source of invented columns.
"""

from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Iterable, Optional

from dataset_registry import ColumnMetadata, parse_table_ref, quote_identifier


@dataclass(frozen=True)
class DistributionRequest:
    category_phrase: str
    group_phrase: str


@dataclass(frozen=True)
class ColumnMatch:
    phrase: str
    column: Optional[ColumnMetadata]
    score: int
    ambiguous: tuple[str, ...] = ()


@dataclass(frozen=True)
class TemporalRequest:
    category_phrase: Optional[str]
    period: str


@dataclass(frozen=True)
class RankingRequest:
    dimension_phrase: str
    measure_phrase: str
    aggregation: str
    direction: str
    limit: int
    comparison: bool = False


_CONCEPT_ALIASES = {
    "aircraft_identity": {
        "phrases": {"aircraft", "aircraftregistration", "registration", "tail", "tailnumber"},
        "columns": (
            "aircraftregistration", "acregistration", "acreg", "tailnumber",
            "registration", "tail", "aircraft", "ac",
        ),
    },
    "job_type": {
        "phrases": {"jobtype", "jobcategory", "maintenancetype", "worktype"},
        "columns": ("jobtype", "jobcategory", "maintenancetype", "worktype"),
    },
    "removal_reason": {
        "phrases": {"removalreason", "reasonforremoval", "removalcode", "reason"},
        "columns": ("removalreason", "reasonforremoval", "removalcode", "reason"),
    },
}

_TOKEN_EQUIVALENTS = {
    "aircraft": {"aircraft", "ac", "tail", "registration", "reg"},
    "registration": {"registration", "reg", "tail", "aircraft", "ac"},
    "tail": {"tail", "registration", "reg", "aircraft", "ac"},
    "jobtype": {"jobtype", "job", "type", "work", "category"},
    "job": {"job", "work"},
    "type": {"type", "category", "class"},
    "removal": {"removal", "removed", "remove"},
    "reason": {"reason", "cause", "code"},
}


def _compact(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", (value or "").lower())


def _tokens(value: str) -> set[str]:
    prepared = re.sub(r"([a-z])([A-Z])", r"\1 \2", value or "")
    parts = set(re.findall(r"[a-z0-9]+", prepared.lower()))
    compact = _compact(value)
    if compact:
        parts.add(compact)
    for word in ("aircraft", "registration", "removal", "reason", "job", "type", "component"):
        if word in compact:
            parts.add(word)
    return parts


def parse_distribution_request(question: str) -> Optional[DistributionRequest]:
    """Extract ``category by grouping`` from common distribution wording."""
    q = (question or "").strip().lower()
    q = re.sub(r"[?!.]+$", "", q)
    q = re.sub(
        r"^\s*(?:please\s+)?(?:show|give|display|plot|visuali[sz]e)\s+(?:me\s+)?(?:a\s+|an\s+|the\s+)?",
        "",
        q,
    )
    patterns = (
        r"^(?:distribution|breakdown|spread|mix)\s+of\s+(.+?)\s+by\s+(.+)$",
        r"^(.+?)\s+(?:distribution|breakdown|spread|mix)\s+by\s+(.+)$",
    )
    for pattern in patterns:
        match = re.match(pattern, q)
        if not match:
            continue
        category = match.group(1).strip(" :-")
        group = match.group(2).strip(" :-")
        if category and group:
            return DistributionRequest(category, group)
    return None


def _question_body(question: str) -> str:
    q = (question or "").strip().lower()
    q = re.sub(r"[?!.]+$", "", q)
    return re.sub(
        r"^\s*(?:please\s+)?(?:show|give|display|plot|visuali[sz]e|tell)\s+(?:me\s+)?(?:a\s+|an\s+|the\s+)?",
        "",
        q,
    ).strip()


def parse_temporal_request(question: str) -> Optional[TemporalRequest]:
    """Parse common year/month trend wording without assuming a table schema."""
    q = _question_body(question)
    # An explicit date hint remains in the original question for resolver
    # scoring, but must not become part of the requested category phrase.
    q = re.sub(r"\s+(?:using|based\s+on)\s+.+$", "", q).strip()
    patterns = (
        (r"^(yearly|annual|monthly)\s+(?:distribution|breakdown|spread|trend)(?:\s+of)?\s+(.+)$", 1, 2),
        (r"^(?:distribution|breakdown|spread|trend)\s+of\s+(.+?)\s+by\s+(year|month)$", 2, 1),
        (r"^(.+?)\s+(?:distribution|breakdown|spread|trend)\s+by\s+(year|month)$", 2, 1),
        (r"^(.+?)\s+by\s+(year|month)$", 2, 1),
    )
    for pattern, period_group, category_group in patterns:
        match = re.match(pattern, q)
        if not match:
            continue
        period_text = match.group(period_group)
        period = "month" if period_text == "monthly" or period_text == "month" else "year"
        category = match.group(category_group).strip(" :-")
        category = re.sub(r"^(?:distribution|breakdown|spread|trend)\s+(?:of\s+)?", "", category)
        if category in {"records", "record count", "rows", "row count", "events", "event count"}:
            category = None
        return TemporalRequest(category or None, period)
    return None


def _parse_measure_phrase(value: str) -> tuple[str, str]:
    phrase = (value or "").strip(" :-")
    aggregate_patterns = (
        ("sum", r"^(?:total|sum of|summed)\s+(.+)$"),
        ("avg", r"^(?:average|avg|mean)\s+(.+)$"),
        ("max", r"^(?:highest|maximum|max)\s+(.+)$"),
        ("min", r"^(?:lowest|minimum|min)\s+(.+)$"),
        ("count", r"^(?:count|number of|volume of)\s+(.+)$"),
    )
    for aggregation, pattern in aggregate_patterns:
        match = re.match(pattern, phrase)
        if match:
            return aggregation, match.group(1).strip(" :-")
    return "count", phrase


def parse_ranking_request(question: str) -> Optional[RankingRequest]:
    """Parse explicit top/bottom rankings and aggregate comparisons."""
    q = _question_body(question)
    top_match = re.match(r"^(top|bottom)\s*(\d{1,3})?\s*(.+?)\s+by\s+(.+)$", q)
    if top_match:
        direction = "desc" if top_match.group(1) == "top" else "asc"
        limit = max(1, min(int(top_match.group(2) or 10), 50))
        aggregation, measure = _parse_measure_phrase(top_match.group(4))
        return RankingRequest(top_match.group(3).strip(), measure, aggregation, direction, limit)

    which_match = re.match(
        r"^which\s+(.+?)\s+(?:have|has|show|shows)\s+the\s+"
        r"(most|fewest|least|highest|lowest)\s+(.+)$",
        q,
    )
    if which_match:
        order_word = which_match.group(2)
        direction = "desc" if order_word in {"most", "highest"} else "asc"
        default_aggregation = "max" if order_word in {"highest", "lowest"} else "count"
        explicit_aggregation, measure = _parse_measure_phrase(which_match.group(3))
        aggregation = explicit_aggregation if explicit_aggregation != "count" else default_aggregation
        return RankingRequest(which_match.group(1).strip(), measure, aggregation, direction, 10)

    compare_match = re.match(r"^compare\s+(.+?)\s+(?:across|by|between)\s+(.+)$", q)
    if compare_match:
        aggregation, measure = _parse_measure_phrase(compare_match.group(1))
        return RankingRequest(
            compare_match.group(2).strip(), measure, aggregation, "desc", 50, comparison=True
        )
    return None


def _concept_for_phrase(phrase: str):
    compact = _compact(phrase)
    for concept in _CONCEPT_ALIASES.values():
        if compact in concept["phrases"]:
            return concept
    return None


def _expanded_tokens(value: str) -> set[str]:
    result = _tokens(value)
    for token in tuple(result):
        result.update(_TOKEN_EQUIVALENTS.get(token, {token}))
    return result


def resolve_column(phrase: str, columns: Iterable[ColumnMetadata]) -> ColumnMatch:
    """Resolve a phrase to one live column, surfacing ties as ambiguity."""
    phrase_compact = _compact(phrase)
    phrase_tokens = _expanded_tokens(phrase)
    concept = _concept_for_phrase(phrase)
    scored: list[tuple[int, ColumnMetadata]] = []

    for column in columns:
        column_compact = _compact(column.name)
        column_tokens = _expanded_tokens(" ".join(filter(None, [column.name, column.comment or ""])))
        score = 0
        if phrase_compact and phrase_compact == column_compact:
            score = max(score, 240)
        if len(phrase_compact) >= 4 and phrase_compact in column_compact:
            score = max(score, 130)
        if len(column_compact) >= 4 and column_compact in phrase_compact:
            score = max(score, 115)
        if concept and column_compact in concept["columns"]:
            preference = concept["columns"].index(column_compact)
            score = max(score, 190 - preference)
        overlap = len(phrase_tokens & column_tokens)
        score += overlap * 8
        if score > 0:
            scored.append((score, column))

    if not scored:
        return ColumnMatch(phrase, None, 0)
    scored.sort(key=lambda item: (-item[0], item[1].name.lower()))
    best_score, best_column = scored[0]
    tied = tuple(item[1].name for item in scored if item[0] == best_score)
    if len(tied) > 1:
        return ColumnMatch(phrase, None, best_score, tied)
    return ColumnMatch(phrase, best_column, best_score)


def resolve_temporal_column(question: str, columns: Iterable[ColumnMetadata]) -> ColumnMatch:
    """Select a live date/time field, surfacing genuinely tied candidates."""
    question_tokens = _expanded_tokens(question)
    scored: list[tuple[int, ColumnMetadata]] = []
    for column in columns:
        data_type = (column.data_type or "").lower()
        name_tokens = _expanded_tokens(" ".join(filter(None, [column.name, column.comment or ""])))
        compact_name = _compact(column.name)
        is_typed_date = data_type.startswith(("date", "timestamp"))
        looks_temporal = bool(re.search(r"date|time|timestamp|month|year|(^|_)mos($|_)", column.name, re.I))
        if not is_typed_date and not looks_temporal:
            continue
        score = (120 if is_typed_date else 45) + len(question_tokens & name_tokens) * 10
        if "removal" in question_tokens and "removal" in name_tokens:
            score += 35
        if "installation" in question_tokens and (
            "installation" in name_tokens or "installed" in name_tokens
        ):
            score += 35
        if compact_name in {"date", "eventdate", "recorddate", "transactiondate"}:
            score += 10
        scored.append((score, column))

    if not scored:
        return ColumnMatch("date/time", None, 0)
    scored.sort(key=lambda item: (-item[0], item[1].name.lower()))
    best_score, best_column = scored[0]
    tied = tuple(item[1].name for item in scored if item[0] == best_score)
    if len(tied) > 1:
        return ColumnMatch("date/time", None, best_score, tied)
    return ColumnMatch("date/time", best_column, best_score)


def _quoted_table(table_ref: str) -> str:
    return ".".join(quote_identifier(part) for part in parse_table_ref(table_ref))


def _normalised_dimension(column_name: str) -> str:
    quoted = quote_identifier(column_name)
    text = f"TRIM(CAST({quoted} AS STRING))"
    return (
        "CASE WHEN "
        f"{quoted} IS NULL OR {text} = '' OR LOWER({text}) IN "
        "('-', '--', 'n/a', 'na', 'null', 'none', 'unknown') "
        f"THEN '(Missing)' ELSE {text} END"
    )


def build_grouped_distribution_sql(
    table_ref: str,
    category_column: str,
    group_column: str,
    *,
    top_categories: int = 8,
) -> str:
    """Build valid Spark SQL for a bounded category-by-group distribution."""
    table_sql = _quoted_table(table_ref)
    category_expr = _normalised_dimension(category_column)
    group_expr = _normalised_dimension(group_column)
    limit = max(1, min(int(top_categories), 20))
    return f"""
WITH normalised AS (
    SELECT
        {group_expr} AS group_value,
        {category_expr} AS category_value
    FROM {table_sql}
),
category_totals AS (
    SELECT category_value, COUNT(*) AS category_total
    FROM normalised
    GROUP BY category_value
),
ranked_categories AS (
    SELECT
        category_value,
        ROW_NUMBER() OVER (ORDER BY category_total DESC, category_value ASC) AS category_rank
    FROM category_totals
),
labelled AS (
    SELECT
        n.group_value,
        CASE WHEN r.category_rank <= {limit} THEN n.category_value ELSE '(Other)' END AS category_value
    FROM normalised n
    INNER JOIN ranked_categories r ON n.category_value = r.category_value
),
grouped AS (
    SELECT group_value, category_value, COUNT(*) AS record_count
    FROM labelled
    GROUP BY group_value, category_value
)
SELECT
    group_value,
    category_value,
    record_count,
    ROUND(record_count * 100.0 / NULLIF(SUM(record_count) OVER (PARTITION BY group_value), 0), 1)
        AS pct_within_group
FROM grouped
ORDER BY group_value ASC, record_count DESC, category_value ASC
LIMIT 500
""".strip()


def build_temporal_distribution_sql(
    table_ref: str,
    date_column: str,
    *,
    category_column: Optional[str] = None,
    period: str = "year",
    top_categories: int = 8,
) -> str:
    """Build a bounded year/month record or categorical trend query."""
    table_sql = _quoted_table(table_ref)
    date_sql = quote_identifier(date_column)
    if period not in {"year", "month"}:
        raise ValueError("Temporal period must be year or month.")
    period_expr = (
        f"YEAR(TRY_CAST({date_sql} AS TIMESTAMP))"
        if period == "year"
        else f"DATE_TRUNC('MONTH', TRY_CAST({date_sql} AS TIMESTAMP))"
    )
    if not category_column:
        return f"""
WITH base AS (
    SELECT {period_expr} AS period_value
    FROM {table_sql}
)
SELECT period_value, COUNT(*) AS record_count
FROM base
WHERE period_value IS NOT NULL
GROUP BY period_value
ORDER BY period_value ASC
LIMIT 500
""".strip()

    category_expr = _normalised_dimension(category_column)
    limit = max(1, min(int(top_categories), 20))
    return f"""
WITH normalised AS (
    SELECT
        {period_expr} AS period_value,
        {category_expr} AS category_value
    FROM {table_sql}
),
category_totals AS (
    SELECT category_value, COUNT(*) AS category_total
    FROM normalised
    WHERE period_value IS NOT NULL
    GROUP BY category_value
),
ranked_categories AS (
    SELECT
        category_value,
        ROW_NUMBER() OVER (ORDER BY category_total DESC, category_value ASC) AS category_rank
    FROM category_totals
),
labelled AS (
    SELECT
        n.period_value,
        CASE WHEN r.category_rank <= {limit} THEN n.category_value ELSE '(Other)' END AS category_value
    FROM normalised n
    INNER JOIN ranked_categories r ON n.category_value = r.category_value
    WHERE n.period_value IS NOT NULL
),
grouped AS (
    SELECT period_value, category_value, COUNT(*) AS record_count
    FROM labelled
    GROUP BY period_value, category_value
)
SELECT
    period_value,
    category_value,
    record_count,
    ROUND(record_count * 100.0 / NULLIF(SUM(record_count) OVER (PARTITION BY period_value), 0), 1)
        AS pct_within_period
FROM grouped
ORDER BY period_value ASC, record_count DESC, category_value ASC
LIMIT 500
""".strip()


def build_ranking_sql(
    table_ref: str,
    dimension_column: str,
    *,
    measure_column: Optional[str] = None,
    aggregation: str = "count",
    direction: str = "desc",
    limit: int = 10,
) -> str:
    """Build a schema-grounded grouped ranking/comparison query."""
    if aggregation not in {"count", "sum", "avg", "min", "max"}:
        raise ValueError("Unsupported ranking aggregation.")
    if direction not in {"asc", "desc"}:
        raise ValueError("Ranking direction must be asc or desc.")
    if aggregation != "count" and not measure_column:
        raise ValueError("A measure column is required for this aggregation.")

    table_sql = _quoted_table(table_ref)
    dimension_expr = _normalised_dimension(dimension_column)
    if aggregation == "count" and measure_column:
        measure = quote_identifier(measure_column)
        value_expr = (
            f"SUM(CASE WHEN {measure} IS NULL OR TRIM(CAST({measure} AS STRING)) = '' "
            "THEN 0 ELSE 1 END)"
        )
        value_alias = "record_count"
    elif aggregation == "count":
        value_expr = "COUNT(*)"
        value_alias = "record_count"
    else:
        measure = quote_identifier(measure_column or "")
        function = {"sum": "SUM", "avg": "AVG", "min": "MIN", "max": "MAX"}[aggregation]
        value_expr = f"{function}(TRY_CAST({measure} AS DOUBLE))"
        value_alias = f"{aggregation}_value"

    bounded_limit = max(1, min(int(limit), 50))
    order_sql = "DESC" if direction == "desc" else "ASC"
    return f"""
SELECT
    {dimension_expr} AS dimension_value,
    {value_expr} AS {value_alias},
    COUNT(*) AS group_records
FROM {table_sql}
GROUP BY {dimension_expr}
HAVING {value_expr} IS NOT NULL
ORDER BY {value_alias} {order_sql}, dimension_value ASC
LIMIT {bounded_limit}
""".strip()

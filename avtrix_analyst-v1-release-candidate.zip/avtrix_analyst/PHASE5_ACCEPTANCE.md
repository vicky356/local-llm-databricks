# Phase 5 cross-dataset acceptance

Use this after deploying the Phase 5 package to the Mac. The purpose is to
measure whether the same analytical behaviours work across different schemas,
not to make every dataset answer identical questions.

## Datasets

1. `poc.avtrix_fb.fb_camp_fleet_history_join`
2. `poc.avtrix_fb.unified_fleet_detailed_utilization`
3. One accessible table with a materially different schema

Generate or refresh the profile for each dataset before running the questions.

## Test set

For each dataset, identify one suitable categorical field, grouping field, date
field, numeric measure and entity/dimension field from its live schema. Then run:

1. `Give me a general overview of the active dataset`
2. `Show me a distribution of <category> by <group>`
3. `Show me a yearly distribution of <category>`
4. If more than one date field exists, repeat question 3 and name the intended
   date field when AvTrix asks for clarification.
5. `Top 10 <dimension> by number of records`
6. `Top 10 <dimension> by total <numeric measure>`
7. `Compare average <numeric measure> across <dimension>`
8. Ask one unsupported analytical question to exercise profile-informed model
   generation and the bounded correction path.

## Record for each answer

| Check | Result |
|---|---|
| Correct dataset shown under Sources | Pass / Fail |
| Correct schema fingerprint shown | Pass / Fail |
| Matching profile shown as used | Yes / No |
| SQL source | Semantic template / Local model / Named analysis |
| Correction attempted | Yes / No |
| Query completed | Pass / Fail |
| Visual matches the returned table | Pass / Fail / Not applicable |
| Narrative stays within the evidence | Pass / Fail |
| Approximate response time | Seconds |
| Notes | Free text |

## Acceptance threshold

- All deterministic semantic queries execute without model-generated SQL.
- An ambiguous date or field produces a useful clarification rather than a
  guessed column.
- No incompatible named shortcut reaches Databricks.
- Every successful analytical response identifies its dataset, schema and SQL
  source under Sources.
- Unsupported questions use no more than one SQL correction attempt.
- Any failure is captured with the exact question, active dataset and safe
  Databricks error before the next implementation change is selected.


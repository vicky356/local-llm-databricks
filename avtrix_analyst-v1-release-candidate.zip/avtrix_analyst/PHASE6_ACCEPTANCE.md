# Phase 6 Acceptance — Generic Integrity Framework

Run this after deploying the Phase 6 package to the Mac. Use three structurally
different Databricks datasets; do not make any source-data changes during this
test.

## Safety rule

A flag is evidence for review, not proof that data is wrong. Do not change,
merge or delete data from these results. Confirm record history, dependencies
and the owning business rule first.

## Test datasets

| Dataset | Structure | Profile generated? | Result |
|---|---|---:|---|
| `poc.avtrix_fb.fb_camp_fleet_history_join` | maintenance history |  |  |
| `poc.avtrix_fb.unified_fleet_detailed_utilization` | utilisation/cumulative values |  |  |
|  | structurally different third dataset |  |  |

## Repeat for each dataset

1. Select the dataset in the browser and confirm its name in the context panel.
2. Generate or refresh its dataset profile.
3. Ask: `run a data integrity check`.
4. Confirm the response shows one scorecard row for each of the six checks.
5. Open every available evidence tab and record the observations below.
6. Open Sources and confirm the active table and schema fingerprint match the
   selected dataset.
7. Confirm no `INSERT`, `UPDATE`, `DELETE`, `MERGE`, `CREATE`, `ALTER`, `DROP`,
   `TRUNCATE` or other write operation was issued.

## Evidence capture

| Dataset | Check | Status | Flags | Evidence sensible? | Notes / screenshot |
|---|---|---|---:|---:|---|
|  | Completeness |  |  |  |  |
|  | Uniqueness |  |  |  |  |
|  | Monotonicity |  |  |  |  |
|  | Cross-column consistency |  |  |  |  |
|  | Date coverage |  |  |  |  |
|  | Metadata completeness |  |  |  |  |

Copy the six rows above for the other two datasets.

## Specific acceptance checks

- Decimal operational values and a known `H:MM` value are parsed without a SQL
  failure. If the dataset has no `H:MM` values, record `not present` rather than
  manufacturing one in production.
- A cumulative field is checked only when its role is defensible from the live
  schema/profile or explicitly configured.
- TSI, TSN and TSO are not automatically treated as cumulative counters. Add
  them only through the dataset config when the owning methodology requires it.
- If two date fields are equally plausible, date coverage and monotonicity are
  not guessed; the planning notes request `order_column` configuration.
- Exact duplicate-key groups are reported separately from missing key values.
- Date gaps are described as observed calendar gaps, not automatically as
  missing records.
- An optional check failure appears as `Unavailable` without erasing the other
  completed checks.
- Unknown configured field names appear in planning notes and are not queried.
- The scorecard and each evidence tab open correctly in both Focused and Analyst
  views.

## Optional configured-plan test

1. Copy `integrity_config.json.example` to `integrity_config.json`.
2. Add one exact dataset reference and verified live field names.
3. Restart AvTrix and rerun the review.
4. Confirm the narrative says the plan is **configured**.
5. Temporarily misspell one field, rerun, and confirm it is ignored with a
   planning note rather than sent to Databricks.
6. Restore the correct configuration.

## Acceptance decision

Phase 6 is accepted when all three datasets complete the review without source
mutation, ambiguous roles are skipped rather than guessed, the detailed tabs
match the scorecard, and every observed flag is worded as review evidence.

Accepted by: ____________________  Date: ____________________


"""Privacy-conscious local operational records for AvTrix.

Integrity history contains scorecard summaries only. Methodology snapshots keep
the question, read-only SQL and provenance, but never query result rows. These
records support reproducibility without silently creating a second data store.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import threading
from typing import Any, Optional

from databricks_client import validate_read_only_sql


_SAFE_NAME = re.compile(r"[^A-Za-z0-9_.-]+")


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso_utc(value: Optional[datetime] = None) -> str:
    return (value or _utc_now()).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _parse_time(value: Any) -> Optional[datetime]:
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).astimezone(timezone.utc)
    except (TypeError, ValueError):
        return None


def _atomic_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False, default=str),
        encoding="utf-8",
    )
    try:
        os.chmod(temporary, 0o600)
    except OSError:
        pass
    os.replace(temporary, path)


def _bounded_text(value: Any, maximum: int = 4000) -> str:
    return str(value or "")[:maximum]


class OperationalStore:
    """Persist bounded summaries and explicitly locked methodologies locally."""

    def __init__(
        self,
        root: Path | str,
        *,
        retention_days: int = 90,
        max_history_entries: int = 500,
    ) -> None:
        self.root = Path(root)
        self.history_path = self.root / "integrity_history.json"
        self.methodology_dir = self.root / "methodologies"
        self.retention_days = max(1, int(retention_days))
        self.max_history_entries = max(1, int(max_history_entries))
        self._lock = threading.RLock()

    def _read_history(self) -> list[dict[str, Any]]:
        if not self.history_path.exists():
            return []
        try:
            payload = json.loads(self.history_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return []
        return [item for item in payload if isinstance(item, dict)] if isinstance(payload, list) else []

    def _prune(self, records: list[dict[str, Any]], now: Optional[datetime] = None) -> list[dict[str, Any]]:
        reference = now or _utc_now()
        if reference.tzinfo is None:
            reference = reference.replace(tzinfo=timezone.utc)
        else:
            reference = reference.astimezone(timezone.utc)
        threshold = reference - timedelta(days=self.retention_days)
        retained = []
        for record in records:
            created = _parse_time(record.get("checked_at"))
            if created is not None and created >= threshold:
                retained.append(record)
        retained.sort(key=lambda item: str(item.get("checked_at") or ""), reverse=True)
        return retained[: self.max_history_entries]

    @staticmethod
    def _scorecard(result: dict[str, Any]) -> list[dict[str, Any]]:
        columns = [str(column) for column in (result.get("columns") or [])]
        allowed = {"Check", "Scope", "Status", "Flags", "Population", "Evidence"}
        if not columns or not set(columns).issubset(allowed):
            return []
        scorecard = []
        for row in (result.get("rows") or [])[:12]:
            mapped = dict(zip(columns, row))
            scorecard.append({
                key: mapped.get(key) if isinstance(mapped.get(key), (int, float)) else _bounded_text(mapped.get(key), 1000)
                for key in columns
            })
        return scorecard

    def record_integrity(
        self,
        metadata,
        result: dict[str, Any],
        *,
        origin: str = "interactive",
        checked_at: Optional[datetime] = None,
    ) -> dict[str, Any]:
        """Store summary-only evidence; detailed query rows are intentionally omitted."""
        scorecard = self._scorecard(result)
        statuses = {"Review": 0, "No flags": 0, "Not run": 0, "Unavailable": 0}
        for check in scorecard:
            status = str(check.get("Status") or "")
            if status in statuses:
                statuses[status] += 1
        timestamp = _iso_utc(checked_at)
        identity = hashlib.sha256(
            f"{metadata.table_ref}|{metadata.schema_fingerprint}|{timestamp}".encode("utf-8")
        ).hexdigest()[:16]
        plan = result.get("integrity_plan") or {}
        record = {
            "record_id": identity,
            "checked_at": timestamp,
            "origin": "scheduled" if origin == "scheduled" else "interactive",
            "dataset": metadata.table_ref,
            "schema_fingerprint": metadata.schema_fingerprint,
            "plan_source": _bounded_text(plan.get("source"), 50),
            "statuses": statuses,
            "scorecard": scorecard,
        }
        with self._lock:
            records = self._read_history()
            records.insert(0, record)
            _atomic_json(self.history_path, self._prune(records, now=checked_at))
        return record

    def list_integrity_history(self, table_ref: Optional[str] = None, *, limit: int = 20) -> list[dict[str, Any]]:
        with self._lock:
            records = self._prune(self._read_history())
            if table_ref:
                records = [record for record in records if record.get("dataset") == table_ref]
            return records[: max(1, min(int(limit), 100))]

    def latest_integrity(self, table_ref: str) -> Optional[dict[str, Any]]:
        records = self.list_integrity_history(table_ref, limit=1)
        return records[0] if records else None

    def save_methodology(
        self,
        *,
        metadata,
        question: str,
        intent: str,
        sql: str,
        sql_statements: Optional[dict[str, str]] = None,
        provenance: Optional[dict[str, Any]] = None,
        integrity_plan: Optional[dict[str, Any]] = None,
        saved_at: Optional[datetime] = None,
    ) -> dict[str, Any]:
        """Explicitly save a reproducible read-only method without result data."""
        statements = {
            _bounded_text(name, 100): _bounded_text(statement, 50000)
            for name, statement in (sql_statements or {}).items()
            if isinstance(name, str) and isinstance(statement, str) and statement.strip()
        }
        candidates = list(statements.values()) + ([sql] if sql else [])
        if not candidates:
            raise ValueError("No read-only SQL methodology was provided.")
        for statement in candidates:
            validation_error = validate_read_only_sql(statement)
            if validation_error:
                raise ValueError(validation_error.message)
        timestamp = _iso_utc(saved_at)
        digest = hashlib.sha256(
            f"{metadata.table_ref}|{metadata.schema_fingerprint}|{question}|{sql}".encode("utf-8")
        ).hexdigest()[:12]
        stamp = timestamp.replace(":", "").replace("-", "").replace("T", "-").replace("Z", "")
        dataset_name = _SAFE_NAME.sub("-", metadata.table)[:60].strip("-") or "dataset"
        filename = f"{stamp}-{dataset_name}-{digest}.json"
        safe_provenance = {
            key: (value if isinstance(value, (bool, int, float)) or value is None else _bounded_text(value, 1000))
            for key, value in (provenance or {}).items()
            if key in {
                "dataset", "schema_fingerprint", "profile_used", "profile_generated_at",
                "sql_source", "repair_attempted", "repair_succeeded",
            }
        }
        safe_plan = None
        if isinstance(integrity_plan, dict):
            safe_plan = {
                key: _bounded_text(integrity_plan.get(key), 1000)
                for key in {"table_ref", "schema_fingerprint", "order_column", "source"}
                if key in integrity_plan
            }
            for key in {
                "key_columns", "entity_columns", "cumulative_columns",
                "metadata_columns", "review_notes",
            }:
                values = integrity_plan.get(key)
                if isinstance(values, list):
                    safe_plan[key] = [_bounded_text(value, 500) for value in values[:50]]
            pairs = integrity_plan.get("consistency_pairs")
            if isinstance(pairs, list):
                safe_plan["consistency_pairs"] = [
                    {
                        "event": _bounded_text(pair.get("event"), 500),
                        "cumulative": _bounded_text(pair.get("cumulative"), 500),
                    }
                    for pair in pairs[:20] if isinstance(pair, dict)
                ]
        payload = {
            "methodology_version": 1,
            "saved_at": timestamp,
            "question": _bounded_text(question, 4000),
            "intent": _bounded_text(intent, 100),
            "dataset": metadata.to_dict(include_columns=False),
            "sql": _bounded_text(sql, 50000),
            "sql_statements": statements,
            "provenance": safe_provenance,
            "integrity_plan": safe_plan,
            "result_rows_stored": False,
        }
        path = self.methodology_dir / filename
        with self._lock:
            _atomic_json(path, payload)
        return {
            "saved_at": timestamp,
            "filename": filename,
            "path": str(path),
            "result_rows_stored": False,
        }


import unittest

from databricks_client import validate_read_only_sql
from dataset_registry import ColumnMetadata
from semantic_layer import (
    build_grouped_distribution_sql,
    build_ranking_sql,
    build_temporal_distribution_sql,
    parse_distribution_request,
    parse_ranking_request,
    parse_temporal_request,
    resolve_column,
    resolve_temporal_column,
)


class SemanticLayerTests(unittest.TestCase):
    def setUp(self):
        self.columns = (
            ColumnMetadata("AC_REG", "string", "Aircraft registration"),
            ColumnMetadata("JOBTYPE", "string", "Scheduled or unscheduled job type"),
            ColumnMetadata("REASON", "string", "Reason for component removal"),
            ColumnMetadata("EVENT_DATE", "date"),
        )

    def test_parses_reported_distribution_phrases(self):
        reason = parse_distribution_request(
            "show me a distribution of removal reason by aircraft"
        )
        jobtype = parse_distribution_request(
            "show me a distribution of jobtype by aircraft"
        )
        self.assertEqual(reason.category_phrase, "removal reason")
        self.assertEqual(reason.group_phrase, "aircraft")
        self.assertEqual(jobtype.category_phrase, "jobtype")
        self.assertEqual(jobtype.group_phrase, "aircraft")

    def test_resolves_phrases_against_live_columns(self):
        self.assertEqual(resolve_column("removal reason", self.columns).column.name, "REASON")
        self.assertEqual(resolve_column("jobtype", self.columns).column.name, "JOBTYPE")
        self.assertEqual(resolve_column("aircraft", self.columns).column.name, "AC_REG")

    def test_grouped_sql_is_bounded_read_only_and_grouped(self):
        sql = build_grouped_distribution_sql(
            "catalog.schema.any_dataset", "REASON", "AC_REG"
        )
        self.assertIsNone(validate_read_only_sql(sql))
        self.assertIn("GROUP BY group_value, category_value", sql)
        self.assertIn("PARTITION BY group_value", sql)
        self.assertIn("`catalog`.`schema`.`any_dataset`", sql)
        self.assertIn("LIMIT 500", sql)
        self.assertIn("'(Missing)'", sql)

    def test_parses_yearly_and_monthly_trend_requests(self):
        yearly = parse_temporal_request("show me a yearly distribution of job types")
        monthly = parse_temporal_request("removal reason by month")
        explicit = parse_temporal_request(
            "yearly distribution of job types using removal date"
        )
        self.assertEqual(yearly.category_phrase, "job types")
        self.assertEqual(yearly.period, "year")
        self.assertEqual(monthly.category_phrase, "removal reason")
        self.assertEqual(monthly.period, "month")
        self.assertEqual(explicit.category_phrase, "job types")

    def test_temporal_column_resolution_uses_live_types_and_question_hint(self):
        columns = (
            ColumnMetadata("installed_date", "date"),
            ColumnMetadata("removal_date", "date"),
            ColumnMetadata("job_type", "string"),
        )
        resolved = resolve_temporal_column("yearly removal job type", columns)
        ambiguous = resolve_temporal_column("yearly job type", columns)
        self.assertEqual(resolved.column.name, "removal_date")
        self.assertIsNone(ambiguous.column)
        self.assertEqual(set(ambiguous.ambiguous), {"installed_date", "removal_date"})

    def test_temporal_sql_is_bounded_and_groups_every_selected_dimension(self):
        sql = build_temporal_distribution_sql(
            "catalog.schema.any_dataset",
            "EVENT_DATE",
            category_column="JOBTYPE",
            period="year",
        )
        self.assertIsNone(validate_read_only_sql(sql))
        self.assertIn("YEAR(TRY_CAST(`EVENT_DATE` AS TIMESTAMP))", sql)
        self.assertIn("GROUP BY period_value, category_value", sql)
        self.assertIn("PARTITION BY period_value", sql)
        self.assertIn("LIMIT 500", sql)

    def test_parses_rankings_and_comparisons(self):
        ranking = parse_ranking_request("top 5 suppliers by total cost")
        comparison = parse_ranking_request("compare average cost across aircraft")
        self.assertEqual(ranking.dimension_phrase, "suppliers")
        self.assertEqual(ranking.measure_phrase, "cost")
        self.assertEqual(ranking.aggregation, "sum")
        self.assertEqual(ranking.limit, 5)
        self.assertEqual(comparison.dimension_phrase, "aircraft")
        self.assertEqual(comparison.aggregation, "avg")
        self.assertTrue(comparison.comparison)

    def test_ranking_sql_uses_exact_live_columns_and_sample_size(self):
        sql = build_ranking_sql(
            "catalog.schema.any_dataset",
            "supplier",
            measure_column="cost",
            aggregation="sum",
            direction="desc",
            limit=5,
        )
        self.assertIsNone(validate_read_only_sql(sql))
        self.assertIn("TRY_CAST(`cost` AS DOUBLE)", sql)
        self.assertIn("COUNT(*) AS group_records", sql)
        self.assertIn("GROUP BY", sql)
        self.assertIn("LIMIT 5", sql)


if __name__ == "__main__":
    unittest.main()

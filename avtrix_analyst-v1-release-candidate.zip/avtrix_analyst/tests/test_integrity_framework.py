import json
from pathlib import Path
import tempfile
import unittest

from databricks_client import validate_read_only_sql
from dataset_registry import ColumnMetadata, DatasetMetadata
from integrity_framework import (
    build_consistency_sql,
    build_date_coverage_sql,
    build_integrity_plan,
    build_monotonicity_sql,
    build_uniqueness_sql,
    load_integrity_overrides,
    operational_number_sql,
    parse_operational_number,
)


class IntegrityFrameworkTests(unittest.TestCase):
    def setUp(self):
        self.metadata = DatasetMetadata(
            table_ref="catalog.schema.unfamiliar_events",
            catalog="catalog",
            schema="schema",
            table="unfamiliar_events",
            object_type="TABLE",
            columns=(
                ColumnMetadata("aircraft_registration", "string"),
                ColumnMetadata("event_date", "date"),
                ColumnMetadata("event_number", "bigint"),
                ColumnMetadata("engine_hours", "string"),
                ColumnMetadata("engine_cum_hours", "string"),
                ColumnMetadata("TSI", "string"),
                ColumnMetadata("model", "string"),
                ColumnMetadata("serial_number", "string"),
            ),
            schema_fingerprint="synthetic-fingerprint",
        )
        self.profile = {
            "record_count": 100,
            "candidate_identifiers": [],
            "candidate_natural_keys": [
                {"columns": ["aircraft_registration", "event_date", "event_number"]}
            ],
            "columns": [
                {
                    "name": "aircraft_registration", "inferred_role": "identifier",
                    "missing_count": 0, "missing_rate": 0, "numeric_like_count": 0,
                },
                {
                    "name": "event_date", "inferred_role": "date", "missing_count": 0,
                    "missing_rate": 0, "date_like_count": 100, "numeric_like_count": 0,
                },
                {
                    "name": "event_number", "inferred_role": "measure", "missing_count": 0,
                    "missing_rate": 0, "numeric_like_count": 100,
                },
                {
                    "name": "engine_hours", "inferred_role": "measure", "missing_count": 0,
                    "missing_rate": 0, "numeric_like_count": 100,
                },
                {
                    "name": "engine_cum_hours", "inferred_role": "cumulative", "missing_count": 0,
                    "missing_rate": 0, "numeric_like_count": 100,
                },
                {
                    "name": "TSI", "inferred_role": "measure", "missing_count": 0,
                    "missing_rate": 0, "numeric_like_count": 100,
                },
                {
                    "name": "model", "inferred_role": "dimension", "missing_count": 2,
                    "missing_rate": 0.02, "numeric_like_count": 0,
                },
                {
                    "name": "serial_number", "inferred_role": "identifier", "missing_count": 3,
                    "missing_rate": 0.03, "numeric_like_count": 0,
                },
            ],
        }

    def test_operational_number_parser_handles_decimal_and_hour_minute(self):
        self.assertEqual(parse_operational_number("15.30"), 15.3)
        self.assertAlmostEqual(parse_operational_number("9:12"), 9.2)
        self.assertAlmostEqual(parse_operational_number("-1:30"), -1.5)
        self.assertIsNone(parse_operational_number("9:75"))
        self.assertIsNone(parse_operational_number("not-a-number"))

    def test_sql_number_parser_is_identifier_safe_and_uses_try_cast(self):
        sql = operational_number_sql("engine_hours")
        self.assertIn("`engine_hours`", sql)
        self.assertIn("REGEXP_EXTRACT", sql)
        self.assertIn("TRY_CAST", sql)
        self.assertIn("< 60", sql)

    def test_plan_is_inferred_from_unfamiliar_live_schema_and_profile(self):
        plan = build_integrity_plan(self.metadata, self.profile)
        self.assertEqual(plan.entity_columns, ("aircraft_registration",))
        self.assertEqual(plan.order_column, "event_date")
        self.assertEqual(plan.cumulative_columns, ("engine_cum_hours",))
        self.assertNotIn("TSI", plan.cumulative_columns)
        self.assertEqual(plan.consistency_pairs, (("engine_hours", "engine_cum_hours"),))
        self.assertEqual(
            plan.key_columns,
            ("aircraft_registration", "event_date", "event_number"),
        )
        self.assertIn("model", plan.metadata_columns)
        self.assertIn("serial_number", plan.metadata_columns)

    def test_all_generated_checks_are_single_read_only_statements(self):
        plan = build_integrity_plan(self.metadata, self.profile)
        statements = [
            build_uniqueness_sql(plan),
            build_monotonicity_sql(plan),
            build_consistency_sql(plan),
            build_date_coverage_sql(plan),
        ]
        for sql in statements:
            self.assertIsNotNone(sql)
            self.assertIsNone(validate_read_only_sql(sql))
        self.assertIn("HAVING COUNT(*) > 1", statements[0])
        self.assertIn("LAG(metric_0)", statements[1])
        self.assertIn("FROM collapsed", statements[1])
        self.assertIn("event_0 > cumulative_0", statements[2])
        self.assertIn("largest_gap_days", statements[3])

    def test_exact_overrides_can_disable_or_define_checks(self):
        overrides = {
            "key_columns": [],
            "entity_columns": ["aircraft_registration"],
            "order_column": "event_date",
            "cumulative_columns": ["TSI"],
            "consistency_pairs": [],
            "metadata_columns": ["unknown_field", "model"],
        }
        plan = build_integrity_plan(self.metadata, self.profile, overrides)
        self.assertEqual(plan.source, "configured")
        self.assertEqual(plan.key_columns, ())
        self.assertEqual(plan.cumulative_columns, ("TSI",))
        self.assertEqual(plan.consistency_pairs, ())
        self.assertEqual(plan.metadata_columns, ("model",))
        self.assertTrue(any("unknown_field" in note for note in plan.review_notes))

    def test_ambiguous_typed_dates_are_not_guessed(self):
        metadata = DatasetMetadata(
            table_ref="catalog.schema.ambiguous_dates",
            catalog="catalog",
            schema="schema",
            table="ambiguous_dates",
            object_type="TABLE",
            columns=(
                ColumnMetadata("asset_id", "string"),
                ColumnMetadata("start_date", "date"),
                ColumnMetadata("end_date", "date"),
            ),
            schema_fingerprint="ambiguous",
        )
        plan = build_integrity_plan(metadata)
        self.assertIsNone(plan.order_column)
        self.assertTrue(any("equally plausible" in note for note in plan.review_notes))

    def test_config_loader_uses_exact_table_reference(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "integrity.json"
            path.write_text(json.dumps({
                "datasets": {
                    self.metadata.table_ref: {"key_columns": ["event_number"]},
                    "catalog.schema.other": {"key_columns": ["other_id"]},
                }
            }), encoding="utf-8")
            configured, error = load_integrity_overrides(path, self.metadata.table_ref)
        self.assertIsNone(error)
        self.assertEqual(configured, {"key_columns": ["event_number"]})


if __name__ == "__main__":
    unittest.main()

import unittest

from databricks_client import QueryError
from dataset_registry import ColumnMetadata, DatasetMetadata
from query_reasoning import (
    build_reasoning_context,
    is_repairable_sql_error,
    missing_shortcut_columns,
    select_relevant_columns,
    validate_generated_sql,
)


def metadata():
    return DatasetMetadata(
        table_ref="catalog.schema.any_dataset",
        catalog="catalog",
        schema="schema",
        table="any_dataset",
        object_type="TABLE",
        columns=(
            ColumnMetadata("aircraft_registration", "string", "Aircraft tail registration"),
            ColumnMetadata("event_date", "date", "Date of event"),
            ColumnMetadata("event_cost", "double", "Cost of the event"),
            ColumnMetadata("event_status", "string", "Workflow status"),
            ColumnMetadata("contact_name", "string", "Named contact"),
        ),
        schema_fingerprint="abc123",
    )


def profile():
    return {
        "generated_at": "2026-10-11T10:00:00+00:00",
        "record_count": 120,
        "columns": [
            {
                "name": "event_cost", "inferred_role": "measure", "missing_rate": 0.05,
                "approx_distinct_count": 80, "min": 10, "max": 900, "mean": 155.5,
                "values_suppressed": False, "representative_values": [], "anomalies": [],
            },
            {
                "name": "event_status", "inferred_role": "dimension", "missing_rate": 0,
                "approx_distinct_count": 2, "values_suppressed": False,
                "representative_values": [{"value": "OPEN", "count": 70}], "anomalies": [],
            },
            {
                "name": "contact_name", "inferred_role": "dimension", "missing_rate": 0,
                "approx_distinct_count": 2, "values_suppressed": True,
                "representative_values": [{"value": "SECRET PERSON", "count": 1}], "anomalies": [],
            },
        ],
    }


class QueryReasoningTests(unittest.TestCase):
    def test_context_uses_live_schema_and_safe_matching_profile(self):
        context = build_reasoning_context(metadata(), profile(), "cost by status")

        self.assertIn("catalog.schema.any_dataset", context)
        self.assertIn("SCHEMA FINGERPRINT: abc123", context)
        self.assertIn("`event_cost` (double)", context)
        self.assertIn("mean=155.5", context)
        self.assertIn("sample_categories=OPEN", context)
        self.assertNotIn("SECRET PERSON", context)

    def test_question_terms_prioritise_relevant_columns(self):
        selected = select_relevant_columns(metadata(), profile(), "cost by status", limit=2)
        self.assertEqual(selected, ["event_cost", "event_status"])

    def test_generated_sql_rejects_an_invented_quoted_column(self):
        sql = (
            "SELECT `aircraft_registration`, COUNT(`invented_reason`) AS event_count "
            "FROM `catalog`.`schema`.`any_dataset` GROUP BY `aircraft_registration`"
        )
        issues = validate_generated_sql(sql, metadata())
        self.assertTrue(any("invented_reason" in issue for issue in issues))

    def test_generated_sql_accepts_live_columns_and_output_aliases(self):
        sql = (
            "SELECT `event_status`, COUNT(*) AS `event_count` "
            "FROM `catalog`.`schema`.`any_dataset` GROUP BY `event_status` "
            "ORDER BY `event_count` DESC LIMIT 500"
        )
        self.assertEqual(validate_generated_sql(sql, metadata()), [])

    def test_shortcut_compatibility_uses_explicit_manifest(self):
        shortcut = {"required_columns": ["event_status", "missing_field"]}
        self.assertEqual(missing_shortcut_columns(shortcut, metadata()), ["missing_field"])

    def test_only_sql_errors_are_eligible_for_model_correction(self):
        self.assertTrue(is_repairable_sql_error(QueryError(
            "sql", "Databricks rejected the SQL query.", False, "[MISSING_GROUP_BY]"
        )))
        self.assertFalse(is_repairable_sql_error(QueryError(
            "timeout", "The request timed out.", True
        )))
        self.assertFalse(is_repairable_sql_error(QueryError(
            "authentication", "Authentication failed.", False
        )))


if __name__ == "__main__":
    unittest.main()


import re
import tempfile
import unittest
from pathlib import Path

from databricks_client import QueryOutcome
from dataset_profiler import DatasetProfiler, ProfileStore, ProfilerConfig
from dataset_registry import ColumnMetadata, DatasetMetadata


def metadata(fingerprint="schema-a", columns=None):
    return DatasetMetadata(
        table_ref="catalog.schema.any_dataset",
        catalog="catalog",
        schema="schema",
        table="any_dataset",
        object_type="TABLE",
        columns=tuple(columns or [
            ColumnMetadata("record_id", "string"),
            ColumnMetadata("event_date", "date"),
            ColumnMetadata("hours", "double"),
            ColumnMetadata("status", "string"),
            ColumnMetadata("contact_name", "string"),
        ]),
        schema_fingerprint=fingerprint,
    )


class ProfileClient:
    def __init__(self):
        self.queries = []

    def execute(self, sql_text, *, table_ref=None):
        self.queries.append((sql_text, table_ref))
        if sql_text.startswith("SELECT COUNT(*)"):
            return QueryOutcome(["total_records"], [[4]])
        if "approx_count_distinct" in sql_text:
            aliases = re.findall(r"AS `([^`]+)`", sql_text)
            values = {}
            for alias in aliases:
                values[alias] = 0
            values.update({
                "c0000_distinct": 4,
                "c0000_numeric_like": 4,
                "c0000_min_length": 1,
                "c0000_max_length": 1,
                "c0001_distinct": 4,
                "c0001_min": "2024-01-01",
                "c0001_max": "2024-01-04",
                "c0002_distinct": 4,
                "c0002_min": 1.5,
                "c0002_max": 9.0,
                "c0002_mean": 4.75,
                "c0002_stddev": 2.5,
                "c0003_distinct": 2,
                "c0003_min_length": 4,
                "c0003_max_length": 6,
                "c0004_distinct": 2,
                "c0004_min_length": 3,
                "c0004_max_length": 5,
            })
            return QueryOutcome(aliases, [[values[alias] for alias in aliases]])
        if "GROUP BY `status`" in sql_text:
            return QueryOutcome(["value", "value_count"], [["OPEN", 3], ["CLOSED", 1]])
        if "GROUP BY `record_id`" in sql_text:
            return QueryOutcome(["value", "value_count"], [["1", 1], ["2", 1]])
        if "GROUP BY `hours`" in sql_text:
            return QueryOutcome(["value", "value_count"], [["1.5", 1], ["9.0", 1]])
        raise AssertionError(f"Unexpected SQL: {sql_text}")


class DatasetProfilerTests(unittest.TestCase):
    def test_profiles_an_unfamiliar_schema_without_table_specific_fields(self):
        client = ProfileClient()
        with tempfile.TemporaryDirectory() as temp_dir:
            profiler = DatasetProfiler(
                client,
                ProfileStore(Path(temp_dir)),
                ProfilerConfig(sample_values_enabled=False),
            )
            outcome = profiler.get_or_create(metadata())

        self.assertTrue(outcome.ok)
        self.assertFalse(outcome.cached)
        profile = outcome.profile
        self.assertEqual(profile["record_count"], 4)
        self.assertEqual(profile["column_count"], 5)
        self.assertEqual(profile["columns"][1]["inferred_role"], "date")
        self.assertEqual(profile["columns"][2]["inferred_role"], "measure")
        self.assertEqual(profile["columns"][2]["mean"], 4.75)
        self.assertEqual(profile["columns"][2]["stddev"], 2.5)
        self.assertTrue(profile["candidate_identifiers"])
        generated_sql = "\n".join(query for query, _ in client.queries)
        self.assertIn("`catalog`.`schema`.`any_dataset`", generated_sql)
        self.assertNotIn("AC_Reg", generated_sql)
        self.assertNotIn("Job_Type", generated_sql)

    def test_cache_is_used_only_for_the_same_schema_fingerprint(self):
        client = ProfileClient()
        with tempfile.TemporaryDirectory() as temp_dir:
            store = ProfileStore(Path(temp_dir))
            profiler = DatasetProfiler(
                client,
                store,
                ProfilerConfig(sample_values_enabled=False),
            )
            first = profiler.get_or_create(metadata("schema-a"))
            queries_after_first = len(client.queries)
            second = profiler.get_or_create(metadata("schema-a"))

            self.assertTrue(first.ok)
            self.assertTrue(second.cached)
            self.assertEqual(len(client.queries), queries_after_first)
            self.assertIsNone(store.load(metadata("schema-b")))

    def test_sensitive_columns_do_not_store_representative_values(self):
        client = ProfileClient()
        with tempfile.TemporaryDirectory() as temp_dir:
            profiler = DatasetProfiler(
                client,
                ProfileStore(Path(temp_dir)),
                ProfilerConfig(
                    sample_values_enabled=True,
                    low_cardinality_threshold=4,
                    max_value_columns=10,
                ),
            )
            outcome = profiler.get_or_create(metadata())

        self.assertTrue(outcome.ok)
        by_name = {column["name"]: column for column in outcome.profile["columns"]}
        self.assertEqual(by_name["status"]["representative_values"][0]["value"], "OPEN")
        self.assertTrue(by_name["contact_name"]["values_suppressed"])
        self.assertEqual(by_name["contact_name"]["representative_values"], [])
        self.assertFalse(any("GROUP BY `contact_name`" in sql for sql, _ in client.queries))

    def test_suggests_a_composite_natural_key_for_review_without_claiming_uniqueness(self):
        client = ProfileClient()
        key_metadata = metadata(columns=[
            ColumnMetadata("AC_Reg", "string"),
            ColumnMetadata("Event_Date", "date"),
            ColumnMetadata("Leg_Num", "bigint"),
        ])
        with tempfile.TemporaryDirectory() as temp_dir:
            outcome = DatasetProfiler(
                client,
                ProfileStore(Path(temp_dir)),
                ProfilerConfig(sample_values_enabled=False),
            ).get_or_create(key_metadata)

        self.assertTrue(outcome.ok)
        suggestion = outcome.profile["candidate_natural_keys"][0]
        self.assertEqual(suggestion["columns"], ["AC_Reg", "Event_Date", "Leg_Num"])
        self.assertTrue(suggestion["requires_validation"])
        self.assertIn("has not been tested", suggestion["basis"])


if __name__ == "__main__":
    unittest.main()

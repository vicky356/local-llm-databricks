from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import tempfile
import unittest

from dataset_registry import ColumnMetadata, DatasetMetadata
from integrity_scheduler import IntegrityScheduler, load_scheduler_config
from operational_store import OperationalStore


class OperationalStoreTests(unittest.TestCase):
    def setUp(self):
        self.metadata = DatasetMetadata(
            table_ref="catalog.schema.events",
            catalog="catalog",
            schema="schema",
            table="events",
            object_type="TABLE",
            columns=(ColumnMetadata("event_id", "bigint"),),
            schema_fingerprint="phase7-fingerprint",
        )
        self.result = {
            "columns": ["Check", "Scope", "Status", "Flags", "Population", "Evidence"],
            "rows": [
                ["Completeness", "1 live field", "Review", 1, "10 rows", "1 field is incomplete"],
                ["Uniqueness", "event_id", "No flags", 0, "10 rows", "No exact duplicates"],
            ],
            "answer": "raw-secret-value",
            "integrity_details": [{"rows": [["raw-secret-value"]]}],
            "integrity_plan": {"source": "inferred"},
        }

    def test_integrity_history_is_summary_only_and_bounded(self):
        with tempfile.TemporaryDirectory() as directory:
            store = OperationalStore(directory, retention_days=90, max_history_entries=2)
            now = datetime.now(timezone.utc)
            for index in range(3):
                store.record_integrity(
                    self.metadata,
                    self.result,
                    checked_at=now - timedelta(minutes=index),
                )
            records = store.list_integrity_history(self.metadata.table_ref, limit=10)
            persisted = (Path(directory) / "integrity_history.json").read_text(encoding="utf-8")
        self.assertEqual(len(records), 2)
        self.assertNotIn("raw-secret-value", persisted)
        self.assertNotIn("integrity_details", persisted)
        self.assertEqual(records[0]["statuses"]["Review"], 1)
        self.assertEqual(records[0]["statuses"]["No flags"], 1)

    def test_old_history_is_removed_by_retention(self):
        with tempfile.TemporaryDirectory() as directory:
            store = OperationalStore(directory, retention_days=30, max_history_entries=20)
            now = datetime.now(timezone.utc)
            store.record_integrity(self.metadata, self.result, checked_at=now - timedelta(days=31))
            store.record_integrity(self.metadata, self.result, checked_at=now)
            records = store.list_integrity_history(self.metadata.table_ref)
        self.assertEqual(len(records), 1)

    def test_methodology_snapshot_has_no_result_rows(self):
        with tempfile.TemporaryDirectory() as directory:
            store = OperationalStore(directory)
            saved = store.save_methodology(
                metadata=self.metadata,
                question="count events",
                intent="analytical",
                sql="SELECT COUNT(*) FROM `catalog`.`schema`.`events`",
                provenance={"schema_fingerprint": "phase7-fingerprint"},
            )
            payload = json.loads(
                (Path(directory) / "methodologies" / saved["filename"]).read_text(encoding="utf-8")
            )
        self.assertFalse(payload["result_rows_stored"])
        self.assertNotIn("rows", payload)
        self.assertIn("SELECT COUNT(*)", payload["sql"])

    def test_methodology_snapshot_rejects_writes(self):
        with tempfile.TemporaryDirectory() as directory:
            store = OperationalStore(directory)
            with self.assertRaises(ValueError):
                store.save_methodology(
                    metadata=self.metadata,
                    question="change events",
                    intent="analytical",
                    sql="UPDATE catalog.schema.events SET value = 1",
                )


class SchedulerTests(unittest.TestCase):
    def test_scheduler_requires_environment_and_file_opt_in(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "scheduler.json"
            path.write_text(json.dumps({
                "enabled": True,
                "interval_minutes": 5,
                "tables": ["catalog.schema.events"],
            }), encoding="utf-8")
            disabled, disabled_error = load_scheduler_config(path, environment_enabled=False)
            enabled, enabled_error = load_scheduler_config(path, environment_enabled=True)
        self.assertIsNone(disabled_error)
        self.assertFalse(disabled.enabled)
        self.assertIsNone(enabled_error)
        self.assertTrue(enabled.enabled)
        self.assertEqual(enabled.interval_minutes, 15)

    def test_run_once_uses_only_allowlisted_tables(self):
        calls = []
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "scheduler.json"
            path.write_text(json.dumps({
                "enabled": True,
                "interval_minutes": 60,
                "tables": ["catalog.schema.one", "catalog.schema.two"],
            }), encoding="utf-8")
            config, error = load_scheduler_config(path, environment_enabled=True)
        self.assertIsNone(error)
        scheduler = IntegrityScheduler(config, calls.append)
        scheduler.run_once()
        self.assertEqual(calls, ["catalog.schema.one", "catalog.schema.two"])
        self.assertIsNotNone(scheduler.status()["last_run"])


if __name__ == "__main__":
    unittest.main()

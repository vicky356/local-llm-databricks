import time
import unittest

from databricks_client import (
    DatabricksQueryClient,
    classify_exception,
    validate_read_only_sql,
)


class FakeCursor:
    def __init__(self, rows=None, columns=None, error=None, delay=0):
        self._rows = rows or []
        self.description = [(c,) for c in (columns or [])]
        self._error = error
        self._delay = delay
        self.cancelled = False
        self.closed = False

    def execute(self, _sql):
        if self._delay:
            time.sleep(self._delay)
        if self._error:
            raise self._error

    def fetchmany(self, size):
        return self._rows[:size]

    def cancel(self):
        self.cancelled = True

    def close(self):
        self.closed = True


class FakeConnection:
    def __init__(self, cursor):
        self._cursor = cursor
        self.closed = False

    def cursor(self):
        return self._cursor

    def close(self):
        self.closed = True


class SequencedConnector:
    def __init__(self, connections):
        self.connections = list(connections)
        self.calls = 0

    def __call__(self, **_kwargs):
        connection = self.connections[min(self.calls, len(self.connections) - 1)]
        self.calls += 1
        return connection


def make_client(connector, **overrides):
    return DatabricksQueryClient(
        "workspace.example",
        "/sql/warehouse/example",
        "secret-token",
        connector=connector,
        **overrides,
    )


class ReadOnlyValidationTests(unittest.TestCase):
    def test_allows_read_only_statements(self):
        for sql in (
            "SELECT * FROM sample",
            "WITH source AS (SELECT 1) SELECT * FROM source",
            "DESCRIBE TABLE sample",
            "SHOW TABLES",
            "EXPLAIN SELECT 1",
            "SELECT `update` FROM `catalog`.`schema`.`table`",
        ):
            self.assertIsNone(validate_read_only_sql(sql), sql)

    def test_rejects_writes_and_multiple_statements(self):
        self.assertIsNotNone(validate_read_only_sql("DELETE FROM sample"))
        self.assertIsNotNone(validate_read_only_sql("SELECT 1; DROP TABLE sample"))
        self.assertIsNotNone(validate_read_only_sql("WITH x AS (DELETE FROM sample) SELECT * FROM x"))


class QueryClientTests(unittest.TestCase):
    def test_success_and_row_limit(self):
        cursor = FakeCursor(rows=[[1], [2], [3]], columns=["value"])
        connector = SequencedConnector([FakeConnection(cursor)])
        outcome = make_client(connector, max_rows=2).execute("SELECT value FROM sample")

        self.assertTrue(outcome.ok)
        self.assertEqual(outcome.rows, [[1], [2]])
        self.assertTrue(outcome.truncated)
        self.assertEqual(outcome.attempts, 1)

    def test_expired_session_reconnects_once(self):
        expired = FakeConnection(FakeCursor(error=RuntimeError(
            "INVALID_STATE: Invalid SessionHandle: SessionHandle [expired]"
        )))
        healthy = FakeConnection(FakeCursor(rows=[[1]], columns=["ok"]))
        connector = SequencedConnector([expired, healthy])

        outcome = make_client(connector, session_retries=1).execute("SELECT 1")

        self.assertTrue(outcome.ok)
        self.assertEqual(outcome.attempts, 2)
        self.assertEqual(connector.calls, 2)

    def test_expired_session_does_not_retry_forever(self):
        first = FakeConnection(FakeCursor(error=RuntimeError("Invalid SessionHandle")))
        second = FakeConnection(FakeCursor(error=RuntimeError("Invalid SessionHandle")))
        connector = SequencedConnector([first, second])

        outcome = make_client(connector, session_retries=1).execute("SELECT 1")

        self.assertFalse(outcome.ok)
        self.assertEqual(outcome.error.category, "session_expired")
        self.assertEqual(outcome.attempts, 2)
        self.assertEqual(connector.calls, 2)

    def test_timeout_returns_structured_error(self):
        cursor = FakeCursor(rows=[[1]], columns=["ok"], delay=0.2)
        outcome = make_client(
            SequencedConnector([FakeConnection(cursor)]),
            query_timeout_seconds=0.02,
        ).execute("SELECT 1")

        self.assertFalse(outcome.ok)
        self.assertEqual(outcome.error.category, "timeout")
        self.assertTrue(outcome.error.retryable)

    def test_credentials_are_redacted(self):
        error = classify_exception(
            RuntimeError("request failed for secret-token at workspace.example"),
            secrets=("secret-token", "workspace.example"),
        )
        self.assertNotIn("secret-token", error.detail)
        self.assertNotIn("workspace.example", error.detail)
        self.assertIn("[REDACTED]", error.detail)

    def test_missing_group_by_is_classified_as_a_sql_error(self):
        error = classify_exception(RuntimeError(
            "[MISSING_GROUP_BY] The query does not include a GROUP BY clause. SQLSTATE: 42803"
        ))
        self.assertEqual(error.category, "sql")


if __name__ == "__main__":
    unittest.main()

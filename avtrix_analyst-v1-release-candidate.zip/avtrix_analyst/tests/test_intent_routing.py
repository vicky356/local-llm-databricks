import sys
import types
import unittest


try:
    import dotenv  # noqa: F401
except ImportError:
    dotenv = types.ModuleType("dotenv")
    dotenv.load_dotenv = lambda *args, **kwargs: None
    sys.modules["dotenv"] = dotenv

try:
    import flask  # noqa: F401
except ImportError:
    flask = types.ModuleType("flask")

    class _TestFlask:
        def __init__(self, *args, **kwargs):
            self.secret_key = None

        def route(self, *args, **kwargs):
            return lambda function: function

        def errorhandler(self, *args, **kwargs):
            return lambda function: function

    flask.Flask = _TestFlask
    flask.request = types.SimpleNamespace(path="/")
    flask.jsonify = lambda payload=None, **kwargs: payload if payload is not None else kwargs
    sys.modules["flask"] = flask

from avtrix_analyst import NAMED_QUERIES, _match_shortcut_by_intent, classify_intent_cli
from databricks_client import QueryError, validate_read_only_sql
from dataset_registry import ColumnMetadata, DatasetMetadata
import web_analyst as web

classify_intent_web = web.classify_intent


class IntentRoutingTests(unittest.TestCase):
    def test_stale_shortcut_pattern_falls_through_instead_of_raising(self):
        self.assertNotIn("mtbur_by_part", NAMED_QUERIES)
        self.assertIsNone(_match_shortcut_by_intent("What's MTBUR?"))
        self.assertEqual(classify_intent_cli("What's MTBUR?"), "domain")
        self.assertEqual(classify_intent_cli("Whats MTBUR?"), "domain")

    def test_available_shortcut_still_matches(self):
        shortcut = _match_shortcut_by_intent("Show the jobtype distribution")
        self.assertEqual(shortcut, "jobtype_distribution")
        self.assertIn(shortcut, NAMED_QUERIES)

    def test_reversed_jobtype_wording_uses_trusted_distribution(self):
        shortcut = _match_shortcut_by_intent("show me an overall distribution of jobtype")
        self.assertEqual(shortcut, "jobtype_distribution")
        sql = NAMED_QUERIES[shortcut]["sql"]
        self.assertIn("'(Missing)'", sql)
        self.assertIn("UPPER(TRIM(JOBTYPE))", sql)

    def test_yearly_jobtype_wording_uses_hardened_temporal_query(self):
        shortcut = _match_shortcut_by_intent("show me a yearly distribution of job types")
        self.assertEqual(shortcut, "jobtype_temporal")
        sql = NAMED_QUERIES[shortcut]["sql"].format(
            table="poc.avtrix_fb.fb_camp_fleet_history_join"
        )
        self.assertIn("TRY_CAST(REMOVAL_C_W_MOS AS TIMESTAMP)", sql)
        self.assertIn("missing_jobtype", sql)
        self.assertNotIn("BETWEEN 1995 AND 2025", sql)
        self.assertIsNone(validate_read_only_sql(sql))

    def test_contextual_repeat_and_ambiguous_year_type_are_recognised(self):
        self.assertTrue(web._is_contextual_repeat("show me the same distribution including null"))
        self.assertTrue(web._is_ambiguous_year_type_question("show me a distribution of year type"))
        self.assertFalse(web._is_ambiguous_year_type_question("show job type by year"))

    def test_combined_jobtype_reason_question_uses_data_story(self):
        question = "whats the spread across jobtype and also across removal reason?"
        shortcut = _match_shortcut_by_intent(question)
        self.assertEqual(shortcut, "reason_by_jobtype")
        self.assertIn(shortcut, NAMED_QUERIES)
        self.assertEqual(classify_intent_cli(question), "analytical")
        self.assertEqual(classify_intent_web(question), "analytical")
        sql = NAMED_QUERIES[shortcut]["sql"].format(
            table="poc.avtrix_fb.fb_camp_fleet_history_join"
        )
        self.assertIsNone(validate_read_only_sql(sql))

    def test_plural_dataset_summary_is_deterministic(self):
        question = "give me a general summary of the datasets"
        self.assertTrue(web._is_multi_dataset_overview(question))
        original = list(web.discovered_tables)
        try:
            web.discovered_tables[:] = [
                "poc.avtrix_fb.fb_camp_fleet_history_join",
                "poc.avtrix_fb.unified_fleet_detailed_utilization",
            ]
            result = web.answer_dataset_portfolio()
        finally:
            web.discovered_tables[:] = original
        self.assertEqual(result["type"], "overview")
        self.assertEqual(len(result["rows"]), 2)
        self.assertIn("Dataset portfolio", result["answer"])

    def test_data_availability_is_not_misclassified_as_capabilities(self):
        question = "what data is available"
        self.assertTrue(web._is_data_availability_question(question))
        self.assertFalse(web._is_capabilities_question(question))
        self.assertTrue(web._is_capabilities_question("what can you do?"))

    def test_ui_keeps_examples_and_renders_followup_questions(self):
        page = web.render_html()
        self.assertGreaterEqual(page.count('class="prompt-shelf"'), 2)
        self.assertIn("Ask next", page)
        self.assertIn("suggested_questions", page)

    def test_ui_has_stop_control_and_detailed_query_errors(self):
        page = web.render_html()
        self.assertIn('id="stop-btn"', page)
        self.assertIn('id="analyst-stop-btn"', page)
        self.assertIn("new AbortController()", page)
        self.assertIn("Databricks detail:", page)

    def test_ui_exposes_phase7_operational_controls(self):
        page = web.render_html()
        self.assertIn("runIntegrityReview()", page)
        self.assertIn("/api/integrity-history", page)
        self.assertIn("Export report", page)
        self.assertIn("Lock methodology", page)
        self.assertIn("/api/methodology", page)
        self.assertIn("no result rows stored", page)

    def test_domain_answers_have_structured_markdown_rendering(self):
        page = web.render_html()
        self.assertIn("function inlineMarkdown", page)
        self.assertIn("class=\"answer-table\"", page)
        self.assertIn(".answer-lead { font-weight:400", page)
        self.assertIn("const heading = line.match", page)
        self.assertIn("Array.isArray(data.charts)", page)
        self.assertIn("Dataset profile", page)

    def test_reliability_status_utilisation_question_uses_verified_card(self):
        question = "what is reliability? TSI and TSN or TSO? Aircraft utilization"
        self.assertTrue(web._is_reliability_glossary_question(question))
        result = web.answer_reliability_glossary()
        self.assertEqual(result["type"], "domain")
        self.assertIn("## Reliability", result["answer"])
        self.assertIn("Time Since Installation", result["answer"])
        self.assertIn("Time Since New", result["answer"])
        self.assertIn("Time Since Overhaul", result["answer"])
        self.assertIn("Technical Standard Order", result["answer"])
        self.assertIn("## Aircraft utilization", result["answer"])
        self.assertNotIn("Technical Standard Notice", result["answer"])

    def test_trusted_jobtype_summary_is_grounded(self):
        answer = web.summarise_jobtype_distribution(
            ["job_type", "record_count", "pct_of_total"],
            [["SCHEDULED", 17, 68.0], ["UNSCHEDULED", 5, 20.0], ["(Missing)", 3, 12.0]],
        )
        self.assertIn("25 records", answer)
        self.assertIn("(Missing)", answer)
        self.assertIn("do not by themselves establish failure rates", answer)
        self.assertIn("Do not infer causes", web.RESULT_INTERPRETATION_SYSTEM)

    def test_generic_component_distribution_uses_exact_counts_not_model_story(self):
        columns = [
            "component_type", "total_components", "unique_aircraft",
            "removals", "installations", "replacements",
        ]
        rows = [
            ["AIRCRAFT", 24131, 5, 933, 777, 42],
            ["ENGINE", 2923, 5, 69, 76, 36],
            ["APU", 256, 5, 14, 14, 16],
        ]
        answer = web.summarise_categorical_distribution(
            "show me a distribution of component type", columns, rows
        )
        self.assertIn("27,310", answer)
        self.assertIn("AIRCRAFT", answer)
        self.assertIn("88.4%", answer)
        self.assertIn("do not by themselves establish failure rates", answer)

    def test_general_overview_returns_statistics_and_visuals_not_field_audit(self):
        profile = {
            "record_count": 100,
            "column_count": 4,
            "role_summary": {"dimension": 2, "measure": 1, "date": 1},
            "anomaly_summary": {"high_missing_rate": 1},
            "candidate_identifiers": [],
            "columns": [
                {
                    "name": "AC_REG", "inferred_role": "dimension",
                    "approx_distinct_count": 2, "missing_count": 0, "missing_rate": 0,
                    "representative_values": [
                        {"value": "N100AA", "count": 60}, {"value": "N200AA", "count": 40},
                    ],
                },
                {
                    "name": "JOBTYPE", "inferred_role": "dimension",
                    "approx_distinct_count": 2, "missing_count": 10, "missing_rate": 0.1,
                    "representative_values": [
                        {"value": "SCHEDULED", "count": 70},
                        {"value": "UNSCHEDULED", "count": 20},
                    ],
                },
                {
                    "name": "HOURS", "inferred_role": "measure",
                    "approx_distinct_count": 90, "missing_count": 5, "missing_rate": 0.05,
                    "min": 1.0, "mean": 50.0, "max": 100.0, "stddev": 12.5,
                    "representative_values": [],
                },
                {
                    "name": "EVENT_DATE", "inferred_role": "date",
                    "approx_distinct_count": 30, "missing_count": 0, "missing_rate": 0,
                    "min": "2024-01-01", "max": "2024-01-30", "representative_values": [],
                },
            ],
        }
        original = web.answer_profile
        web.answer_profile = lambda *args, **kwargs: {
            "type": "profile", "profile": profile, "cached": True,
        }
        try:
            result = web.answer_overview("catalog.schema.any_dataset")
        finally:
            web.answer_profile = original
        self.assertEqual(result["type"], "overview")
        self.assertIn("## Dataset overview", result["answer"])
        self.assertIn("## Coverage", result["answer"])
        self.assertEqual(result["rows"][0][5], 50.0)
        self.assertEqual(len(result["charts"]), 3)
        self.assertNotEqual(result["columns"][0], "column")

    def test_integrity_review_runs_six_generic_checks_with_drill_down(self):
        metadata = DatasetMetadata(
            table_ref="catalog.schema.generic_events",
            catalog="catalog",
            schema="schema",
            table="generic_events",
            object_type="TABLE",
            columns=(
                ColumnMetadata("asset_registration", "string"),
                ColumnMetadata("event_date", "date"),
                ColumnMetadata("event_id", "bigint"),
                ColumnMetadata("asset_hours", "string"),
                ColumnMetadata("asset_cum_hours", "string"),
                ColumnMetadata("asset_model", "string"),
            ),
            schema_fingerprint="integrity-test",
        )
        profile = {
            "generated_at": "2026-10-12T12:00:00Z",
            "record_count": 10,
            "candidate_identifiers": [],
            "candidate_natural_keys": [{
                "columns": ["asset_registration", "event_date", "event_id"],
            }],
            "columns": [
                {"name": "asset_registration", "inferred_role": "identifier", "missing_count": 0, "missing_rate": 0},
                {"name": "event_date", "inferred_role": "date", "missing_count": 0, "missing_rate": 0, "date_like_count": 10},
                {"name": "event_id", "inferred_role": "measure", "missing_count": 0, "missing_rate": 0, "numeric_like_count": 10},
                {"name": "asset_hours", "inferred_role": "measure", "missing_count": 0, "missing_rate": 0, "numeric_like_count": 10},
                {"name": "asset_cum_hours", "inferred_role": "cumulative", "missing_count": 0, "missing_rate": 0, "numeric_like_count": 10},
                {"name": "asset_model", "inferred_role": "dimension", "missing_count": 2, "missing_rate": 0.2},
            ],
        }
        original_run_sql = web.run_sql
        original_profile = web._matching_profile

        def fake_run_sql(sql, table_ref=None):
            if "COUNT(*) AS __total__" in sql:
                columns = ["__total__"]
                row = [10]
                for column in metadata.columns:
                    columns.extend([f"null__{column.name}", f"uniq__{column.name}"])
                    row.extend([2 if column.name == "asset_model" else 0, 4])
                return columns, [row], None
            if "WITH duplicate_groups" in sql:
                return [
                    "duplicate_groups", "rows_in_duplicate_groups",
                    "excess_duplicate_rows", "largest_duplicate_group",
                ], [[1, 2, 1, 2]], None
            if "FROM collapsed" in sql:
                return [
                    "field_name", "checked_transitions", "decreases",
                    "decrease_pct", "largest_decrease",
                ], [["asset_cum_hours", 8, 1, 12.5, 1.0]], None
            if "event_0 > cumulative_0" in sql:
                return [
                    "rule", "comparable_rows", "violations",
                    "violation_pct", "largest_excess",
                ], [["asset_hours <= asset_cum_hours", 10, 0, 0.0, None]], None
            if "WITH entity_dates" in sql:
                return [
                    "entity_value", "first_date", "last_date", "active_dates",
                    "calendar_span_days", "largest_gap_days", "total_gap_days",
                ], [["A1", "2024-01-01", "2024-01-10", 8, 10, 2, 2]], None
            raise AssertionError(f"Unexpected SQL: {sql}")

        web.run_sql = fake_run_sql
        web._matching_profile = lambda current: profile
        try:
            result = web.answer_integrity_check(metadata.table_ref, metadata=metadata)
        finally:
            web.run_sql = original_run_sql
            web._matching_profile = original_profile

        self.assertEqual(result["type"], "integrity")
        self.assertEqual(len(result["rows"]), 6)
        self.assertEqual(len(result["integrity_details"]), 6)
        self.assertEqual(result["integrity_plan"]["source"], "inferred")
        self.assertEqual(result["provenance"]["sql_source"], "integrity_framework")
        self.assertIn("evidence for review", result["answer"])

    def test_semantic_distribution_builds_multi_series_visual(self):
        columns = ["group_value", "category_value", "record_count", "pct_within_group"]
        rows = [
            ["N100AA", "SCHEDULED", 60, 75.0],
            ["N100AA", "UNSCHEDULED", 20, 25.0],
            ["N200AA", "SCHEDULED", 10, 50.0],
            ["N200AA", "UNSCHEDULED", 10, 50.0],
        ]
        semantic = {"category_column": "JOBTYPE", "group_column": "AC_REG"}
        chart = web.build_grouped_distribution_chart(columns, rows, semantic)
        self.assertEqual(chart["layout"]["barmode"], "stack")
        self.assertEqual(len(chart["data"]), 2)
        self.assertEqual(chart["data"][0]["x"], ["N100AA", "N200AA"])

    def test_temporal_semantic_plan_returns_evidence_and_multi_series_chart(self):
        original_metadata = web.dataset_registry.get()
        original_run_sql = web.run_sql
        metadata = DatasetMetadata(
            table_ref="catalog.schema.any_dataset",
            catalog="catalog",
            schema="schema",
            table="any_dataset",
            object_type="TABLE",
            columns=(
                ColumnMetadata("EVENT_DATE", "date", "Date of event"),
                ColumnMetadata("JOBTYPE", "string", "Job type"),
            ),
            schema_fingerprint="temporal-test",
        )
        rows = [
            [2024, "SCHEDULED", 12, 75.0],
            [2024, "UNSCHEDULED", 4, 25.0],
            [2025, "SCHEDULED", 10, 50.0],
            [2025, "UNSCHEDULED", 10, 50.0],
        ]
        web.dataset_registry.activate(metadata)
        web.run_sql = lambda *args, **kwargs: (
            ["period_value", "category_value", "record_count", "pct_within_period"],
            rows,
            None,
        )
        try:
            result = web.answer_semantic_temporal(
                "show me a yearly distribution of job types",
                table_ref=metadata.table_ref,
            )
        finally:
            web.run_sql = original_run_sql
            web.dataset_registry.activate(original_metadata)

        chart = web.build_temporal_distribution_chart(
            result["columns"], result["rows"], result["semantic_temporal"]
        )
        self.assertEqual(result["type"], "analytical")
        self.assertEqual(result["semantic_temporal"]["date_column"], "EVENT_DATE")
        self.assertEqual(result["semantic_temporal"]["category_column"], "JOBTYPE")
        self.assertEqual(len(chart["data"]), 2)
        self.assertIn("recorded category volumes", result["answer"])

    def test_ranking_semantic_plan_uses_numeric_measure_and_live_columns(self):
        original_metadata = web.dataset_registry.get()
        original_run_sql = web.run_sql
        metadata = DatasetMetadata(
            table_ref="catalog.schema.any_dataset",
            catalog="catalog",
            schema="schema",
            table="any_dataset",
            object_type="TABLE",
            columns=(
                ColumnMetadata("supplier", "string", "Supplier"),
                ColumnMetadata("event_cost", "double", "Event cost"),
            ),
            schema_fingerprint="ranking-test",
        )
        web.dataset_registry.activate(metadata)
        web.run_sql = lambda *args, **kwargs: (
            ["dimension_value", "sum_value", "group_records"],
            [["Supplier A", 5000.0, 10], ["Supplier B", 2500.0, 8]],
            None,
        )
        try:
            result = web.answer_semantic_ranking(
                "top 5 suppliers by total event cost",
                table_ref=metadata.table_ref,
            )
        finally:
            web.run_sql = original_run_sql
            web.dataset_registry.activate(original_metadata)

        self.assertEqual(result["type"], "analytical")
        self.assertEqual(result["semantic_ranking"]["dimension_column"], "supplier")
        self.assertEqual(result["semantic_ranking"]["measure_column"], "event_cost")
        self.assertIn("TRY_CAST(`event_cost` AS DOUBLE)", result["sql"])
        self.assertIn("sample-size context", result["answer"])

    def test_reported_grouped_question_bypasses_model_sql_generation(self):
        original_metadata = web.dataset_registry.get()
        original_run_sql = web.run_sql
        metadata = DatasetMetadata(
            table_ref="catalog.schema.any_dataset",
            catalog="catalog",
            schema="schema",
            table="any_dataset",
            object_type="TABLE",
            columns=(
                ColumnMetadata("AC_REG", "string", "Aircraft registration"),
                ColumnMetadata("REASON", "string", "Removal reason"),
            ),
            schema_fingerprint="semantic-test",
        )
        web.dataset_registry.activate(metadata)
        web.run_sql = lambda *args, **kwargs: (
            ["group_value", "category_value", "record_count", "pct_within_group"],
            [["N100AA", "FAILURE", 8, 80.0], ["N100AA", "(Missing)", 2, 20.0]],
            None,
        )
        try:
            result = web.answer_semantic_distribution(
                "show me a distribution of removal reason by aircraft",
                table_ref=metadata.table_ref,
            )
        finally:
            web.run_sql = original_run_sql
            web.dataset_registry.activate(original_metadata)
        self.assertEqual(result["type"], "analytical")
        self.assertEqual(result["semantic_distribution"]["category_column"], "REASON")
        self.assertEqual(result["semantic_distribution"]["group_column"], "AC_REG")
        self.assertIn("GROUP BY group_value, category_value", result["sql"])
        self.assertIn("Data visibility note", result["answer"])

    def test_generated_query_gets_only_one_error_informed_correction(self):
        metadata = DatasetMetadata(
            table_ref="catalog.schema.any_dataset",
            catalog="catalog",
            schema="schema",
            table="any_dataset",
            object_type="TABLE",
            columns=(ColumnMetadata("event_status", "string"),),
            schema_fingerprint="repair-test",
        )
        generation_calls = []
        execution_calls = []
        original_nl_to_sql = web.nl_to_sql
        original_run_sql = web.run_sql
        original_profile = web._matching_profile
        original_interpret = web.interpret_results

        def fake_generation(*args, **kwargs):
            generation_calls.append(kwargs.get("repair_context"))
            return (
                "SELECT `event_status`, COUNT(*) AS event_count "
                "FROM `catalog`.`schema`.`any_dataset` GROUP BY `event_status` LIMIT 500",
                None,
            )

        def fake_execute(sql, table_ref=None):
            execution_calls.append(sql)
            if len(execution_calls) == 1:
                return None, None, QueryError(
                    "sql", "Databricks rejected the SQL query.", False,
                    "[MISSING_GROUP_BY] simulated evidence",
                )
            return ["event_status", "event_count"], [["OPEN", 4]], None

        web.nl_to_sql = fake_generation
        web.run_sql = fake_execute
        web._matching_profile = lambda _metadata: None
        web.interpret_results = lambda *args, **kwargs: "Returned one grouped result."
        try:
            result = web.answer_analytical(
                "count events by status",
                table_ref=metadata.table_ref,
                metadata=metadata,
            )
        finally:
            web.nl_to_sql = original_nl_to_sql
            web.run_sql = original_run_sql
            web._matching_profile = original_profile
            web.interpret_results = original_interpret

        self.assertEqual(result["type"], "analytical")
        self.assertEqual(len(generation_calls), 2)
        self.assertEqual(len(execution_calls), 2)
        self.assertIn("MISSING_GROUP_BY", generation_calls[1]["error"])
        self.assertTrue(result["provenance"]["repair_attempted"])
        self.assertTrue(result["provenance"]["repair_succeeded"])

    def test_timeout_does_not_trigger_model_sql_correction(self):
        metadata = DatasetMetadata(
            table_ref="catalog.schema.any_dataset",
            catalog="catalog",
            schema="schema",
            table="any_dataset",
            object_type="TABLE",
            columns=(ColumnMetadata("event_status", "string"),),
            schema_fingerprint="timeout-test",
        )
        generation_calls = []
        original_nl_to_sql = web.nl_to_sql
        original_run_sql = web.run_sql
        original_profile = web._matching_profile
        web.nl_to_sql = lambda *args, **kwargs: (
            generation_calls.append(kwargs.get("repair_context")) or
            "SELECT `event_status` FROM `catalog`.`schema`.`any_dataset` LIMIT 500",
            None,
        )
        web.run_sql = lambda *args, **kwargs: (
            None, None, QueryError("timeout", "The request timed out.", True)
        )
        web._matching_profile = lambda _metadata: None
        try:
            result = web.answer_analytical(
                "show status",
                table_ref=metadata.table_ref,
                metadata=metadata,
            )
        finally:
            web.nl_to_sql = original_nl_to_sql
            web.run_sql = original_run_sql
            web._matching_profile = original_profile

        self.assertEqual(result["type"], "error")
        self.assertEqual(len(generation_calls), 1)
        self.assertFalse(result["provenance"]["repair_attempted"])

    def test_incompatible_named_shortcut_is_blocked_before_execution(self):
        metadata = DatasetMetadata(
            table_ref="catalog.schema.unrelated_dataset",
            catalog="catalog",
            schema="schema",
            table="unrelated_dataset",
            object_type="TABLE",
            columns=(ColumnMetadata("event_status", "string"),),
            schema_fingerprint="shortcut-test",
        )
        original_run_sql = web.run_sql
        web.run_sql = lambda *args, **kwargs: self.fail("Incompatible shortcut reached Databricks")
        try:
            result = web.answer_analytical(
                "Overall JOBTYPE distribution",
                shortcut_name="jobtype_distribution",
                table_ref=metadata.table_ref,
                metadata=metadata,
            )
        finally:
            web.run_sql = original_run_sql

        self.assertEqual(result["type"], "error")
        self.assertEqual(result["error"]["category"], "schema_compatibility")
        self.assertIn("JOBTYPE", result["answer"])


if __name__ == "__main__":
    unittest.main()

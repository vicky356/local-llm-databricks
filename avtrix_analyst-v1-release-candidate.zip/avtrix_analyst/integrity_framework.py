"""Schema-agnostic integrity planning and read-only Databricks SQL builders.

Every result produced by this module is evidence for review, not proof that a
record is wrong.  Plans are inferred from live metadata and an exact matching
profile, with optional per-dataset overrides for business-owned definitions.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
import re
from typing import Any, Optional

from dataset_registry import ColumnMetadata, DatasetMetadata, parse_table_ref, quote_identifier


_NUMERIC_TYPES = {
    "tinyint", "smallint", "int", "integer", "bigint", "float", "double",
    "real", "decimal", "numeric", "short", "long",
}
_PLACEHOLDERS = (
    "", "-", "--", "---", "n/a", "na", "null", "none", "nil", "?",
    "pn", "sn-unknown", "nsn", "not installed", "not available", "tbc", "tbd",
)
_ENTITY_NAME = re.compile(
    r"(^|_)(aircraft|asset|vehicle|machine|equipment|unit|fleet|tail|registration|reg)(_|$)", re.I
)
_DATE_NAME = re.compile(r"date|time|timestamp|month|year|(^|_)mos($|_)", re.I)
_CUMULATIVE_NAME = re.compile(
    r"cum|cumulative|lifetime|running[_ ]?total|to[_ ]?date|total[_ ]?since",
    re.I,
)
_METADATA_NAME = re.compile(
    r"(^|_)(model|type|serial|sn|registration|reg|manufacturer|make|category|description|part|component)(_|$)",
    re.I,
)


@dataclass(frozen=True)
class IntegrityPlan:
    table_ref: str
    schema_fingerprint: str
    key_columns: tuple[str, ...]
    entity_columns: tuple[str, ...]
    order_column: Optional[str]
    cumulative_columns: tuple[str, ...]
    consistency_pairs: tuple[tuple[str, str], ...]
    metadata_columns: tuple[str, ...]
    source: str
    review_notes: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "table_ref": self.table_ref,
            "schema_fingerprint": self.schema_fingerprint,
            "key_columns": list(self.key_columns),
            "entity_columns": list(self.entity_columns),
            "order_column": self.order_column,
            "cumulative_columns": list(self.cumulative_columns),
            "consistency_pairs": [
                {"event": event, "cumulative": cumulative}
                for event, cumulative in self.consistency_pairs
            ],
            "metadata_columns": list(self.metadata_columns),
            "source": self.source,
            "review_notes": list(self.review_notes),
        }


def parse_operational_number(value: Any) -> Optional[float]:
    """Parse decimals and H:MM operational values to one decimal-hour scale."""
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if not text:
        return None
    match = re.fullmatch(r"([+-]?\d+):(\d{1,2})", text)
    if match:
        minutes = int(match.group(2))
        if minutes >= 60:
            return None
        sign = -1.0 if match.group(1).startswith("-") else 1.0
        hours = abs(int(match.group(1)))
        return sign * (hours + minutes / 60.0)
    try:
        return float(text.replace(",", ""))
    except ValueError:
        return None


def operational_number_sql(column_name: str) -> str:
    """Spark SQL equivalent of :func:`parse_operational_number`."""
    column = quote_identifier(column_name)
    text = f"TRIM(CAST({column} AS STRING))"
    hours = f"TRY_CAST(REGEXP_EXTRACT({text}, '^([+-]?[0-9]+):([0-9]{{1,2}})$', 1) AS DOUBLE)"
    minutes = f"TRY_CAST(REGEXP_EXTRACT({text}, '^([+-]?[0-9]+):([0-9]{{1,2}})$', 2) AS DOUBLE)"
    return (
        "CASE "
        f"WHEN {text} RLIKE '^[+-]?[0-9]+:[0-9]{{1,2}}$' AND {minutes} < 60 THEN "
        f"CASE WHEN {hours} < 0 THEN {hours} - ({minutes} / 60.0) "
        f"ELSE {hours} + ({minutes} / 60.0) END "
        f"ELSE TRY_CAST(TRANSLATE({text}, ',', '') AS DOUBLE) END"
    )


def _quoted_table(table_ref: str) -> str:
    return ".".join(quote_identifier(part) for part in parse_table_ref(table_ref))


def _type_base(data_type: str) -> str:
    return (data_type or "").lower().split("(", 1)[0].strip()


def _profile_map(profile: Optional[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    return {
        str(column.get("name") or "").lower(): column
        for column in (profile or {}).get("columns", [])
        if column.get("name")
    }


def _non_missing(profile: Optional[dict[str, Any]], column: dict[str, Any]) -> int:
    return max(0, int((profile or {}).get("record_count") or 0) - int(column.get("missing_count") or 0))


def _numeric_candidate(column: ColumnMetadata, profile_column: Optional[dict[str, Any]], profile) -> bool:
    if _type_base(column.data_type) in _NUMERIC_TYPES:
        return True
    if not profile_column:
        return False
    populated = _non_missing(profile, profile_column)
    return populated > 0 and int(profile_column.get("numeric_like_count") or 0) / populated >= 0.9


def _date_candidate(column: ColumnMetadata, profile_column: Optional[dict[str, Any]], profile) -> bool:
    if _type_base(column.data_type).startswith(("date", "timestamp")):
        return True
    if not _DATE_NAME.search(column.name) or not profile_column:
        return False
    populated = _non_missing(profile, profile_column)
    return populated > 0 and int(profile_column.get("date_like_count") or 0) / populated >= 0.9


def _name_tokens(name: str) -> set[str]:
    prepared = re.sub(r"([a-z])([A-Z])", r"\1 \2", name or "")
    tokens = set(re.findall(r"[a-z0-9]+", prepared.lower()))
    equivalents = {"hrs": "hours", "hr": "hours", "cycles": "cycles", "cyc": "cycles"}
    return {equivalents.get(token, token) for token in tokens}


def _pair_consistency_columns(
    columns: tuple[ColumnMetadata, ...],
    cumulative: tuple[str, ...],
    numeric_names: set[str],
) -> tuple[tuple[str, str], ...]:
    by_name = {column.name.lower(): column.name for column in columns}
    pairs: list[tuple[str, str]] = []
    removable = {
        "cum", "cumulative", "lifetime", "running", "total", "to", "date", "since",
    }
    for cumulative_name in cumulative:
        root = _name_tokens(cumulative_name) - removable
        if not root:
            continue
        best: tuple[float, str] | None = None
        for candidate_lower in numeric_names:
            candidate = by_name[candidate_lower]
            if candidate.lower() == cumulative_name.lower() or _CUMULATIVE_NAME.search(candidate):
                continue
            tokens = _name_tokens(candidate)
            if not tokens:
                continue
            overlap = len(root & tokens)
            score = overlap / max(len(root | tokens), 1)
            if root == tokens:
                score += 1.0
            if overlap and (best is None or score > best[0]):
                best = (score, candidate)
        if best and best[0] >= 0.6:
            pairs.append((best[1], cumulative_name))
    return tuple(pairs)


def _validated_names(values: Any, available: dict[str, str]) -> tuple[str, ...]:
    result = []
    for raw in values or []:
        actual = available.get(str(raw).lower())
        if actual and actual not in result:
            result.append(actual)
    return tuple(result)


def load_integrity_overrides(path: Path | str, table_ref: str) -> tuple[dict[str, Any], Optional[str]]:
    """Load optional business-owned settings without making them mandatory."""
    config_path = Path(path)
    if not config_path.exists():
        return {}, None
    try:
        payload = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return {}, f"Integrity configuration could not be read: {exc}"
    datasets = payload.get("datasets") if isinstance(payload, dict) else None
    if not isinstance(datasets, dict):
        return {}, "Integrity configuration must contain a datasets object."
    configured = datasets.get(table_ref, {})
    if not isinstance(configured, dict):
        return {}, f"Integrity configuration for {table_ref} must be an object."
    return configured, None


def build_integrity_plan(
    metadata: DatasetMetadata,
    profile: Optional[dict[str, Any]] = None,
    overrides: Optional[dict[str, Any]] = None,
) -> IntegrityPlan:
    """Infer a conservative plan, applying validated business overrides first."""
    overrides = overrides or {}
    available = {column.name.lower(): column.name for column in metadata.columns}
    profiled = _profile_map(profile)
    notes: list[str] = []
    source = "configured" if overrides else "inferred"

    numeric_names = {
        column.name.lower()
        for column in metadata.columns
        if _numeric_candidate(column, profiled.get(column.name.lower()), profile)
    }

    def configured_names(setting: str) -> tuple[str, ...]:
        raw_values = overrides.get(setting) or []
        validated = _validated_names(raw_values, available)
        unknown = [str(value) for value in raw_values if str(value).lower() not in available]
        if unknown:
            notes.append(
                f"Configured {setting} ignored unknown live field(s): {', '.join(unknown)}."
            )
        return validated

    entity_columns = configured_names("entity_columns")
    if "entity_columns" not in overrides:
        candidates = []
        for index, column in enumerate(metadata.columns):
            if not _ENTITY_NAME.search(column.name):
                continue
            item = profiled.get(column.name.lower(), {})
            score = 100 - float(item.get("missing_rate") or 0) * 20 - index / 1000
            if re.search(r"registration|(^|_)reg($|_)|tail|aircraft|asset", column.name, re.I):
                score += 25
            candidates.append((score, column.name))
        if candidates:
            candidates.sort(key=lambda item: (-item[0], item[1].lower()))
            entity_columns = (candidates[0][1],)
        else:
            notes.append("No defensible entity/asset partition field was inferred.")

    configured_order = str(overrides.get("order_column") or "").strip()
    order_column = available.get(configured_order.lower())
    if configured_order and not order_column:
        notes.append(f"Configured order_column ignored unknown live field: {configured_order}.")
    if "order_column" not in overrides:
        candidates = []
        for index, column in enumerate(metadata.columns):
            item = profiled.get(column.name.lower())
            if not _date_candidate(column, item, profile):
                continue
            score = 100 if _type_base(column.data_type).startswith(("date", "timestamp")) else 60
            score -= float((item or {}).get("missing_rate") or 0) * 20
            if re.search(r"event|record|transaction", column.name, re.I):
                score += 10
            candidates.append((round(score, 4), index, column.name))
        candidates.sort(key=lambda item: (-item[0], item[1]))
        if candidates:
            top_score = candidates[0][0]
            top = [item[2] for item in candidates if item[0] == top_score]
            if len(top) == 1:
                order_column = top[0]
            else:
                notes.append("More than one date/time field is equally plausible; configure order_column.")
        else:
            notes.append("No usable date/time ordering field was inferred.")

    cumulative_columns = configured_names("cumulative_columns")
    if "cumulative_columns" not in overrides:
        cumulative_columns = tuple(
            column.name for column in metadata.columns
            if column.name.lower() in numeric_names and _CUMULATIVE_NAME.search(column.name)
        )[:12]
        if not cumulative_columns:
            notes.append("No cumulative numeric fields were inferred.")

    configured_pairs = []
    for pair in overrides.get("consistency_pairs") or []:
        if not isinstance(pair, dict):
            continue
        event = available.get(str(pair.get("event") or "").lower())
        cumulative = available.get(str(pair.get("cumulative") or "").lower())
        if event and cumulative:
            configured_pairs.append((event, cumulative))
        else:
            notes.append("A configured consistency pair was ignored because a live field was not found.")
    consistency_pairs = tuple(configured_pairs) if "consistency_pairs" in overrides else (
        _pair_consistency_columns(metadata.columns, cumulative_columns, numeric_names)[:8]
    )
    if not consistency_pairs:
        notes.append("No event-to-cumulative field pairs were planned.")

    key_columns = configured_names("key_columns")
    if "key_columns" not in overrides and profile:
        identifier_candidates = profile.get("candidate_identifiers") or []
        natural_candidates = profile.get("candidate_natural_keys") or []
        candidate = identifier_candidates[0] if identifier_candidates else (
            natural_candidates[0] if natural_candidates else None
        )
        if candidate:
            key_columns = _validated_names(candidate.get("columns"), available)
    if not key_columns:
        notes.append("No candidate key is available; exact uniqueness was not planned.")

    metadata_columns = configured_names("metadata_columns")
    if "metadata_columns" not in overrides:
        metadata_columns = tuple(
            column.name for column in metadata.columns
            if _METADATA_NAME.search(column.name)
            and (profiled.get(column.name.lower(), {}).get("inferred_role") in {"dimension", "identifier"}
                 or not profile)
        )[:20]
    if not metadata_columns:
        notes.append("No descriptor/identifier metadata fields were inferred.")

    return IntegrityPlan(
        table_ref=metadata.table_ref,
        schema_fingerprint=metadata.schema_fingerprint,
        key_columns=key_columns,
        entity_columns=entity_columns,
        order_column=order_column,
        cumulative_columns=cumulative_columns,
        consistency_pairs=consistency_pairs,
        metadata_columns=metadata_columns,
        source=source,
        review_notes=tuple(notes),
    )


def _nullish(column_name: str) -> str:
    column = quote_identifier(column_name)
    tokens = ", ".join("'" + token.replace("'", "''") + "'" for token in _PLACEHOLDERS)
    return f"({column} IS NULL OR LOWER(TRIM(CAST({column} AS STRING))) IN ({tokens}))"


def build_uniqueness_sql(plan: IntegrityPlan) -> Optional[str]:
    if not plan.key_columns:
        return None
    table = _quoted_table(plan.table_ref)
    keys = ", ".join(quote_identifier(name) for name in plan.key_columns)
    populated = " AND ".join(f"NOT {_nullish(name)}" for name in plan.key_columns)
    return f"""
WITH duplicate_groups AS (
    SELECT {keys}, COUNT(*) AS duplicate_group_size
    FROM {table}
    WHERE {populated}
    GROUP BY {keys}
    HAVING COUNT(*) > 1
)
SELECT
    COUNT(*) AS duplicate_groups,
    COALESCE(SUM(duplicate_group_size), 0) AS rows_in_duplicate_groups,
    COALESCE(SUM(duplicate_group_size - 1), 0) AS excess_duplicate_rows,
    COALESCE(MAX(duplicate_group_size), 0) AS largest_duplicate_group
FROM duplicate_groups
""".strip()


def _entity_partition(columns: tuple[str, ...]) -> str:
    return ", ".join(quote_identifier(name) for name in columns)


def build_monotonicity_sql(plan: IntegrityPlan) -> Optional[str]:
    if not plan.entity_columns or not plan.order_column or not plan.cumulative_columns:
        return None
    table = _quoted_table(plan.table_ref)
    entity_select = _entity_partition(plan.entity_columns)
    order = quote_identifier(plan.order_column)
    metric_select = ",\n        ".join(
        f"{operational_number_sql(name)} AS metric_{index}"
        for index, name in enumerate(plan.cumulative_columns)
    )
    lag_select = ",\n        ".join(
        f"LAG(metric_{index}) OVER (PARTITION BY {entity_select} ORDER BY order_value) AS previous_{index}"
        for index, _ in enumerate(plan.cumulative_columns)
    )
    collapsed_metrics = ",\n        ".join(
        f"MAX(metric_{index}) AS metric_{index}"
        for index, _ in enumerate(plan.cumulative_columns)
    )
    union = []
    for index, name in enumerate(plan.cumulative_columns):
        safe_name = name.replace("'", "''")
        union.append(f"""
SELECT
    '{safe_name}' AS field_name,
    SUM(CASE WHEN metric_{index} IS NOT NULL AND previous_{index} IS NOT NULL THEN 1 ELSE 0 END) AS checked_transitions,
    SUM(CASE WHEN metric_{index} < previous_{index} THEN 1 ELSE 0 END) AS decreases,
    ROUND(100.0 * SUM(CASE WHEN metric_{index} < previous_{index} THEN 1 ELSE 0 END) /
        NULLIF(SUM(CASE WHEN metric_{index} IS NOT NULL AND previous_{index} IS NOT NULL THEN 1 ELSE 0 END), 0), 3)
        AS decrease_pct,
    MAX(CASE WHEN metric_{index} < previous_{index} THEN previous_{index} - metric_{index} END) AS largest_decrease
FROM sequenced
""".strip())
    return f"""
WITH parsed AS (
    SELECT
        {entity_select},
        TRY_CAST({order} AS TIMESTAMP) AS order_value,
        {metric_select}
    FROM {table}
),
collapsed AS (
    SELECT
        {entity_select},
        order_value,
        {collapsed_metrics}
    FROM parsed
    WHERE order_value IS NOT NULL
    GROUP BY {entity_select}, order_value
),
sequenced AS (
    SELECT
        *,
        {lag_select}
    FROM collapsed
)
{" UNION ALL ".join(union)}
""".strip()


def build_consistency_sql(plan: IntegrityPlan) -> Optional[str]:
    if not plan.consistency_pairs:
        return None
    table = _quoted_table(plan.table_ref)
    parsed_fields = []
    parts = []
    for index, (event, cumulative) in enumerate(plan.consistency_pairs):
        event_expr = operational_number_sql(event)
        cumulative_expr = operational_number_sql(cumulative)
        parsed_fields.extend((
            f"{event_expr} AS event_{index}",
            f"{cumulative_expr} AS cumulative_{index}",
        ))
        label = f"{event} <= {cumulative}".replace("'", "''")
        parts.append(f"""
SELECT
    '{label}' AS rule,
    SUM(CASE WHEN event_{index} IS NOT NULL AND cumulative_{index} IS NOT NULL THEN 1 ELSE 0 END) AS comparable_rows,
    SUM(CASE WHEN event_{index} > cumulative_{index} THEN 1 ELSE 0 END) AS violations,
    ROUND(100.0 * SUM(CASE WHEN event_{index} > cumulative_{index} THEN 1 ELSE 0 END) /
        NULLIF(SUM(CASE WHEN event_{index} IS NOT NULL AND cumulative_{index} IS NOT NULL THEN 1 ELSE 0 END), 0), 3)
        AS violation_pct,
    MAX(CASE WHEN event_{index} > cumulative_{index} THEN event_{index} - cumulative_{index} END) AS largest_excess
FROM parsed
""".strip())
    parsed_select = ",\n        ".join(parsed_fields)
    return f"""
WITH parsed AS (
    SELECT
        {parsed_select}
    FROM {table}
)
{" UNION ALL ".join(parts)}
""".strip()


def build_date_coverage_sql(plan: IntegrityPlan) -> Optional[str]:
    if not plan.entity_columns or not plan.order_column:
        return None
    table = _quoted_table(plan.table_ref)
    entity_parts = [f"COALESCE(TRIM(CAST({quote_identifier(name)} AS STRING)), '(Missing)')" for name in plan.entity_columns]
    entity_expr = "CONCAT_WS(' | ', " + ", ".join(entity_parts) + ")"
    order = quote_identifier(plan.order_column)
    return f"""
WITH entity_dates AS (
    SELECT DISTINCT
        {entity_expr} AS entity_value,
        TRY_CAST({order} AS DATE) AS event_date
    FROM {table}
    WHERE TRY_CAST({order} AS DATE) IS NOT NULL
),
sequenced AS (
    SELECT
        entity_value,
        event_date,
        LAG(event_date) OVER (PARTITION BY entity_value ORDER BY event_date) AS previous_date
    FROM entity_dates
)
SELECT
    entity_value,
    MIN(event_date) AS first_date,
    MAX(event_date) AS last_date,
    COUNT(*) AS active_dates,
    DATEDIFF(MAX(event_date), MIN(event_date)) + 1 AS calendar_span_days,
    COALESCE(MAX(GREATEST(DATEDIFF(event_date, previous_date) - 1, 0)), 0) AS largest_gap_days,
    COALESCE(SUM(GREATEST(DATEDIFF(event_date, previous_date) - 1, 0)), 0) AS total_gap_days
FROM sequenced
GROUP BY entity_value
ORDER BY largest_gap_days DESC, entity_value ASC
LIMIT 100
""".strip()


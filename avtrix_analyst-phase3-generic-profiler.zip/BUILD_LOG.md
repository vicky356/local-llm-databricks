# AvTrix Analyst Build Log

This is the authoritative running record for the AvTrix local-LLM and
Databricks application. Update it whenever a phase is completed, a material
architecture decision is made, a milestone is tested, or a known limitation is
introduced or resolved.

## Project objective

Build a dataset-agnostic analytical agent that can connect to an unfamiliar
Databricks dataset, discover and profile it at runtime, generate safe SQL, and
provide evidence-based answers without training or hardcoding the model for a
specific table.

## Core principles

- Dataset knowledge is discovered at runtime, not fine-tuned into the model.
- Live Databricks metadata takes precedence over stored descriptions.
- Queries are read-only, bounded and auditable.
- Business methodology must be explicitly defined or approved.
- Inference is labelled as inference; uncertainty triggers clarification.
- Dataset-specific analysis packs remain optional and separate from the core.
- No credentials, tokens or complete connection strings are written to logs.

## Current milestone

**Milestone 2 — Generic runtime dataset profiling**

Status: **Implemented locally; live Mac/Databricks acceptance test pending.**

Included phases:

- Phase 1 — Databricks connector hardening
- Phase 2 — Dataset discovery and server-side table switching
- Phase 3 — Schema-agnostic profiling and fingerprinted profile storage

Packaged build:

`outputs/avtrix_analyst-phase3-generic-profiler.zip`

---

## Phase 1 — Databricks connector hardening

Status: **Implemented**

### Problem addressed

The original web application retained one global Databricks connection. The UI
reported that Databricks was connected when the Python object existed, even if
the underlying server session had expired. Queries then failed with:

`INVALID_STATE: Invalid SessionHandle`

Unhandled server exceptions could also return Flask HTML to a browser expecting
JSON, producing messages such as:

`Unexpected token '<', "<!doctype "... is not valid JSON`

### Changes implemented

- Added `databricks_client.py`.
- Replaced shared cursors with managed, short-lived query connections.
- Added a real `SELECT 1` health check.
- Added one controlled reconnect after an expired session.
- Prevented unlimited retry loops.
- Added structured query outcomes and error categories.
- Redacted credentials and connection details from errors and logs.
- Added read-only SQL validation.
- Added a configurable 500-row result maximum.
- Added a configurable 60-second query timeout.
- Made web API failures consistently JSON-shaped.
- Applied the query client to both the browser and CLI paths.

### Configuration introduced

```text
DATABRICKS_QUERY_TIMEOUT_SECONDS=60
DATABRICKS_MAX_ROWS=500
DATABRICKS_SESSION_RETRIES=1
AVTRIX_LOG_LEVEL=INFO
```

### Verification

- Python compilation: passed.
- Connector unit tests: passed.
- Expired-session reconnect test: passed.
- Retry-limit test: passed.
- Timeout test: passed.
- Credential-redaction test: passed.
- Read-only SQL validation tests: passed.

### Live verification outstanding

- Deploy on the Mac.
- Confirm health check against the live Databricks warehouse.
- Confirm a query succeeds after an expired or restarted session.
- Confirm browser failures remain valid JSON.

---

## Phase 2 — Dataset discovery and selection

Status: **Implemented**

### Problem addressed

The interface displayed discovered tables, but clicking a table did not change
the server-side query target. The application continued to rely on the startup
`HISTORY_TABLE`, allowing the displayed dataset and queried dataset to diverge.

### Changes implemented

- Added `dataset_registry.py`.
- Added lazy catalog discovery.
- Added lazy schema discovery.
- Added table and view discovery within the selected schema.
- Added catalog and schema selectors to the web interface.
- Made table selection a server-side action through `POST /api/table`.
- Validated each selected dataset using a live `DESCRIBE TABLE`.
- Stored the active dataset in a thread-safe runtime registry.
- Captured the active dataset at the beginning of every query request.
- Refreshed the model's column context from live metadata.
- Added column names, data types and comments to dataset metadata.
- Added a SHA-256 schema fingerprint.
- Included source-dataset metadata in analytical responses.
- Cleared cached chart results when switching datasets.
- Changed `HISTORY_TABLE` into a startup default rather than a permanent target.
- Replaced the FB-specific default overview with a structural overview that is
  valid for any dataset.

### Discovery endpoints

```text
GET  /api/catalogs
GET  /api/schemas?catalog=<catalog>
GET  /api/tables?catalog=<catalog>&schema=<schema>
POST /api/table
```

### Verification

- Total automated tests: 11 passed.
- Python compilation: passed.
- Rendered web page generation: passed.
- Embedded JavaScript syntax validation: passed.
- Dataset discovery tests: passed.
- Schema-fingerprint repeatability test: passed.

### Live verification outstanding

- Confirm catalog and schema permissions against the live account.
- Switch between the two existing fleet tables in the browser.
- Confirm the displayed table and SQL source always match.
- Confirm the schema fingerprint changes when a schema changes.

---

## Phase 3 — Schema-agnostic dataset profiling

Status: **Implemented locally**

### Problem addressed

Live column names alone do not give the model enough context to reason reliably
about an unfamiliar dataset. A generic profiling layer was needed to establish
the dataset's shape, completeness, cardinality, ranges and likely analytical
roles without hardcoding field names from one aviation table.

### Changes implemented

- Added `dataset_profiler.py`.
- Added record and column counts.
- Added null, blank and placeholder counts and rates.
- Added approximate distinct counts and uniqueness ratios.
- Added numeric and date ranges.
- Added bounded representative values for low-cardinality columns.
- Suppressed representative-value sampling for sensitive-looking fields such
  as names, email, phone, address, notes, contact, account and token fields.
- Added inferred roles: identifier, dimension, measure, date, attribute and
  complex field.
- Added cumulative-field candidates based on neutral naming heuristics.
- Added candidate single-column identifiers.
- Added possible composite natural-key components, explicitly marked as
  unverified until an exact duplicate check is performed.
- Added structural review flags for missingness, constants, placeholders and
  numeric/date-like values stored in text fields.
- Added bounded query batching so wide schemas do not produce one unbounded
  aggregate statement.
- Added local JSON profile storage with restrictive file permissions where the
  operating system supports them.
- Keyed every stored profile to both dataset reference and schema fingerprint.
- Added live metadata refresh before profile lookup or creation so a changed
  schema cannot reuse stale context.
- Added `GET /api/profile` for cache lookup and `POST /api/profile` for explicit
  generation or refresh.
- Added a profile status card and Generate/Refresh control to the browser.
- Made the general overview use the generic profile.
- Added natural-language routing for requests such as “profile the active
  dataset”.
- Added profile configuration and privacy controls to `.env.template`.
- Excluded `.avtrix_profiles/` from Git.
- Corrected the read-only validator so quoted columns named after SQL verbs do
  not create false positives.

### Safety and interpretation

- All profile queries are read-only.
- Distinct counts are approximate to reduce cost.
- Candidate keys require exact validation before use.
- Review flags are evidence for review, not proof of bad data.
- Low-cardinality samples are local, bounded and suppress sensitive-looking
  fields by default.
- `AVTRIX_PROFILE_SAMPLE_VALUES=false` disables all representative-value
  storage while retaining counts, ranges and classifications.

### Verification

- Total automated tests: 15 passed.
- Python compilation: passed.
- Unfamiliar-schema profiling test: passed.
- Schema-fingerprint cache isolation test: passed.
- Sensitive-value suppression test: passed.
- Unverified natural-key suggestion test: passed.
- Quoted SQL-keyword identifier test: passed.
- Rendered web page generation: passed.
- Embedded JavaScript syntax validation: passed.

### Live verification outstanding

- Generate profiles for both current fleet tables on the Mac.
- Compare record counts, missingness and ranges with direct Databricks results.
- Profile at least one structurally different non-FB dataset.
- Confirm a second request uses the matching cached profile.
- Confirm profile runtime is acceptable on the free-tier warehouse.
- Confirm sensitive-looking columns contain no representative values in the
  local profile JSON.

---

## Architecture decisions

### ADR-001 — No table-specific model fine-tuning

Decision: dataset adaptability will be achieved through runtime discovery,
profiling, semantic manifests and retrieval. The model remains replaceable.

### ADR-002 — Short-lived Databricks query connections

Decision: the threaded web application will not share a long-lived Databricks
cursor or connection across requests. Reliability and isolation take precedence
over avoiding connection setup time.

### ADR-003 — Startup default versus active dataset

Decision: `HISTORY_TABLE` identifies only the startup dataset. Runtime queries
use the active dataset stored by the dataset registry.

### ADR-004 — Schema fingerprinting

Decision: column names, data types and comments are canonicalised and hashed.
Stored profiles will be keyed by this fingerprint so schema changes invalidate
stale context automatically.

### ADR-005 — Generic overview replaces default FB overview

Decision: the default overview may only report facts available for any dataset.
Richer statistics will come from the generic profiler rather than hardcoded
aviation columns.

### ADR-006 — Approximate discovery, exact confirmation

Decision: generic profiling uses approximate distinct counts for efficient
discovery. Any candidate identifier or natural key remains unverified until a
separate exact duplicate check confirms it.

### ADR-007 — Profiles are schema-fingerprint scoped

Decision: cached profiles are addressed by dataset reference and live schema
fingerprint. A profile for an older schema is never silently loaded for a newer
schema.

### ADR-008 — Sensitive representative values are suppressed

Decision: representative values may improve semantic understanding, but are
only sampled from bounded low-cardinality fields. Sensitive-looking fields are
excluded, and all value sampling can be disabled by configuration.

---

## Known limitations and technical debt

- Existing named shortcuts remain FB-specific and can fail on unrelated tables.
- Dataset identifiers containing dots, backticks or spaces are not yet supported.
- Discovered objects are currently labelled `TABLE_OR_VIEW`; exact object type
  classification is not yet populated on every Databricks surface.
- Relationships between tables have not yet been inferred.
- Approximate key candidates do not yet run an exact uniqueness confirmation.
- Complex columns currently receive null/completeness statistics only.
- Type-format flags use conservative heuristics and may include legitimate
  operational formats; they require review.
- Generic profile performance has not yet been measured against the live
  free-tier warehouse.
- The CLI still starts from its configured table and does not yet expose the
  browser's full catalog/schema selection workflow.
- Live Mac/Databricks acceptance testing is pending.

---

## Next phase — Profile-informed reasoning

Planned outcomes:

- Give the LLM a compact, value-safe profile of the active dataset.
- Build model context from live metadata and the matching fingerprinted
  profile, never from one table's hardcoded notes.
- Match user language to likely columns using metadata, comments, inferred
  roles and safe low-cardinality values.
- Prevent table-specific shortcuts from appearing or running when their
  required columns are absent.
- Validate generated column references against the active schema before SQL is
  executed.
- Add one bounded repair attempt that receives the real Databricks error and
  live schema context.
- Include dataset reference, schema fingerprint and profile timestamp in answer
  provenance.

---

## Milestone acceptance checklist

### Milestone 1

- [x] Expired-session recovery implemented.
- [x] Read-only query client implemented.
- [x] Structured API errors implemented.
- [x] Catalog/schema/table discovery implemented.
- [x] Server-side table switching implemented.
- [x] Live schema metadata captured.
- [x] Schema fingerprint implemented.
- [x] Automated tests passed locally.
- [ ] Deployed to the Mac.
- [ ] Verified against live Databricks.

### Milestone 2

- [x] Generic profiler implemented.
- [x] Profiles cached by schema fingerprint.
- [x] Profile visible in the web interface.
- [x] Offline tests use an unfamiliar synthetic schema.
- [x] No FB-specific field names required by the profiler.
- [ ] Tested live against at least three structurally different datasets.

### Milestone 3

- [ ] Compact profile included in model context.
- [ ] Generated column references validated before execution.
- [ ] Incompatible table-specific shortcuts blocked or hidden.
- [ ] One bounded, evidence-based SQL repair attempt implemented.
- [ ] Answer provenance includes active dataset and profile identity.
- [ ] Tested with questions across three different dataset structures.

---

## Build-log update rules

At every material change:

1. Update the current milestone and phase status.
2. Record what changed and why.
3. Record tests run and their results.
4. Record live verification separately from local automated verification.
5. Add or update an architecture decision when a durable design choice is made.
6. Record known limitations without presenting them as completed work.
7. Update the next action so another session can resume without reconstruction.

## Next action

Implement Phase 4: use the matching generic profile to improve SQL generation
and response quality. Do not fine-tune or hardcode the model for a specific
table, and do not expand the FB-specific shortcut set.

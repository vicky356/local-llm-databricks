"""
AvTrix Fleet Intelligence — Browser Chat Interface
===================================================
A local web app replacing Databricks Genie.
Two modes: Focused (clean chat) and Analyst (split canvas).
Intent router: answers meta/domain/schema questions directly,
SQL questions via Ollama, all without leaving your browser.

Usage:
    python3 web_analyst.py

Then open: http://localhost:5000
"""

import os
import sys
import json
import re
import threading
import webbrowser
from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv

load_dotenv(Path(__file__).parent / ".env")

DATABRICKS_HOST      = os.getenv("DATABRICKS_HOST", "")
DATABRICKS_HTTP_PATH = os.getenv("DATABRICKS_HTTP_PATH", "")
DATABRICKS_TOKEN     = os.getenv("DATABRICKS_TOKEN", "")
OLLAMA_MODEL         = os.getenv("OLLAMA_MODEL", "ministral-3:8b")
HISTORY_TABLE        = os.getenv("HISTORY_TABLE", "poc.avtrix_fb.alg_history_report")
OLLAMA_BASE_URL      = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")

# ── Import shared components from CLI tool ───────────────────────────────────
from avtrix_analyst import (
    NAMED_QUERIES, SCHEMA_CONTEXT, _match_shortcut_by_intent,
    UNIVERSAL_GUARDRAILS, FB_HISTORY_SCHEMA, build_schema_context,
    build_completeness_sql, format_completeness_rows, _parse_describe_columns,
    list_installed_models, set_model,
)

# ── Flask ─────────────────────────────────────────────────────────────────────
try:
    from flask import Flask, request, jsonify
except ImportError:
    print("Flask not found. Run: pip3 install flask")
    sys.exit(1)

app = Flask(__name__)
app.secret_key = "avtrix-local-only"

conversation_history = []
db_conn = None
discovered_tables = []   # populated at startup

# ── Databricks ────────────────────────────────────────────────────────────────
_db_conn_lock = threading.Lock()

def get_connection():
    """Return (connection, error). Thread-safe singleton — only one connect() in flight at a time."""
    global db_conn
    if db_conn is not None:
        return db_conn, None
    with _db_conn_lock:
        # Re-check inside the lock in case another thread just set it
        if db_conn is not None:
            return db_conn, None
        try:
            from databricks import sql as dbsql
            db_conn = dbsql.connect(
                server_hostname=DATABRICKS_HOST,
                http_path=DATABRICKS_HTTP_PATH,
                access_token=DATABRICKS_TOKEN,
            )
        except Exception as e:
            return None, str(e)
    return db_conn, None


def _make_fresh_connection():
    """Create a one-off connection (no singleton) — for background tasks that
    must not race with the shared db_conn initialisation."""
    try:
        from databricks import sql as dbsql
        conn = dbsql.connect(
            server_hostname=DATABRICKS_HOST,
            http_path=DATABRICKS_HTTP_PATH,
            access_token=DATABRICKS_TOKEN,
        )
        return conn, None
    except Exception as e:
        return None, str(e)


def _catalog_prefix(table_ref):
    """Return USE CATALOG statement if table_ref is a three-part name."""
    parts = table_ref.strip().split(".")
    if len(parts) == 3:
        return f"USE CATALOG {parts[0]}"
    return None


def run_sql(sql_query):
    conn, err = get_connection()
    if err:
        return None, None, err
    try:
        cursor = conn.cursor()
        prefix = _catalog_prefix(HISTORY_TABLE)
        if prefix:
            cursor.execute(prefix)
        cursor.execute(sql_query)
        columns = [desc[0] for desc in cursor.description]
        rows = [list(row) for row in cursor.fetchall()]
        return columns, rows, None
    except Exception as e:
        return None, None, str(e)


def discover_tables():
    """Discover available tables in the same schema as HISTORY_TABLE.
    Uses a fresh (non-singleton) connection so it never races with api_status
    or any query that calls get_connection() at the same time."""
    global discovered_tables
    parts = HISTORY_TABLE.strip().split(".")
    if len(parts) != 3:
        discovered_tables = [HISTORY_TABLE]
        return

    catalog, schema = parts[0], parts[1]
    conn, err = _make_fresh_connection()
    if err:
        discovered_tables = [HISTORY_TABLE]
        return
    try:
        cursor = conn.cursor()
        cursor.execute(f"USE CATALOG {catalog}")
        cursor.execute(f"SHOW TABLES IN {schema}")
        rows = cursor.fetchall()
        # rows typically: (database, tableName, isTemporary)
        discovered_tables = [
            f"{catalog}.{schema}.{row[1]}" for row in rows
        ]
        if not discovered_tables:
            discovered_tables = [HISTORY_TABLE]
    except Exception:
        discovered_tables = [HISTORY_TABLE]
    finally:
        try:
            conn.close()
        except Exception:
            pass


# ── Ollama ────────────────────────────────────────────────────────────────────
def call_ollama(prompt, system_prompt=None, timeout=120):
    try:
        import urllib.request
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        payload = json.dumps({
            "model": OLLAMA_MODEL,
            "messages": messages,
            "stream": False,
        }).encode()

        req = urllib.request.Request(
            f"{OLLAMA_BASE_URL}/api/chat",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read())
            return data["message"]["content"].strip(), None
    except Exception as e:
        return None, str(e)


def check_ollama():
    try:
        import urllib.request
        req = urllib.request.Request(f"{OLLAMA_BASE_URL}/api/tags", method="GET")
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
            models = [m["name"] for m in data.get("models", [])]
            return True, models
    except Exception as e:
        return False, str(e)


# ── Intent Router ─────────────────────────────────────────────────────────────
INTEGRITY_PATTERNS = [
    r"\bdata\s+(integrity|quality)\b",
    r"\bintegrity\s+check\b",
    r"\b(completeness|fill rate|null count|null rate)\b",
    r"\b(profile|audit)\b.{0,20}\b(table|data|dataset|fields?|columns?)\b",
    r"\bcheck\b.{0,25}\b(null|placeholder|missing|completeness|fields?|columns?|quality|integrity)\b",
    r"\bwere\s+null(s| values)?\b",
    r"\bplaceholders?\b.{0,20}\b(taken|considered|handled|checked)\b",
]


def _is_integrity_question(question):
    q = (question or "").lower()
    return any(re.search(p, q) for p in INTEGRITY_PATTERNS)


META_PATTERNS = [
    r"\b(what|which|list|show)\b.{0,30}\b(table|tables|schema|catalog|dataset|data)\b",
    r"\b(what data|what tables|what can you|what do you have)\b",
    r"\bdo you have access\b",
    r"\b(available|accessible)\b.{0,20}\b(table|data|schema)\b",
    r"\bshow.{0,10}tables?\b",
    r"\blist.{0,10}tables?\b",
    r"\bwhat.{0,15}(columns?|fields?)\b",
    r"\bdescribe.{0,20}(table|schema|data)\b",
    r"\bschema\b",
    r"\bcolumns?.{0,20}\b(in|of|for)\b",
]

DOMAIN_PATTERNS = [
    r"\b(what is|explain|define|tell me about|how does|why)\b",
    r"\b(mtbur|mtbf|reliability|removal|lru|ata chapter|jobtype)\b.{0,30}\b(mean|definition|explain|why)\b",
    r"\bwhat does.{0,30}mean\b",
    r"\badvice\b|\brecommend\b|\bshould i\b|\bwhat should\b",
    r"\binterpret\b|\bsummarise\b|\bsummarize\b",
    r"\bcontext\b.{0,20}\b(for|of|behind)\b",
]


def _is_guardrails_question(question):
    q = (question or "").lower()
    return bool(re.search(r"\bguardrails?\b|\bmethodolog|how.{0,20}\binvoke\b.{0,20}\bguardrail", q))


def _is_capabilities_question(question):
    q = (question or "").lower()
    return bool(re.search(r"\bwhat can you do\b|\bcapabilit|\bwhat.{0,20}available\b|\bwhat.{0,15}options\b|\bhelp me understand what\b", q))


def answer_guardrails() -> dict:
    """Explain how the guardrails are invoked and show both layers."""
    answer = (
        "**How the guardrails are invoked:** automatically. Every SQL question is given these "
        "rules in the model's system prompt — you don't call them, they're always on.\n\n"
        "They're split into two layers so they stay correct across different tables:\n\n"
        "**1. Universal methodology (applies to ANY table):**\n"
        f"{UNIVERSAL_GUARDRAILS}\n\n"
        "**2. Per-table methodology (only valid for a table with these columns):**\n"
        f"Active table: `{HISTORY_TABLE}`\n"
        "The reliability-specific rules (True Reliability filter, MTBUR, same-serial exclusion) "
        "ONLY apply when the table actually has REASON / removal-hours columns. On a different "
        "table — e.g. a utilisation table with Cum_Hours / ENG1-4 columns — those rules are NOT "
        "applied; the model is given that table's real columns instead."
    )
    return {"type": "domain", "answer": answer, "sql": None, "columns": None, "rows": None}


def answer_capabilities() -> dict:
    """Describe everything the assistant can do."""
    answer = (
        "**What I can do** — ask in plain English and I route automatically:\n\n"
        "- **Analytics** — generate & run Databricks SQL (\"which aircraft have the most removals?\")\n"
        "- **Data integrity check** — schema-agnostic completeness audit of any table "
        "(\"run a data integrity check\")\n"
        "- **Overview** — cross-dataset summary across all discovered tables (\"general overview\")\n"
        "- **Schema** — columns/tables from metadata, no SQL (\"what columns do you have?\")\n"
        "- **Knowledge** — aviation/reliability expertise, no SQL (\"what is MTBUR?\")\n"
        "- **Charts** — re-render the last result as pie/bar/line (\"show that as percentages\")\n\n"
        f"Active table: `{HISTORY_TABLE}` · Model: `{OLLAMA_MODEL}` "
        "(switch it in the sidebar). Ask \"what guardrails do you apply?\" to see the methodology."
    )
    return {"type": "meta", "answer": answer, "sql": None, "columns": None, "rows": None}


def classify_intent(question: str) -> str:
    """
    Returns one of: 'meta' | 'domain' | 'analytical'
    - meta:       questions about the data structure itself (what tables, what columns)
    - domain:     aviation/reliability knowledge questions (no SQL needed)
    - analytical: questions requiring a Databricks query
    """
    q = question.lower().strip()

    for pat in META_PATTERNS:
        if re.search(pat, q):
            return "meta"

    for pat in DOMAIN_PATTERNS:
        if re.search(pat, q):
            return "domain"

    return "analytical"


# ── Response generators ───────────────────────────────────────────────────────
def answer_meta(question: str) -> dict:
    """Answer schema/catalog discovery questions directly from Databricks metadata."""
    q = question.lower()

    # Table listing request
    if any(w in q for w in ["table", "tables", "catalog", "dataset", "access"]):
        if discovered_tables:
            parts = HISTORY_TABLE.split(".")
            catalog = parts[0] if len(parts) == 3 else "N/A"
            schema  = parts[1] if len(parts) == 3 else "N/A"
            table_list = "\n".join(f"  • {t}" for t in discovered_tables)
            answer = (
                f"You have access to **{len(discovered_tables)} table(s)** "
                f"in catalog `{catalog}`, schema `{schema}`:\n\n{table_list}\n\n"
                f"The active table for queries is `{HISTORY_TABLE}`. "
                f"Ask me to analyse any of these tables by name."
            )
        else:
            answer = (
                f"The configured table is `{HISTORY_TABLE}`. "
                "I couldn't enumerate additional tables — check your Databricks credentials."
            )
        return {"type": "meta", "answer": answer, "sql": None, "columns": None, "rows": None}

    # Column/schema request
    if any(w in q for w in ["column", "columns", "fields", "schema", "describe"]):
        schema_text = SCHEMA_CONTEXT.strip()
        answer = f"Here are the key columns in `{HISTORY_TABLE}`:\n\n{schema_text}"
        return {"type": "meta", "answer": answer, "sql": None, "columns": None, "rows": None}

    # Fallback
    return {"type": "meta", "answer": f"I have access to `{HISTORY_TABLE}`. Ask me to describe its columns or list available tables.", "sql": None, "columns": None, "rows": None}


def answer_domain(question: str) -> dict:
    """Answer aviation/reliability domain questions using Ollama without SQL."""
    system = (
        "You are an aviation reliability and maintenance analytics expert with deep knowledge "
        "of MRO (Maintenance, Repair & Overhaul), component reliability analysis, MTBUR (Mean "
        "Time Between Unscheduled Removals), ATA chapters, LRU (Line Replaceable Units), "
        "Airworthiness Directives, and fleet management. "
        "Answer concisely and accurately. Use bullet points for lists. "
        "If the question relates to the AvTrix fleet data system, mention that you can run "
        "queries against the Databricks table for specific numbers."
    )
    answer, err = call_ollama(question, system_prompt=system)
    if err:
        return {"type": "domain", "answer": f"Ollama is not reachable: {err}", "sql": None, "columns": None, "rows": None}
    return {"type": "domain", "answer": answer, "sql": None, "columns": None, "rows": None}


def nl_to_sql(question: str):
    """Generate SQL from a natural language question using Ollama."""
    table_info = f"""
Table: {HISTORY_TABLE}
{SCHEMA_CONTEXT}

Additional rules for this query:
- Always reference the table as: {HISTORY_TABLE}
- Use LIMIT 500 unless the user asks for more
- Return ONLY the SQL query — no explanation, no markdown fences, no commentary
"""
    prompt = f"{table_info}\n\nQuestion: {question}\n\nSQL:"
    system = (
        "You are a Databricks SQL expert for aviation maintenance data. "
        "Generate valid Spark SQL only. No markdown. No explanation. Just the SQL. "
        "Never write a query that JOINs an aggregate CTE back to the base table — "
        "use a single flat SELECT with all aggregates instead."
    )
    sql, err = call_ollama(prompt, system_prompt=system)
    if err:
        return None, err
    # Clean up any accidental markdown fences
    sql = re.sub(r"```sql|```", "", sql).strip()
    return sql, None


def interpret_results(question: str, columns: list, rows: list) -> str:
    """Ask Ollama to interpret query results in plain English."""
    if not rows:
        return "The query returned no rows."
    preview_rows = rows[:20]
    table_text = " | ".join(columns) + "\n"
    table_text += "\n".join(" | ".join(str(v) for v in row) for row in preview_rows)
    if len(rows) > 20:
        table_text += f"\n... ({len(rows) - 20} more rows)"

    prompt = (
        f"Question: {question}\n\n"
        f"Query results:\n{table_text}\n\n"
        "Provide a concise, insightful interpretation of these results in 2-4 sentences. "
        "Focus on the key finding, notable patterns, and any reliability or operational implications."
    )
    system = (
        "You are an aviation reliability analyst. Interpret maintenance data results clearly "
        "and concisely. Highlight what matters operationally."
    )
    interpretation, _ = call_ollama(prompt, system_prompt=system, timeout=60)
    return interpretation or "Results retrieved — see table below."


_OVERVIEW_SQL = """
    SELECT
        COUNT(*)                                                                    AS total_records,
        COUNT(DISTINCT AC_REG)                                                      AS unique_aircraft,
        COUNT(DISTINCT REMOVED_PARTNO)                                              AS unique_part_numbers,
        MIN(TRY_CAST(REMOVAL_C_W_MOS AS DATE))                                     AS earliest_removal,
        MAX(TRY_CAST(REMOVAL_C_W_MOS AS DATE))                                     AS latest_removal,
        COUNT(DISTINCT YEAR(TRY_CAST(REMOVAL_C_W_MOS AS DATE)))                     AS years_covered,
        SUM(CASE WHEN JOBTYPE = 'SCHEDULED'   THEN 1 ELSE 0 END)                    AS scheduled_jobs,
        SUM(CASE WHEN JOBTYPE = 'UNSCHEDULED' THEN 1 ELSE 0 END)                    AS unscheduled_jobs,
        SUM(CASE WHEN JOBTYPE IS NULL          THEN 1 ELSE 0 END)                    AS null_jobtype,
        ROUND(SUM(CASE WHEN JOBTYPE IS NULL THEN 1.0 ELSE 0 END)
              * 100.0 / COUNT(*), 1)                                                AS pct_null_jobtype,
        SUM(CASE WHEN WORKORDER_NUMBER IS NULL
                  OR TRIM(WORKORDER_NUMBER) IN ('', '-', 'N/A')
             THEN 1 ELSE 0 END)                                                     AS missing_workorders,
        ROUND(SUM(CASE WHEN WORKORDER_NUMBER IS NULL
                       OR TRIM(WORKORDER_NUMBER) IN ('', '-', 'N/A')
                  THEN 1.0 ELSE 0 END)
              * 100.0 / COUNT(*), 1)                                                AS pct_missing_workorders,
        SUM(CASE WHEN REMOVED_SERIALNO IS NULL
                  OR TRIM(REMOVED_SERIALNO) IN ('', 'SN-UNKNOWN', 'NSN', 'NOT INSTALLED')
             THEN 1 ELSE 0 END)                                                     AS missing_removed_serial,
        ROUND(SUM(CASE WHEN REMOVED_SERIALNO IS NULL
                       OR TRIM(REMOVED_SERIALNO) IN ('', 'SN-UNKNOWN', 'NSN', 'NOT INSTALLED')
                  THEN 1.0 ELSE 0 END)
              * 100.0 / COUNT(*), 1)                                                AS pct_missing_removed_serial
    FROM {table}
"""


def _summarise_one_table(table_ref):
    """Run the overview SQL against one table using its OWN connection.
    A dedicated connection per thread is required — Databricks connections
    are not safe for concurrent cursor use across threads."""
    sql = _OVERVIEW_SQL.format(table=table_ref).strip()
    conn, err = _make_fresh_connection()
    if err:
        return table_ref, None, None, f"connection failed: {err}"
    try:
        cursor = conn.cursor()
        prefix = _catalog_prefix(table_ref)
        if prefix:
            cursor.execute(prefix)
        cursor.execute(sql)
        cols = [d[0] for d in cursor.description]
        rows = [list(r) for r in cursor.fetchall()]
        return table_ref, cols, rows, None
    except Exception as e:
        return table_ref, None, None, str(e)
    finally:
        try:
            conn.close()
        except Exception:
            pass


def answer_overview() -> dict:
    """
    Semantic-layer overview: query every discovered table for the same summary
    metrics, then ask Ollama to synthesise a cross-dataset narrative with
    similarities and differences highlighted.
    """
    import concurrent.futures

    tables = discovered_tables if discovered_tables else [HISTORY_TABLE]

    # Run summary queries in parallel (one thread per table)
    table_summaries = {}
    all_cols = None
    all_rows = []

    with concurrent.futures.ThreadPoolExecutor(max_workers=min(len(tables), 6)) as ex:
        futures = {ex.submit(_summarise_one_table, t): t for t in tables}
        for fut in concurrent.futures.as_completed(futures):
            tref, cols, rows, err = fut.result()
            if err or not rows:
                table_summaries[tref] = {"error": err or "no rows returned"}
            else:
                table_summaries[tref] = dict(zip(cols, rows[0]))
                if all_cols is None:
                    all_cols = ["dataset"] + cols
                all_rows.append([tref] + list(rows[0]))

    if not all_rows:
        # Surface the actual per-table error(s) instead of a generic message
        err_lines = []
        for tref, stats in table_summaries.items():
            if "error" in stats:
                err_lines.append(f"• `{tref}`: {stats['error']}")
        err_detail = "\n".join(err_lines) if err_lines else "No tables returned data."
        return {
            "type": "error",
            "answer": f"Could not retrieve summary stats. Query errors:\n\n{err_detail}",
            "sql": _OVERVIEW_SQL.strip(),
            "columns": None,
            "rows": None,
        }

    # Build a readable text block for Ollama
    summary_lines = []
    for tref, stats in table_summaries.items():
        if "error" in stats:
            summary_lines.append(f"Dataset: {tref}\n  ⚠ {stats['error']}")
        else:
            lines = [f"Dataset: {tref}"]
            for k, v in stats.items():
                lines.append(f"  {k}: {v}")
            summary_lines.append("\n".join(lines))

    summary_text = "\n\n".join(summary_lines)

    system = (
        "You are an aviation fleet reliability analyst. You have been given summary "
        "statistics for one or more maintenance datasets from a business aviation operator. "
        "Your job is to give a clear, concise overview that an engineering director would "
        "find useful — covering: what data exists, the date coverage, data quality issues "
        "(null jobtypes, missing work orders, missing serial numbers), and where datasets "
        "overlap or differ in scope. Use plain language. Use bullet points. Be direct about "
        "data quality problems — don't soften them. Flag anything anomalous."
    )

    narrative_prompt = (
        f"Here are the summary statistics for {len(table_summaries)} dataset(s) "
        f"in this Databricks environment:\n\n{summary_text}\n\n"
        "Please provide:\n"
        "1. A brief description of each dataset (what it appears to cover)\n"
        "2. Key metrics for each (record count, date range, aircraft count)\n"
        "3. Data quality highlights (null jobtypes, missing work orders/serials)\n"
        "4. If multiple datasets: similarities, differences, and any apparent overlap\n"
        "5. One or two recommended first questions to explore the data further"
    )

    narrative, err = call_ollama(narrative_prompt, system_prompt=system, timeout=120)
    if err or not narrative:
        # Fallback: return the raw table without narrative
        narrative = f"Retrieved stats for {len(all_rows)} dataset(s). See table below."

    return {
        "type": "overview",
        "answer": narrative,
        "sql": _OVERVIEW_SQL.strip(),
        "columns": all_cols,
        "rows": all_rows,
    }


def answer_integrity_check(table: str = None) -> dict:
    """Schema-agnostic data integrity check (Completeness). Introspects the
    table's columns and reports per-field null/placeholder rates in the
    standard AvTrix format. Works on ANY table."""
    table = table or HISTORY_TABLE

    # 1. introspect columns
    dcols, drows, derr = run_sql(f"DESCRIBE TABLE {table}")
    if derr:
        return {"type": "error", "answer": f"Could not describe `{table}`: {derr}",
                "sql": f"DESCRIBE TABLE {table}", "columns": None, "rows": None}
    columns = _parse_describe_columns(drows or [])
    if not columns:
        return {"type": "error", "answer": f"No columns found for `{table}`.",
                "sql": f"DESCRIBE TABLE {table}", "columns": None, "rows": None}

    # 2. profile (single query)
    sql = build_completeness_sql(table, columns)
    pcols, prows, perr = run_sql(sql)
    if perr or not prows:
        return {"type": "error",
                "answer": f"Integrity profile failed: {perr or 'no rows returned'}",
                "sql": sql, "columns": None, "rows": None}

    agg = dict(zip(pcols, prows[0]))
    header, report = format_completeness_rows(columns, agg)

    # 3. build display rows in the standard format + a scorecard narrative
    disp_cols = header
    disp_rows = [[r[h] for h in header] for r in report]

    total = report[0]["Total Rows"] if report else 0
    empty_cols = [r["Field Name"] for r in report if r["% Null"] >= 100]
    high_null  = [r["Field Name"] for r in report if 50 <= r["% Null"] < 100]
    clean      = [r["Field Name"] for r in report if r["% Null"] == 0]

    lines = [
        f"**Data integrity check — `{table}`**",
        f"{total:,} rows · {len(report)} columns · placeholders "
        f"('-', '--', 'PN', 'SN-UNKNOWN', etc.) counted as missing.",
        "",
        f"- Fully populated (0% null): **{len(clean)}**",
        f"- High null (≥50%): **{len(high_null)}**" + (f" — {', '.join(high_null)}" if high_null else ""),
        f"- Completely empty (100% null): **{len(empty_cols)}**" + (f" — {', '.join(empty_cols)}" if empty_cols else ""),
    ]
    return {
        "type": "integrity",
        "answer": "\n".join(lines),
        "sql": sql,
        "columns": disp_cols,
        "rows": disp_rows,
    }


def answer_analytical(question: str, shortcut_name: str = None) -> dict:
    """Run a SQL query (pre-built or generated) and return structured results."""
    sql = None

    # Use a named shortcut if provided
    if shortcut_name and shortcut_name in NAMED_QUERIES:
        sql = NAMED_QUERIES[shortcut_name]["sql"].format(table=HISTORY_TABLE).strip()
    else:
        # Generate SQL from the question
        sql, err = nl_to_sql(question)
        if err:
            return {"type": "error", "answer": f"Could not generate SQL: {err}", "sql": None, "columns": None, "rows": None}
        if not sql:
            return {"type": "error", "answer": "No SQL was generated.", "sql": None, "columns": None, "rows": None}

    columns, rows, err = run_sql(sql)
    if err:
        return {"type": "error", "answer": f"Query failed: {err}", "sql": sql, "columns": None, "rows": None}

    interpretation = interpret_results(question, columns, rows)

    return {
        "type": "analytical",
        "answer": interpretation,
        "sql": sql,
        "columns": columns,
        "rows": rows,
    }


# ── Chart helpers ─────────────────────────────────────────────────────────────
def detect_chart_type(columns, rows):
    """Auto-detect chart type from result shape."""
    if not columns or not rows:
        return None
    numeric_cols = []
    string_cols  = []
    date_cols    = []
    for i, col in enumerate(columns):
        col_l = col.lower()
        sample = [r[i] for r in rows[:20] if r[i] is not None]
        if any(kw in col_l for kw in ["year", "month", "date", "time", "quarter"]):
            date_cols.append(i)
        elif sample and isinstance(sample[0], (int, float)):
            numeric_cols.append(i)
        else:
            string_cols.append(i)

    if date_cols and numeric_cols:
        return "line"
    if string_cols and numeric_cols:
        return "bar"
    if len(numeric_cols) >= 2:
        return "scatter"
    return None


def build_chart(columns, rows, chart_type):
    """Build a Plotly JSON chart spec."""
    try:
        import plotly.graph_objects as go
        import plotly

        copper = "#B8864F"
        copper2 = "#CBA36A"
        slate  = "#1A1F25"

        if chart_type == "bar":
            # First string col = labels, first numeric col = values
            label_idx = next((i for i, c in enumerate(columns)
                              if not isinstance(rows[0][i], (int, float))), 0)
            val_idx   = next((i for i, c in enumerate(columns)
                              if isinstance(rows[0][i], (int, float))), 1)
            fig = go.Figure(go.Bar(
                x=[str(r[label_idx]) for r in rows],
                y=[r[val_idx] for r in rows],
                marker_color=copper,
            ))
            fig.update_layout(xaxis_title=columns[label_idx], yaxis_title=columns[val_idx])

        elif chart_type == "line":
            # Date/year col = x, all numeric cols = series
            date_idx = next((i for i, c in enumerate(columns)
                             if any(k in c.lower() for k in ["year","month","date","time","quarter"])), 0)
            numeric_idxs = [i for i in range(len(columns)) if i != date_idx
                            and rows and isinstance(rows[0][i], (int, float))]
            colors = [copper, copper2, "#8F6435", "#FCFAF6"]
            fig = go.Figure()
            for k, ni in enumerate(numeric_idxs[:4]):
                fig.add_trace(go.Scatter(
                    x=[r[date_idx] for r in rows],
                    y=[r[ni] for r in rows],
                    name=columns[ni],
                    line=dict(color=colors[k % len(colors)], width=2),
                    mode="lines+markers",
                ))
            fig.update_layout(xaxis_title=columns[date_idx])

        elif chart_type == "scatter":
            fig = go.Figure(go.Scatter(
                x=[r[0] for r in rows],
                y=[r[1] for r in rows],
                mode="markers",
                marker=dict(color=copper, size=6),
            ))
            fig.update_layout(xaxis_title=columns[0], yaxis_title=columns[1])
        else:
            return None

        fig.update_layout(
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#FCFAF6", family="Inter, ui-sans-serif, sans-serif"),
            margin=dict(l=40, r=20, t=30, b=40),
            height=280,
            showlegend=len(fig.data) > 1,
        )
        return json.loads(plotly.io.to_json(fig))
    except Exception:
        return None


# ── Routes ────────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_html()


@app.route("/api/status")
def api_status():
    # Check Ollama (fast, local — 5s timeout already in check_ollama)
    ollama_ok, ollama_info = check_ollama()

    # Check Databricks with a hard 8s timeout so the page never freezes
    db_ok = False
    db_err = None
    result = [None, "timeout"]

    def _try_db():
        conn, err = get_connection()
        result[0] = conn
        result[1] = err

    t = threading.Thread(target=_try_db, daemon=True)
    t.start()
    t.join(timeout=8)
    if result[1] == "timeout":
        db_err = "Connection timed out — Databricks may be starting up"
        db_ok = False
    elif result[1]:
        db_err = result[1]
        db_ok = False
    else:
        db_ok = True

    return jsonify({
        "ollama": {"ok": ollama_ok, "info": ollama_info},
        "databricks": {"ok": db_ok, "error": db_err},
        "model": OLLAMA_MODEL,
        "table": HISTORY_TABLE,
        "discovered_tables": discovered_tables,
    })


@app.route("/api/tables")
def api_tables():
    return jsonify({"tables": discovered_tables, "active": HISTORY_TABLE})


@app.route("/api/shortcuts")
def api_shortcuts():
    return jsonify({
        name: {"description": q["description"]}
        for name, q in NAMED_QUERIES.items()
    })


@app.route("/api/models")
def api_models():
    """List installed Ollama models (via the local Ollama /api/tags)."""
    ok, info = check_ollama()
    models = info if ok and isinstance(info, list) else []
    return jsonify({"models": models, "active": OLLAMA_MODEL})


@app.route("/api/model", methods=["POST"])
def api_set_model():
    """Switch the active Ollama model used for SQL generation and narratives."""
    global OLLAMA_MODEL
    data = request.json or {}
    name = (data.get("model") or "").strip()
    if not name:
        return jsonify({"ok": False, "error": "No model given"}), 400
    ok, info = check_ollama()
    installed = info if ok and isinstance(info, list) else []
    # exact or unique-prefix match
    exact = [m for m in installed if m == name]
    partial = [m for m in installed if name in m]
    if exact:
        OLLAMA_MODEL = exact[0]
    elif len(partial) == 1:
        OLLAMA_MODEL = partial[0]
    elif len(partial) > 1:
        return jsonify({"ok": False, "error": f"Ambiguous: {', '.join(partial)}"}), 400
    else:
        OLLAMA_MODEL = name  # allow; user may pull it
    return jsonify({"ok": True, "model": OLLAMA_MODEL})


@app.route("/api/query", methods=["POST"])
def api_query():
    data = request.json or {}
    question = (data.get("question") or "").strip()
    shortcut = data.get("shortcut") or None

    if not question and not shortcut:
        return jsonify({"error": "No question provided"}), 400

    display_question = question
    if shortcut and shortcut in NAMED_QUERIES:
        display_question = NAMED_QUERIES[shortcut]["description"]

    # Add to conversation history
    conversation_history.append({
        "role": "user",
        "content": display_question,
        "timestamp": datetime.now().strftime("%H:%M"),
    })

    # Route the intent
    if not shortcut and _is_guardrails_question(question):
        result = answer_guardrails()
    elif not shortcut and _is_capabilities_question(question):
        result = answer_capabilities()
    elif shortcut == "integrity_check" or (not shortcut and _is_integrity_question(question)):
        display_question = "Data integrity check"
        result = answer_integrity_check(HISTORY_TABLE)
    elif shortcut == "dataset_overview" or (not shortcut and _match_shortcut_by_intent(question) == "dataset_overview"):
        # Semantic overview: queries all discovered tables, synthesises narrative
        display_question = "General overview — all datasets"
        result = answer_overview()
    elif shortcut:
        result = answer_analytical(display_question, shortcut_name=shortcut)
    else:
        # Check if the free-text question matches any other named shortcut by intent
        auto_shortcut = _match_shortcut_by_intent(question)
        if auto_shortcut:
            display_question = NAMED_QUERIES[auto_shortcut]["description"]
            result = answer_analytical(display_question, shortcut_name=auto_shortcut)
        else:
            intent = classify_intent(question)
            if intent == "meta":
                result = answer_meta(question)
            elif intent == "domain":
                result = answer_domain(question)
            else:
                result = answer_analytical(question)

    # Build chart only for analytical results — integrity/overview/meta tables
    # are not meaningfully chartable.
    chart = None
    if result.get("type") == "analytical" and result.get("columns") and result.get("rows"):
        chart_type = detect_chart_type(result["columns"], result["rows"])
        if chart_type:
            chart = build_chart(result["columns"], result["rows"], chart_type)

    # Summarise rows for JSON (cap at 500 for browser)
    rows_payload = result.get("rows") or []
    if len(rows_payload) > 500:
        rows_payload = rows_payload[:500]

    response = {
        "question": display_question,
        "intent": result["type"],
        "answer": result["answer"],
        "sql": result.get("sql"),
        "columns": result.get("columns"),
        "rows": rows_payload,
        "total_rows": len(result.get("rows") or []),
        "chart": chart,
        "timestamp": datetime.now().strftime("%H:%M"),
    }

    conversation_history.append({
        "role": "assistant",
        "content": result["answer"],
        "timestamp": response["timestamp"],
    })

    return jsonify(response)


@app.route("/api/clear", methods=["POST"])
def api_clear():
    conversation_history.clear()
    return jsonify({"ok": True})


# ── HTML Template ─────────────────────────────────────────────────────────────
def render_html():
    shortcuts_json = json.dumps({
        name: q["description"] for name, q in NAMED_QUERIES.items()
    })
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AvTrix Fleet Intelligence</title>
<script src="https://cdn.jsdelivr.net/npm/plotly.js-dist@2.27.0/plotly.min.js"></script>
<style>
:root {{
  --bg:        #0F1318;
  --panel:     #1A1F25;
  --panel2:    #232A33;
  --panel3:    #2A3340;
  --line:      #2E3742;
  --text:      #E8E4DC;
  --muted:     #8A9BAD;
  --copper:    #B8864F;
  --copper-d:  #8F6435;
  --copper-l:  #CBA36A;
  --cream:     #FCFAF6;
  --good:      #4CAF7D;
  --warn:      #E8A844;
  --bad:       #E05454;
  --accent:    #B8864F;
}}

*, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}
html, body {{ height: 100%; background: var(--bg); color: var(--text); font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; font-size: 14px; }}

/* ── Layout ── */
.app {{ display: grid; grid-template-columns: 220px minmax(0,1fr) 260px; height: 100vh; overflow: hidden; }}

/* ── Sidebar ── */
.sidebar {{
  background: var(--panel);
  border-right: 1px solid var(--line);
  display: flex; flex-direction: column; gap: 12px;
  padding: 16px 12px; overflow-y: auto;
}}
.brand {{ display:flex; align-items:center; gap:10px; padding: 4px 6px; font-weight:600; }}
.logo {{
  width:32px; height:32px; border-radius:9px;
  background: linear-gradient(135deg, var(--copper) 0%, var(--copper-d) 100%);
  display:grid; place-items:center; font-size:16px; flex:0 0 auto;
}}
.new-btn {{
  display:flex; align-items:center; justify-content:center; gap:8px;
  background: var(--copper); color: var(--cream); border:none; border-radius:9px;
  padding: 10px; font-weight:600; cursor:pointer; font-size:14px; width:100%;
}}
.new-btn:hover {{ background: var(--copper-l); }}
.side-label {{ color:var(--muted); text-transform:uppercase; letter-spacing:.08em; font-size:11px; padding:0 6px; margin-top:4px; }}
.thread-list {{ display:grid; gap:3px; }}
.thread-btn {{
  text-align:left; padding:9px 10px; border:none; border-radius:7px;
  background:transparent; color:var(--muted); cursor:pointer;
  overflow:hidden; text-overflow:ellipsis; white-space:nowrap; width:100%;
  font-size:13px;
}}
.thread-btn.active, .thread-btn:hover {{ background:var(--panel3); color:var(--text); }}
.sidebar-foot {{ margin-top:auto; border-top:1px solid var(--line); padding-top:12px; display:grid; gap:8px; }}
.runtime {{ display:flex; align-items:center; gap:8px; color:var(--muted); font-size:12px; padding:0 6px; }}
.dot {{ width:8px; height:8px; border-radius:50%; background:var(--good); flex:0 0 auto; }}
.dot.bad {{ background: var(--bad); }}
.dot.warn {{ background: var(--warn); }}

/* ── Mode switch ── */
.mode-switch {{ display:inline-flex; align-items:center; gap:3px; padding:3px; border:1px solid var(--line); border-radius:10px; background:var(--panel2); }}
.mode-btn {{
  min-height:30px; padding:4px 12px; border:none; border-radius:7px;
  background:transparent; color:var(--muted); cursor:pointer; font-size:13px;
}}
.mode-btn.active {{ background:var(--panel3); color:var(--text); }}

/* ── Topbar ── */
.topbar {{
  border-bottom:1px solid var(--line); padding:12px 20px;
  display:flex; align-items:center; gap:16px; flex-wrap:wrap;
}}
.topbar-title {{ flex:1; }}
.topbar-title strong {{ display:block; font-size:15px; }}
.topbar-title span {{ color:var(--muted); font-size:12px; }}
.status-row {{ display:flex; gap:8px; flex-wrap:wrap; }}
.pill {{
  display:inline-flex; align-items:center; gap:6px;
  padding:4px 10px; border-radius:20px; font-size:12px;
  background:var(--panel2); border:1px solid var(--line); color:var(--muted);
}}
.pill.ok {{ border-color: var(--good); color: var(--good); }}
.pill.warn {{ border-color: var(--warn); color: var(--warn); }}

/* ── Main chat panel ── */
.main {{ display:flex; flex-direction:column; min-width:0; min-height:0; height:100vh; background:var(--bg); }}
.chat {{ flex:1; min-height:0; overflow-y:auto; padding:24px 28px; display:flex; flex-direction:column; gap:20px; }}

.welcome {{ text-align:center; padding:40px 20px; color:var(--muted); }}
.welcome h2 {{ font-size:22px; color:var(--text); margin-bottom:10px; }}
.welcome p {{ max-width:480px; margin:0 auto; line-height:1.6; }}

.suggestions {{ display:flex; flex-wrap:wrap; gap:8px; justify-content:center; margin-top:20px; }}
.suggestion-btn {{
  padding:8px 14px; border-radius:20px; border:1px solid var(--copper-d);
  background:transparent; color:var(--copper-l); cursor:pointer; font-size:13px;
}}
.suggestion-btn:hover {{ background:var(--panel2); }}

/* ── Model switcher ── */
.model-switch-row {{ display:flex; align-items:center; gap:8px; margin:8px 0; font-size:12px; color:var(--muted); }}
.model-switch-row label {{ flex:0 0 auto; }}
.model-switch-row select {{
  flex:1; min-width:0; background:var(--panel2); color:var(--text);
  border:1px solid var(--line); border-radius:6px; padding:4px 6px; font-size:12px; cursor:pointer;
}}

/* ── Messages ── */
.message {{ display:flex; gap:12px; max-width:100%; }}
.message.user {{ flex-direction:row-reverse; }}
.message.user .bubble {{ background:var(--copper); color:var(--cream); border-radius:18px 4px 18px 18px; }}
.message .bubble {{
  background:var(--panel); border-radius:4px 18px 18px 18px;
  padding:14px 18px; max-width:82%; line-height:1.6;
}}
.message.user .bubble {{ max-width:72%; }}
.avatar {{
  width:30px; height:30px; border-radius:50%;
  background: linear-gradient(135deg, var(--copper) 0%, var(--copper-d) 100%);
  display:grid; place-items:center; font-size:14px; flex:0 0 auto; margin-top:4px;
}}

.answer-lead {{ font-weight:600; margin-bottom:8px; color:var(--cream); }}
.answer-meta {{
  display:flex; align-items:center; gap:12px; margin-top:12px;
  font-size:12px; color:var(--muted);
}}
.sql-toggle {{ background:none; border:none; color:var(--copper-l); cursor:pointer; font-size:12px; text-decoration:underline; }}
.sql-block {{
  display:none; margin-top:10px; background:var(--panel2); border-radius:8px;
  padding:12px 14px; font-family:monospace; font-size:12px; white-space:pre-wrap;
  word-break:break-all; color:var(--cream); border:1px solid var(--line);
}}
.sql-block.open {{ display:block; }}

/* ── Result tabs ── */
.result-tabs-row {{ display:flex; gap:4px; margin-top:14px; border-bottom:1px solid var(--line); padding-bottom:6px; }}
.result-tab-btn {{ background:none; border:none; color:var(--muted); cursor:pointer; padding:4px 10px; border-radius:6px; font-size:12px; }}
.result-tab-btn.active {{ color:var(--text); background:var(--panel2); }}
.result-panel {{ margin-top:10px; }}
.result-panel[hidden] {{ display:none; }}

/* ── Mini table ── */
.mini-table {{ width:100%; border-collapse:collapse; font-size:13px; }}
.mini-table th {{ text-align:left; padding:7px 10px; color:var(--muted); border-bottom:1px solid var(--line); font-weight:500; }}
.mini-table td {{ padding:7px 10px; border-bottom:1px solid var(--line); vertical-align:top; }}
.mini-table tr:last-child td {{ border-bottom:none; }}
.mini-table tr:hover td {{ background:var(--panel2); }}
.row-count {{ color:var(--muted); font-size:12px; margin-top:6px; }}

/* ── Chart area ── */
.chart-wrap {{ margin-top:12px; background:var(--panel); border-radius:10px; padding:16px; border:1px solid var(--line); overflow:hidden; }}

/* ── Analyst split layout ── */
.analyst-body {{ display:grid; grid-template-columns:minmax(0,1fr) minmax(0,1fr); flex:1; min-height:0; overflow:hidden; }}
.analyst-chat {{ border-right:1px solid var(--line); display:flex; flex-direction:column; }}
.analyst-canvas {{ display:flex; flex-direction:column; background:var(--panel); }}
.canvas-head {{ padding:16px 20px; border-bottom:1px solid var(--line); }}
.canvas-head h2 {{ font-size:15px; font-weight:600; }}
.canvas-head p {{ color:var(--muted); font-size:12px; margin-top:2px; }}
.canvas-body {{ flex:1; overflow-y:auto; padding:16px 20px; display:flex; flex-direction:column; gap:16px; }}

/* ── Composer ── */
.composer {{ border-top:1px solid var(--line); padding:16px 20px; background:var(--panel); }}
.composer textarea {{
  width:100%; background:var(--panel2); border:1px solid var(--line);
  border-radius:10px; color:var(--text); padding:12px 14px;
  resize:none; outline:none; font:inherit; line-height:1.5;
  min-height:80px;
}}
.composer textarea:focus {{ border-color:var(--copper-d); }}
.compose-foot {{ display:flex; align-items:center; justify-content:space-between; margin-top:8px; }}
.send-btn {{
  background: var(--copper); color: var(--cream); border:none; border-radius:9px;
  padding:9px 20px; font-weight:600; cursor:pointer; font-size:14px;
}}
.send-btn:hover {{ background:var(--copper-l); }}
.send-btn:disabled {{ opacity:0.5; cursor:not-allowed; }}

/* ── Context panel ── */
.context-panel {{ background:var(--panel); border-left:1px solid var(--line); padding:20px 16px; overflow-y:auto; display:flex; flex-direction:column; gap:20px; }}
.context-panel h3 {{ font-size:13px; font-weight:600; text-transform:uppercase; letter-spacing:.06em; color:var(--muted); }}
.context-section {{ display:grid; gap:8px; }}
.context-label {{ font-size:11px; color:var(--muted); text-transform:uppercase; letter-spacing:.06em; }}
.context-value {{ font-size:13px; font-weight:500; color:var(--cream); }}
.tag-row {{ display:flex; flex-wrap:wrap; gap:6px; }}
.tag {{ padding:3px 8px; border-radius:12px; border:1px solid var(--line); font-size:11px; color:var(--muted); }}
.security-list {{ display:grid; gap:6px; }}
.security-item {{ display:flex; align-items:center; gap:8px; font-size:12px; color:var(--muted); }}

/* ── Shortcuts panel (in context) ── */
.shortcuts-list {{ display:grid; gap:4px; }}
.shortcut-btn {{
  text-align:left; padding:8px 10px; border:1px solid var(--line);
  border-radius:8px; background:transparent; color:var(--muted);
  cursor:pointer; font-size:12px; line-height:1.4;
}}
.shortcut-btn:hover {{ background:var(--panel2); color:var(--text); border-color:var(--copper-d); }}

/* ── Table picker ── */
.table-picker {{ display:grid; gap:4px; }}
.table-item {{
  display:flex; align-items:center; gap:8px; padding:7px 10px;
  border-radius:7px; font-size:12px; font-family:monospace;
  color:var(--muted); cursor:pointer; user-select:none;
}}
.table-item.active {{ color:var(--copper-l); }}
.table-item:hover {{ background:var(--panel2); color:var(--text); }}
.table-dot {{ width:6px; height:6px; border-radius:50%; background:var(--line); flex:0 0 auto; }}
.table-item.active .table-dot {{ background:var(--copper); }}

/* ── Thinking indicator ── */
.thinking {{ display:flex; gap:12px; align-items:flex-start; }}
.thinking-dots span {{
  display:inline-block; width:6px; height:6px; border-radius:50%;
  background:var(--copper); animation:blink 1.2s infinite;
}}
.thinking-dots span:nth-child(2) {{ animation-delay:.2s; }}
.thinking-dots span:nth-child(3) {{ animation-delay:.4s; }}
@keyframes blink {{ 0%,80%,100%{{opacity:.2}} 40%{{opacity:1}} }}

/* ── Error state ── */
.error-bubble {{ background:color-mix(in srgb,var(--bad) 15%,var(--panel)); border:1px solid var(--bad); border-radius:10px; padding:12px 16px; color:var(--bad); font-size:13px; }}

/* ── Analyst canvas sections ── */
.canvas-chart-panel {{ background:var(--panel2); border-radius:10px; padding:16px; border:1px solid var(--line); }}
.canvas-result-panel {{ background:var(--panel2); border-radius:10px; border:1px solid var(--line); }}
.canvas-result-head {{ padding:12px 14px; border-bottom:1px solid var(--line); display:flex; gap:6px; }}

/* ── Scrollbars ── */
::-webkit-scrollbar {{ width:6px; height:6px; }}
::-webkit-scrollbar-track {{ background:transparent; }}
::-webkit-scrollbar-thumb {{ background:var(--line); border-radius:3px; }}
::-webkit-scrollbar-thumb:hover {{ background:var(--muted); }}
</style>
</head>
<body>

<div class="app" id="app">

  <!-- ── Sidebar ── -->
  <aside class="sidebar">
    <div class="brand">
      <div class="logo">✦</div>
      <span>AvTrix AI</span>
    </div>

    <button class="new-btn" onclick="newConversation()">＋ New conversation</button>

    <div class="side-label">Interface</div>
    <div class="mode-switch">
      <button class="mode-btn active" id="mode-focused" onclick="setMode('focused')">Focused</button>
      <button class="mode-btn" id="mode-analyst" onclick="setMode('analyst')">Analyst</button>
    </div>

    <div class="side-label" style="margin-top:8px">Recent</div>
    <div class="thread-list" id="thread-list">
      <!-- populated dynamically -->
    </div>

    <div class="sidebar-foot">
      <div class="runtime" id="ollama-status">
        <span class="dot warn" id="ollama-dot"></span>
        <span id="ollama-label">Checking Ollama…</span>
      </div>
      <div class="model-switch-row">
        <label for="model-select">Model</label>
        <select id="model-select" onchange="switchModel(this.value)" title="Switch the local model used for SQL and narratives">
          <option>…</option>
        </select>
      </div>
      <div class="runtime" id="db-status">
        <span class="dot warn" id="db-dot"></span>
        <span id="db-label">Checking Databricks…</span>
      </div>
    </div>
  </aside>

  <!-- ── Main area (focused mode) ── -->
  <main class="main" id="focused-main">
    <header class="topbar">
      <div class="topbar-title">
        <strong id="convo-title">Fleet Intelligence</strong>
        <span>Powered by local AI + Databricks</span>
      </div>
      <div class="status-row" id="status-pills">
        <span class="pill" id="pill-model">⏳ Loading…</span>
        <span class="pill" id="pill-db">⏳ Databricks</span>
      </div>
    </header>

    <div class="chat" id="chat-area">
      <div class="welcome" id="welcome-msg">
        <h2>Ask your fleet data</h2>
        <p>I'll answer schema questions instantly, aviation knowledge from memory, and complex analytics by querying Databricks — all locally, no data leaves your machine.</p>
        <div class="suggestions">
          <button class="suggestion-btn" onclick="fillPrompt('Give me a general overview')">General overview</button>
          <button class="suggestion-btn" onclick="fillPrompt('Run a data integrity check')">Data integrity check</button>
          <button class="suggestion-btn" onclick="fillPrompt('What tables do you have access to?')">What tables do you have?</button>
          <button class="suggestion-btn" onclick="fillPrompt('What is MTBUR and why does it matter?')">What is MTBUR?</button>
          <button class="suggestion-btn" onclick="fillPrompt('Show me the jobtype distribution')">Jobtype distribution</button>
          <button class="suggestion-btn" onclick="fillPrompt('Which aircraft have the most removals?')">Most removals by aircraft</button>
        </div>
      </div>
    </div>

    <div class="composer">
      <label for="main-prompt" style="display:none">Ask a question</label>
      <textarea id="main-prompt" placeholder="Ask about your fleet data, schema, or aviation reliability…" rows="3" onkeydown="handleKey(event)"></textarea>
      <div class="compose-foot">
        <span style="color:var(--muted);font-size:12px" id="active-table-label"></span>
        <button class="send-btn" id="send-btn" onclick="sendQuestion()">Send ↑</button>
      </div>
    </div>
  </main>

  <!-- ── Analyst main (split view) ── -->
  <main class="main" id="analyst-main" style="display:none">
    <header class="topbar">
      <div class="topbar-title">
        <strong>Analyst Workspace</strong>
        <span>Chat + live canvas</span>
      </div>
      <div class="status-row" id="analyst-status-pills">
        <span class="pill" id="analyst-pill-model">⏳ Loading…</span>
        <span class="pill" id="analyst-pill-db">⏳ Databricks</span>
      </div>
    </header>
    <div class="analyst-body">
      <div class="analyst-chat main">
        <div class="chat" id="analyst-chat-area">
          <div class="welcome">
            <h2>Analyst mode</h2>
            <p>Results appear in the canvas panel on the right.</p>
          </div>
        </div>
        <div class="composer">
          <textarea id="analyst-prompt" placeholder="Continue the analysis…" rows="3" onkeydown="handleAnalystKey(event)"></textarea>
          <div class="compose-foot">
            <span></span>
            <button class="send-btn" id="analyst-send-btn" onclick="sendAnalystQuestion()">Send ↑</button>
          </div>
        </div>
      </div>
      <div class="analyst-canvas">
        <div class="canvas-head">
          <h2 id="canvas-title">Canvas</h2>
          <p id="canvas-sub">Results will appear here</p>
        </div>
        <div class="canvas-body" id="canvas-body">
          <p style="color:var(--muted);font-size:13px">Send a question to see the chart and data here.</p>
        </div>
      </div>
    </div>
  </main>

  <!-- ── Context panel ── -->
  <aside class="context-panel">
    <h3>Context</h3>

    <div class="context-section">
      <div class="context-label">Active table</div>
      <div class="context-value" id="ctx-table" style="font-size:12px;font-family:monospace;word-break:break-all">–</div>
      <div class="table-picker" id="table-picker">
        <!-- populated from /api/tables -->
      </div>
    </div>

    <div class="context-section">
      <div class="context-label">Query protection</div>
      <div class="security-list">
        <div class="security-item">🔒 Read-only access</div>
        <div class="security-item">📋 500-row maximum</div>
        <div class="security-item">⏱ 60-second timeout</div>
        <div class="security-item">🏠 Local model only</div>
      </div>
    </div>

    <div class="context-section">
      <div class="context-label">Quick shortcuts</div>
      <div class="shortcuts-list" id="shortcuts-list">
        <!-- populated from /api/shortcuts -->
      </div>
    </div>
  </aside>

</div>

<script>
const SHORTCUTS = {shortcuts_json};

let currentMode = 'focused';
let activeTable = '';
let conversationCount = 0;
let lastResult = null;  // {{columns, rows, question}} of the most recent tabular result

// Detect a request to re-chart the LAST result (never hits the model).
// Returns 'pie' | 'bar' | 'line' | null.
function detectChartRequest(text) {{
  const t = text.toLowerCase();
  const isChartish = /\\b(chart|graph|plot|visuali[sz]e|pie|bar graph|bar chart|line graph|line chart|donut|percentage|percentages|%)\\b/.test(t);
  if (!isChartish) return null;
  // Must refer to existing data, not request new data
  const refersExisting = /\\b(this|that|it|these|the (result|results|data|numbers|above))\\b/.test(t)
                         || /\\b(as|into|in) a\\b/.test(t)
                         || /\\bpresent\\b/.test(t)
                         || /\\bshow\\b/.test(t);
  if (!refersExisting) return null;
  if (/\\bpie\\b|\\bdonut\\b/.test(t)) return 'pie';
  if (/\\bline\\b/.test(t)) return 'line';
  if (/\\bbar\\b/.test(t)) return 'bar';
  // generic "chart this" → pick based on data shape later; default pie if percentages mentioned
  if (/\\bpercentage|%\\b/.test(t)) return 'pie';
  return 'bar';
}}

// Build a Plotly spec client-side from cached rows/columns.
function buildChartSpecJS(columns, rows, type) {{
  const copper = '#B8864F', copper2 = '#CBA36A';
  const palette = ['#B8864F','#CBA36A','#8F6435','#D9B98A','#6E4B28','#E8D5B5','#A8763C'];
  // find first text column (labels) and first numeric column (values)
  let labelIdx = -1, valIdx = -1;
  for (let i=0;i<columns.length;i++) {{
    const v = rows[0][i];
    if (labelIdx<0 && (typeof v === 'string')) labelIdx = i;
    if (valIdx<0 && (typeof v === 'number')) valIdx = i;
  }}
  if (valIdx<0) valIdx = columns.length>1?1:0;
  if (labelIdx<0) labelIdx = 0;

  const labels = rows.map(r => String(r[labelIdx]));
  const values = rows.map(r => Number(r[valIdx]) || 0);

  const layout = {{
    paper_bgcolor:'rgba(0,0,0,0)', plot_bgcolor:'rgba(0,0,0,0)',
    font:{{color:'#FCFAF6', family:'Inter, ui-sans-serif, sans-serif'}},
    margin:{{l:40,r:20,t:30,b:40}}, height:300, showlegend:true
  }};
  let data;
  if (type === 'pie') {{
    data = [{{ type:'pie', labels, values, textinfo:'label+percent',
               hole:0, marker:{{colors:palette}}, sort:true }}];
    layout.showlegend = true;
  }} else if (type === 'line') {{
    data = [{{ type:'scatter', mode:'lines+markers', x:labels, y:values,
               line:{{color:copper,width:2}} }}];
    layout.xaxis_title = columns[labelIdx]; layout.yaxis_title = columns[valIdx];
  }} else {{
    data = [{{ type:'bar', x:labels, y:values, marker:{{color:copper}} }}];
    layout.xaxis_title = columns[labelIdx]; layout.yaxis_title = columns[valIdx];
    layout.showlegend = false;
  }}
  return {{ data, layout }};
}}

// ── Init ──
async function init() {{
  // loadStatus runs independently — it can be slow (Databricks cold start)
  // and must never block the UI from becoming interactive.
  loadStatus();
  loadModels();
  await Promise.all([loadTables(), loadShortcuts()]);
}}

async function loadModels() {{
  try {{
    const r = await fetch('/api/models');
    const d = await r.json();
    const sel = document.getElementById('model-select');
    if (!sel) return;
    const models = d.models || [];
    if (!models.length) {{ sel.innerHTML = '<option>no models</option>'; return; }}
    sel.innerHTML = models.map(m =>
      `<option value="${{escHtml(m)}}" ${{m === d.active ? 'selected' : ''}}>${{escHtml(m)}}</option>`
    ).join('');
  }} catch(e) {{
    const sel = document.getElementById('model-select');
    if (sel) sel.innerHTML = '<option>unavailable</option>';
  }}
}}

async function switchModel(name) {{
  if (!name) return;
  try {{
    const r = await fetch('/api/model', {{
      method:'POST', headers:{{'Content-Type':'application/json'}},
      body: JSON.stringify({{model: name}})
    }});
    const d = await r.json();
    if (d.ok) {{
      window._model = d.model;
      const olab = document.getElementById('ollama-label');
      if (olab) olab.textContent = d.model + ' · local';
    }}
  }} catch(e) {{ /* non-fatal */ }}
}}

async function loadStatus() {{
  try {{
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 6000);
    const r = await fetch('/api/status', {{ signal: controller.signal }});
    clearTimeout(timer);
    const d = await r.json();

    // Ollama
    const odot = document.getElementById('ollama-dot');
    const olab = document.getElementById('ollama-label');
    if (d.ollama.ok) {{
      odot.className = 'dot';
      olab.textContent = d.model + ' · local';
    }} else {{
      odot.className = 'dot bad';
      olab.textContent = 'Ollama offline';
    }}

    // Databricks
    const ddot = document.getElementById('db-dot');
    const dlab = document.getElementById('db-label');
    if (d.databricks.ok) {{
      ddot.className = 'dot';
      dlab.textContent = 'Databricks connected';
    }} else {{
      ddot.className = 'dot bad';
      dlab.textContent = 'Databricks error';
    }}

    // Status pills (focused)
    document.getElementById('pill-model').textContent = d.ollama.ok ? ('✦ ' + d.model) : '✗ Ollama offline';
    document.getElementById('pill-model').className = 'pill ' + (d.ollama.ok ? 'ok' : 'warn');
    document.getElementById('pill-db').textContent = d.databricks.ok ? '🗄 Databricks ready' : '✗ DB error';
    document.getElementById('pill-db').className = 'pill ' + (d.databricks.ok ? 'ok' : 'warn');

    // Analyst pills
    document.getElementById('analyst-pill-model').textContent = d.ollama.ok ? ('✦ ' + d.model) : '✗ Ollama offline';
    document.getElementById('analyst-pill-model').className = 'pill ' + (d.ollama.ok ? 'ok' : 'warn');
    document.getElementById('analyst-pill-db').textContent = d.databricks.ok ? '🗄 Databricks ready' : '✗ DB error';
    document.getElementById('analyst-pill-db').className = 'pill ' + (d.databricks.ok ? 'ok' : 'warn');

    activeTable = d.table || '';
    document.getElementById('ctx-table').textContent = activeTable;
    document.getElementById('active-table-label').textContent = activeTable ? ('Table: ' + activeTable.split('.').pop()) : '';
  }} catch(e) {{
    console.warn('Status check failed', e);
    document.getElementById('ollama-dot').className = 'dot warn';
    document.getElementById('ollama-label').textContent = 'Status check failed';
    document.getElementById('db-dot').className = 'dot warn';
    document.getElementById('db-label').textContent = 'Status check failed';
    document.getElementById('pill-model').textContent = '⚠ Status check failed';
    document.getElementById('pill-db').textContent = '⚠ Status check failed';
  }}
}}

async function loadTables() {{
  try {{
    const r = await fetch('/api/tables');
    const d = await r.json();
    const picker = document.getElementById('table-picker');
    picker.innerHTML = '';
    d.tables.forEach(t => {{
      const div = document.createElement('div');
      div.className = 'table-item' + (t === d.active ? ' active' : '');
      const parts = t.split('.');
      const short = parts[parts.length - 1];
      div.innerHTML = `<span class="table-dot"></span><span title="${{t}}">${{short}}</span>`;
      div.title = t;
      picker.appendChild(div);
    }});
  }} catch(e) {{}}
}}

async function loadShortcuts() {{
  const list = document.getElementById('shortcuts-list');
  list.innerHTML = '';
  Object.entries(SHORTCUTS).forEach(([name, desc]) => {{
    const btn = document.createElement('button');
    btn.className = 'shortcut-btn';
    btn.textContent = desc;
    btn.onclick = () => runShortcut(name, desc);
    list.appendChild(btn);
  }});
}}

// ── Mode ──
function setMode(mode) {{
  currentMode = mode;
  document.getElementById('focused-main').style.display = mode === 'focused' ? 'flex' : 'none';
  document.getElementById('analyst-main').style.display  = mode === 'analyst'  ? 'flex' : 'none';
  document.getElementById('focused-main').style.flexDirection = 'column';
  document.getElementById('analyst-main').style.flexDirection = 'column';
  document.getElementById('mode-focused').className = 'mode-btn' + (mode === 'focused' ? ' active' : '');
  document.getElementById('mode-analyst').className  = 'mode-btn' + (mode === 'analyst'  ? ' active' : '');
}}

// ── Conversation ──
function newConversation() {{
  fetch('/api/clear', {{method:'POST'}});
  document.getElementById('chat-area').innerHTML = document.getElementById('welcome-msg')?.outerHTML || '';
  document.getElementById('analyst-chat-area').innerHTML = '<div class="welcome"><h2>Analyst mode</h2><p>Results appear in the canvas panel on the right.</p></div>';
  document.getElementById('canvas-body').innerHTML = '<p style="color:var(--muted);font-size:13px">Send a question to see the chart and data here.</p>';
  document.getElementById('main-prompt').value = '';
  document.getElementById('analyst-prompt').value = '';
  conversationCount = 0;
}}

function addThread(text) {{
  const list = document.getElementById('thread-list');
  const btn = document.createElement('button');
  btn.className = 'thread-btn active';
  btn.textContent = text.length > 36 ? text.slice(0,34)+'…' : text;
  list.querySelectorAll('.thread-btn').forEach(b => b.classList.remove('active'));
  list.prepend(btn);
}}

// ── Input helpers ──
function fillPrompt(text) {{
  const ta = currentMode === 'focused' ? document.getElementById('main-prompt') : document.getElementById('analyst-prompt');
  ta.value = text;
  ta.focus();
  hideWelcome();
}}

function handleKey(e) {{
  if (e.key === 'Enter' && !e.shiftKey) {{ e.preventDefault(); sendQuestion(); }}
}}
function handleAnalystKey(e) {{
  if (e.key === 'Enter' && !e.shiftKey) {{ e.preventDefault(); sendAnalystQuestion(); }}
}}

function hideWelcome() {{
  const w = document.getElementById('welcome-msg');
  if (w) w.style.display = 'none';
}}

// ── Send (focused) ──
async function sendQuestion() {{
  const ta = document.getElementById('main-prompt');
  const q = ta.value.trim();
  if (!q) return;
  ta.value = '';
  hideWelcome();
  await executeQuery(q, null, 'focused');
}}

async function sendAnalystQuestion() {{
  const ta = document.getElementById('analyst-prompt');
  const q = ta.value.trim();
  if (!q) return;
  ta.value = '';
  await executeQuery(q, null, 'analyst');
}}

async function runShortcut(name, desc) {{
  hideWelcome();
  const chatEl = currentMode === 'focused' ? 'chat-area' : 'analyst-chat-area';
  await executeQuery(desc, name, currentMode);
}}

// ── Core query executor ──
async function executeQuery(question, shortcut, mode) {{
  const chatArea = document.getElementById(mode === 'analyst' ? 'analyst-chat-area' : 'chat-area');
  const btnId = mode === 'analyst' ? 'analyst-send-btn' : 'send-btn';

  // Add user bubble
  appendUserBubble(chatArea, question);
  if (conversationCount === 0) addThread(question);
  conversationCount++;

  // ── Chart request on existing data: re-render locally, skip the model ──
  if (!shortcut) {{
    const chartType = detectChartRequest(question);
    if (chartType && lastResult && lastResult.rows && lastResult.rows.length) {{
      appendChartBubble(chatArea, lastResult, chartType, mode);
      chatArea.scrollTop = chatArea.scrollHeight;
      return;
    }}
    if (chartType && (!lastResult || !lastResult.rows || !lastResult.rows.length)) {{
      appendErrorBubble(chatArea, 'No results to chart yet — run a query first, then ask me to chart it.');
      chatArea.scrollTop = chatArea.scrollHeight;
      return;
    }}
  }}

  // Disable send button
  document.getElementById(btnId).disabled = true;

  // Show thinking indicator
  const thinkId = 'think-' + Date.now();
  chatArea.insertAdjacentHTML('beforeend', `
    <div class="thinking" id="${{thinkId}}">
      <div class="avatar">✦</div>
      <div class="bubble" style="padding:14px 18px">
        <div class="thinking-dots"><span></span><span></span><span></span></div>
      </div>
    </div>`);
  chatArea.scrollTop = chatArea.scrollHeight;

  try {{
    const resp = await fetch('/api/query', {{
      method: 'POST',
      headers: {{'Content-Type': 'application/json'}},
      body: JSON.stringify({{question, shortcut}}),
    }});
    const data = await resp.json();

    // Remove thinking indicator
    document.getElementById(thinkId)?.remove();

    if (data.error) {{
      appendErrorBubble(chatArea, data.error);
    }} else {{
      appendAssistantBubble(chatArea, data, mode);
      // In analyst mode, also update canvas
      if (mode === 'analyst') updateCanvas(data);
    }}
  }} catch(e) {{
    document.getElementById(thinkId)?.remove();
    appendErrorBubble(chatArea, 'Network error: ' + e.message);
  }} finally {{
    document.getElementById(btnId).disabled = false;
    chatArea.scrollTop = chatArea.scrollHeight;
  }}
}}

// ── Bubble builders ──
function appendUserBubble(chatArea, text) {{
  const div = document.createElement('div');
  div.className = 'message user';
  div.innerHTML = `<div class="bubble"><p>${{escHtml(text)}}</p></div>`;
  chatArea.appendChild(div);
}}

function appendErrorBubble(chatArea, msg) {{
  const div = document.createElement('div');
  div.className = 'message';
  div.innerHTML = `<div class="avatar">✦</div><div class="error-bubble">${{escHtml(msg)}}</div>`;
  chatArea.appendChild(div);
}}

function appendAssistantBubble(chatArea, data, mode) {{
  const hasData   = data.columns && data.rows && data.rows.length > 0;
  const hasSql    = !!data.sql;
  const hasChart  = !!data.chart;

  // Cache the latest tabular result so chart requests can re-render it
  // without going back to the model.
  if (hasData) {{
    lastResult = {{ columns: data.columns, rows: data.rows, question: data.question || '' }};
  }}
  const sqlId     = 'sql-' + Date.now();
  const tableId   = 'tbl-' + Date.now();
  const chartId   = 'ch-'  + Date.now();

  // Intent badge colour
  const intentMap = {{
    meta:      ['#4A90D9', 'Schema'],
    domain:    ['#7B68EE', 'Domain knowledge'],
    integrity: ['#2E9E83', 'Data integrity'],
    overview:  ['#C77D3A', 'Overview'],
    analytical:['var(--copper)', 'Live query'],
  }};
  const [intentColor, intentLabel] = intentMap[data.intent] || ['var(--copper)', 'Live query'];

  // Build result tabs if we have data
  let tabsHtml = '';
  if (hasData || hasSql) {{
    const tabs = [];
    const panels = [];
    if (hasData) {{
      tabs.push(`<button class="result-tab-btn active" data-tab="table-${{tableId}}" onclick="switchTab(this,'${{tableId}}')">Table (${{data.total_rows}} rows)</button>`);
      panels.push(`<div id="table-${{tableId}}" class="result-panel">${{buildTable(data.columns, data.rows, data.total_rows)}}</div>`);
    }}
    if (hasSql) {{
      tabs.push(`<button class="result-tab-btn" data-tab="sql-${{sqlId}}" onclick="switchTab(this,'${{sqlId}}')">SQL</button>`);
      panels.push(`<div id="sql-${{sqlId}}" class="result-panel" hidden><div class="sql-block open"><code>${{escHtml(data.sql)}}</code></div></div>`);
    }}
    if (hasData) {{
      tabs.push(`<button class="result-tab-btn" data-tab="src-${{tableId}}" onclick="switchTab(this,'${{tableId}}-src')">Sources</button>`);
      panels.push(`<div id="src-${{tableId}}-src" class="result-panel" hidden><div style="color:var(--muted);font-size:12px;padding:8px 0">
        <div class="security-item" style="margin-bottom:6px">🗄 ${{escHtml(activeTable)}}</div>
        <div class="security-item">🔒 Read-only Databricks query</div>
        <div class="security-item">🤖 SQL generated by ${{escHtml('local ' + (window._model||'Ollama'))}}</div>
      </div></div>`);
    }}
    tabsHtml = `<div class="result-tabs-row">${{tabs.join('')}}</div>${{panels.join('')}}`;
  }}

  // Chart section (focused mode inline, analyst mode goes to canvas)
  let chartHtml = '';
  if (hasChart && mode === 'focused') {{
    chartHtml = `<div class="chart-wrap" id="${{chartId}}"></div>`;
  }}

  const div = document.createElement('div');
  div.className = 'message';
  div.innerHTML = `
    <div class="avatar">✦</div>
    <div class="bubble">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
        <span style="font-size:11px;padding:2px 8px;border-radius:10px;background:color-mix(in srgb,${{intentColor}} 20%,transparent);color:${{intentColor}}">${{intentLabel}}</span>
        <span style="font-size:11px;color:var(--muted)">${{data.timestamp}}</span>
      </div>
      <div class="answer-lead">${{markdownToHtml(data.answer)}}</div>
      ${{chartHtml}}
      ${{tabsHtml}}
    </div>`;
  chatArea.appendChild(div);

  // Render Plotly chart if in focused mode
  if (hasChart && mode === 'focused') {{
    const chartEl = document.getElementById(chartId);
    if (chartEl) renderChart(chartEl, data.chart);
  }}
}}

function appendChartBubble(chatArea, result, type, mode) {{
  const chartId = 'rech-' + Date.now();
  const label = type.charAt(0).toUpperCase() + type.slice(1);
  const div = document.createElement('div');
  div.className = 'message';
  div.innerHTML = `
    <div class="avatar">✦</div>
    <div class="bubble">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
        <span style="font-size:11px;padding:2px 8px;border-radius:10px;background:color-mix(in srgb,var(--copper) 20%,transparent);color:var(--copper)">${{label}} chart</span>
      </div>
      <div class="answer-lead">Here's the previous result as a ${{label.toLowerCase()}} chart.</div>
      <div class="chart-wrap" id="${{chartId}}"></div>
    </div>`;
  chatArea.appendChild(div);
  const spec = buildChartSpecJS(result.columns, result.rows, type);
  const el = document.getElementById(chartId);
  if (el) renderChart(el, spec);
  // In analyst mode, also drop it on the canvas
  if (mode === 'analyst') {{
    const body = document.getElementById('canvas-body');
    if (body) {{
      const wrap = document.createElement('div');
      wrap.className = 'canvas-chart-panel';
      wrap.id = 'canvas-rech-' + Date.now();
      body.insertBefore(wrap, body.firstChild);
      renderChart(wrap, spec);
    }}
  }}
}}

function buildTable(columns, rows, totalRows) {{
  const thead = '<tr>' + columns.map(c => `<th>${{escHtml(c)}}</th>`).join('') + '</tr>';
  const tbody = rows.slice(0,100).map(row =>
    '<tr>' + row.map(v => `<td>${{escHtml(String(v ?? ''))}}</td>`).join('') + '</tr>'
  ).join('');
  const note = totalRows > 100 ? `<div class="row-count">Showing 100 of ${{totalRows}} rows</div>` : '';
  return `<div style="overflow-x:auto"><table class="mini-table"><thead>${{thead}}</thead><tbody>${{tbody}}</tbody></table></div>${{note}}`;
}}

// ── Analyst canvas ──
function updateCanvas(data) {{
  const title   = document.getElementById('canvas-title');
  const sub     = document.getElementById('canvas-sub');
  const body    = document.getElementById('canvas-body');

  title.textContent = data.question.length > 60 ? data.question.slice(0,58)+'…' : data.question;
  sub.textContent   = data.timestamp + ' · ' + (data.total_rows || 0) + ' rows';
  body.innerHTML    = '';

  // Chart
  if (data.chart) {{
    const chartWrap = document.createElement('div');
    chartWrap.className = 'canvas-chart-panel';
    chartWrap.id = 'canvas-chart-' + Date.now();
    body.appendChild(chartWrap);
    renderChart(chartWrap, data.chart);
  }}

  // Result panel with tabs
  if (data.columns && data.rows) {{
    const panel = document.createElement('div');
    panel.className = 'canvas-result-panel';
    const tabId = 'ct-' + Date.now();
    panel.innerHTML = `
      <div class="canvas-result-head">
        <button class="result-tab-btn active" onclick="switchTab(this,'${{tabId}}-table')">Table (${{data.total_rows}} rows)</button>
        ${{data.sql ? `<button class="result-tab-btn" onclick="switchTab(this,'${{tabId}}-sql')">SQL</button>` : ''}}
      </div>
      <div id="${{tabId}}-table" class="result-panel" style="padding:12px">${{buildTable(data.columns, data.rows, data.total_rows)}}</div>
      ${{data.sql ? `<div id="${{tabId}}-sql" class="result-panel" hidden style="padding:12px"><div class="sql-block open"><code>${{escHtml(data.sql)}}</code></div></div>` : ''}}
    `;
    body.appendChild(panel);
  }}
}}

// ── Tab switcher ──
function switchTab(btn, panelId) {{
  const container = btn.closest('.result-tabs-row, .canvas-result-head');
  if (!container) return;
  container.querySelectorAll('.result-tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  // Find sibling panels — look in the bubble or canvas panel
  const scope = btn.closest('.bubble') || btn.closest('.canvas-result-panel');
  if (!scope) return;
  scope.querySelectorAll('.result-panel').forEach(p => {{ p.hidden = (p.id !== panelId); }});
}}

// ── Chart rendering ──
function renderChart(el, chartSpec) {{
  if (!window.Plotly) return;
  try {{
    Plotly.react(el, chartSpec.data, chartSpec.layout, {{responsive:true, displayModeBar:false}});
  }} catch(e) {{ console.warn('Chart render error', e); }}
}}

// ── Utilities ──
function escHtml(str) {{
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}}

function markdownToHtml(text) {{
  if (!text) return '';
  return text
    .replace(/[*][*]([^*]+)[*][*]/g, '<strong>$1</strong>')
    .replace(/`([^`]+)`/g, '<code style="background:var(--panel2);padding:1px 5px;border-radius:4px">$1</code>')
    .replace(/\\n\\n/g, '</p><p>')
    .replace(/\\n•/g, '<br>•')
    .replace(/\\n/g, '<br>');
}}

// ── Boot ──
window._model = '';
init().then(() => {{
  // Store model name for source attribution
  fetch('/api/status').then(r=>r.json()).then(d=>{{ window._model = d.model||'Ollama'; }});
}});
</script>
</body>
</html>"""


# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    missing = [v for v in [DATABRICKS_HOST, DATABRICKS_HTTP_PATH, DATABRICKS_TOKEN] if not v]
    if missing:
        print("⚠  Missing Databricks credentials in .env")
        print("   Copy .env.template to .env and fill in your values.")

    print("🔍  Discovering tables in Databricks catalog…")
    threading.Thread(target=discover_tables, daemon=True).start()

    PORT = 5001

    print(f"✦  AvTrix Fleet Intelligence")
    print(f"   Model : {OLLAMA_MODEL}")
    print(f"   Table : {HISTORY_TABLE}")
    print(f"   URL   : http://127.0.0.1:{PORT}")
    print()

    threading.Timer(1.5, lambda: webbrowser.open(f"http://127.0.0.1:{PORT}")).start()
    app.run(host="0.0.0.0", port=PORT, debug=False, threaded=True)

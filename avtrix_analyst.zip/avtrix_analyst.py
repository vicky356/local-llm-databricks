"""
AvTrix Fleet Intelligence — Local Analytical Assistant
======================================================
Replaces Databricks Genie with a local Ollama LLM connected directly
to your Delta tables. No usage caps. Runs entirely on your laptop.

Usage:
    python avtrix_analyst.py              # interactive mode
    python avtrix_analyst.py --query "how many null jobtypes?"
    python avtrix_analyst.py --run jobtype_temporal
    python avtrix_analyst.py --list       # list named shortcuts

Startup:
    1. Make sure Ollama is running:  ollama serve  (or set to auto-start)
    2. Fill in .env with your Databricks credentials (one-time setup)
    3. python avtrix_analyst.py
"""

import os
import sys
import json
import csv
import argparse
import textwrap
from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv

# ── Load environment ─────────────────────────────────────────────────────────
load_dotenv(Path(__file__).parent / ".env")

DATABRICKS_HOST      = os.getenv("DATABRICKS_HOST", "")
DATABRICKS_HTTP_PATH = os.getenv("DATABRICKS_HTTP_PATH", "")
DATABRICKS_TOKEN     = os.getenv("DATABRICKS_TOKEN", "")
OLLAMA_MODEL         = os.getenv("OLLAMA_MODEL", "llama3")
HISTORY_TABLE        = os.getenv("HISTORY_TABLE", "poc.avtrix_fb.alg_history_report")

# ── Colour helpers ───────────────────────────────────────────────────────────
GREEN  = "\033[92m"
COPPER = "\033[93m"
BLUE   = "\033[94m"
RED    = "\033[91m"
DIM    = "\033[2m"
RESET  = "\033[0m"
BOLD   = "\033[1m"

def banner():
    print(f"""
{COPPER}{BOLD}╔══════════════════════════════════════════════════════════╗
║        AvTrix Fleet Intelligence — Local Analyst          ║
║        Engineering-Led Fleet Intelligence                  ║
╚══════════════════════════════════════════════════════════╝{RESET}
{DIM}Model: {OLLAMA_MODEL}  |  Table: {HISTORY_TABLE}
Type 'help' for commands, 'quit' to exit.{RESET}
""")

# ── Named query shortcuts ────────────────────────────────────────────────────
# Pre-built queries from the FB discovery analysis.
# Run with:  python avtrix_analyst.py --run <name>

NAMED_QUERIES = {

    "dataset_overview": {
        "description": "General overview — record counts, date range, aircraft, data quality (CLI: single table; web app: all tables with narrative)",
        "sql": """
            SELECT
                COUNT(*)                                                          AS total_records,
                COUNT(DISTINCT AC_REG)                                            AS unique_aircraft,
                COUNT(DISTINCT REMOVED_PARTNO)                                    AS unique_part_numbers,
                MIN(DATE(REMOVAL_C_W_MOS))                                        AS earliest_removal,
                MAX(DATE(REMOVAL_C_W_MOS))                                        AS latest_removal,
                COUNT(DISTINCT YEAR(REMOVAL_C_W_MOS))                             AS years_covered,
                SUM(CASE WHEN JOBTYPE = 'SCHEDULED'   THEN 1 ELSE 0 END)          AS scheduled_jobs,
                SUM(CASE WHEN JOBTYPE = 'UNSCHEDULED' THEN 1 ELSE 0 END)          AS unscheduled_jobs,
                SUM(CASE WHEN JOBTYPE IS NULL          THEN 1 ELSE 0 END)          AS null_jobtype,
                ROUND(SUM(CASE WHEN JOBTYPE IS NULL THEN 1 ELSE 0 END) * 100.0
                      / COUNT(*), 1)                                               AS pct_null_jobtype,
                SUM(CASE WHEN WORKORDER_NUMBER IS NULL
                          OR TRIM(WORKORDER_NUMBER) IN ('', '-', 'N/A')
                     THEN 1 ELSE 0 END)                                            AS missing_workorders,
                ROUND(SUM(CASE WHEN WORKORDER_NUMBER IS NULL
                               OR TRIM(WORKORDER_NUMBER) IN ('', '-', 'N/A')
                          THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1)               AS pct_missing_workorders,
                SUM(CASE WHEN REMOVED_SERIALNO IS NULL
                          OR TRIM(REMOVED_SERIALNO) IN ('', 'SN-UNKNOWN', 'NSN', 'NOT INSTALLED')
                     THEN 1 ELSE 0 END)                                            AS missing_removed_serial,
                ROUND(SUM(CASE WHEN REMOVED_SERIALNO IS NULL
                               OR TRIM(REMOVED_SERIALNO) IN ('', 'SN-UNKNOWN', 'NSN', 'NOT INSTALLED')
                          THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1)               AS pct_missing_removed_serial
            FROM {table}
        """
    },

    "jobtype_distribution": {
        "description": "Overall JOBTYPE distribution (SCHEDULED / UNSCHEDULED / NULL)",
        "sql": """
            SELECT
                COALESCE(JOBTYPE, 'NULL') AS job_type,
                COUNT(*) AS record_count,
                ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 1) AS pct_of_total
            FROM {table}
            GROUP BY COALESCE(JOBTYPE, 'NULL')
            ORDER BY record_count DESC
        """
    },

    "jobtype_temporal": {
        "description": "JOBTYPE distribution by year — surfaces the labelling decline trend",
        "sql": """
            SELECT
                YEAR(REMOVAL_C_W_MOS) AS year,
                COUNT(*) AS total_records,
                SUM(CASE WHEN JOBTYPE = 'SCHEDULED'   THEN 1 ELSE 0 END) AS scheduled,
                SUM(CASE WHEN JOBTYPE = 'UNSCHEDULED' THEN 1 ELSE 0 END) AS unscheduled,
                SUM(CASE WHEN JOBTYPE IS NULL          THEN 1 ELSE 0 END) AS null_jobtype,
                ROUND(SUM(CASE WHEN JOBTYPE = 'UNSCHEDULED' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) AS pct_unscheduled,
                ROUND(SUM(CASE WHEN JOBTYPE IS NULL    THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) AS pct_null
            FROM {table}
            WHERE YEAR(REMOVAL_C_W_MOS) IS NOT NULL
              AND YEAR(REMOVAL_C_W_MOS) BETWEEN 1995 AND 2025
            GROUP BY YEAR(REMOVAL_C_W_MOS)
            ORDER BY year
        """
    },

    "reason_by_jobtype": {
        "description": "REASON code distribution split by JOBTYPE — shows '-' dominance and label discrepancies",
        "sql": """
            SELECT
                COALESCE(REASON, 'NULL') AS reason,
                SUM(CASE WHEN JOBTYPE = 'SCHEDULED'   THEN 1 ELSE 0 END) AS scheduled_count,
                SUM(CASE WHEN JOBTYPE = 'UNSCHEDULED' THEN 1 ELSE 0 END) AS unscheduled_count,
                SUM(CASE WHEN JOBTYPE IS NULL          THEN 1 ELSE 0 END) AS null_jobtype_count,
                COUNT(*) AS total
            FROM {table}
            GROUP BY COALESCE(REASON, 'NULL')
            ORDER BY total DESC
            LIMIT 20
        """
    },

    "workorder_coverage": {
        "description": "WORKORDER_NUMBER population rate — the procurement join gap",
        "sql": """
            SELECT
                COUNT(*) AS total_records,
                SUM(CASE WHEN WORKORDER_NUMBER IS NOT NULL
                          AND TRIM(WORKORDER_NUMBER) NOT IN ('', '-', 'N/A')
                     THEN 1 ELSE 0 END) AS populated,
                SUM(CASE WHEN WORKORDER_NUMBER IS NULL
                          OR TRIM(WORKORDER_NUMBER) IN ('', '-', 'N/A')
                     THEN 1 ELSE 0 END) AS null_or_placeholder,
                ROUND(
                    SUM(CASE WHEN WORKORDER_NUMBER IS NULL
                              OR TRIM(WORKORDER_NUMBER) IN ('', '-', 'N/A')
                         THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2
                ) AS pct_absent
            FROM {table}
        """
    },

    "installed_side_capture": {
        "description": "INSTALLED_PARTNO and INSTALLED_SERIALNO null rates across three denominators",
        "sql": """
            WITH full_dataset AS (
                SELECT
                    'Full dataset' AS population,
                    COUNT(*) AS total,
                    SUM(CASE WHEN INSTALLED_PARTNO IS NULL
                              OR TRIM(INSTALLED_PARTNO) IN ('', 'PN') THEN 1 ELSE 0 END) AS partno_null,
                    ROUND(SUM(CASE WHEN INSTALLED_PARTNO IS NULL
                              OR TRIM(INSTALLED_PARTNO) IN ('', 'PN') THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) AS partno_null_pct,
                    SUM(CASE WHEN INSTALLED_SERIALNO IS NULL
                              OR TRIM(INSTALLED_SERIALNO) IN ('', 'SN-UNKNOWN', 'NSN', 'NOT INSTALLED')
                         THEN 1 ELSE 0 END) AS serialno_null,
                    ROUND(SUM(CASE WHEN INSTALLED_SERIALNO IS NULL
                              OR TRIM(INSTALLED_SERIALNO) IN ('', 'SN-UNKNOWN', 'NSN', 'NOT INSTALLED')
                         THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) AS serialno_null_pct
                FROM {table}
            ),
            removal_records AS (
                SELECT
                    'Removal-tagged records' AS population,
                    COUNT(*) AS total,
                    SUM(CASE WHEN INSTALLED_PARTNO IS NULL
                              OR TRIM(INSTALLED_PARTNO) IN ('', 'PN') THEN 1 ELSE 0 END) AS partno_null,
                    ROUND(SUM(CASE WHEN INSTALLED_PARTNO IS NULL
                              OR TRIM(INSTALLED_PARTNO) IN ('', 'PN') THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) AS partno_null_pct,
                    SUM(CASE WHEN INSTALLED_SERIALNO IS NULL
                              OR TRIM(INSTALLED_SERIALNO) IN ('', 'SN-UNKNOWN', 'NSN', 'NOT INSTALLED')
                         THEN 1 ELSE 0 END) AS serialno_null,
                    ROUND(SUM(CASE WHEN INSTALLED_SERIALNO IS NULL
                              OR TRIM(INSTALLED_SERIALNO) IN ('', 'SN-UNKNOWN', 'NSN', 'NOT INSTALLED')
                         THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) AS serialno_null_pct
                FROM {table}
                WHERE REMOVED_PARTNO IS NOT NULL
                  AND TRIM(REMOVED_PARTNO) NOT IN ('', 'PN', '-')
            )
            SELECT population, total, partno_null, partno_null_pct, serialno_null, serialno_null_pct
            FROM full_dataset
            UNION ALL
            SELECT population, total, partno_null, partno_null_pct, serialno_null, serialno_null_pct
            FROM removal_records
            ORDER BY total DESC
        """
    },

    "utilisation_by_year": {
        "description": "Annual flight hours and legs from the maintenance record",
        "sql": """
            SELECT
                YEAR(REMOVAL_C_W_MOS) AS year,
                COUNT(*) AS total_records,
                ROUND(MAX(CAST(REMOVAL_C_W_HRS AS DOUBLE)) - MIN(CAST(REMOVAL_C_W_HRS AS DOUBLE)), 1) AS approx_hours_flown,
                COUNT(DISTINCT DATE(REMOVAL_C_W_MOS)) AS active_days
            FROM {table}
            WHERE YEAR(REMOVAL_C_W_MOS) IS NOT NULL
              AND YEAR(REMOVAL_C_W_MOS) BETWEEN 2000 AND 2025
              AND REMOVAL_C_W_HRS IS NOT NULL
              AND TRIM(REMOVAL_C_W_HRS) NOT IN ('', '0', '-')
            GROUP BY YEAR(REMOVAL_C_W_MOS)
            ORDER BY year
        """
    },

    "missing_dates_by_aircraft": {
        "description": "Missing installation/removal dates distribution — which aircraft/tail drives the gap",
        "sql": """
            SELECT
                COALESCE(AC_REG, 'UNKNOWN') AS aircraft_reg,
                COUNT(*) AS total_records,
                SUM(CASE WHEN REMOVAL_C_W_MOS IS NULL  THEN 1 ELSE 0 END) AS missing_removal_date,
                SUM(CASE WHEN INSTALLED_C_W_MOS IS NULL THEN 1 ELSE 0 END) AS missing_install_date,
                ROUND(SUM(CASE WHEN REMOVAL_C_W_MOS IS NULL THEN 1 ELSE 0 END)  * 100.0 / COUNT(*), 1) AS pct_missing_removal,
                ROUND(SUM(CASE WHEN INSTALLED_C_W_MOS IS NULL THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) AS pct_missing_install
            FROM {table}
            GROUP BY COALESCE(AC_REG, 'UNKNOWN')
            ORDER BY total_records DESC
        """
    },

    "time_expired_split": {
        "description": "TIME EXPIRED reason — split across SCHEDULED vs UNSCHEDULED with component breakdown",
        "sql": """
            SELECT
                COALESCE(JOBTYPE, 'NULL') AS job_type,
                REMOVED_PARTNO AS part_number,
                COUNT(*) AS count,
                ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (PARTITION BY COALESCE(JOBTYPE, 'NULL')), 1) AS pct_within_jobtype
            FROM {table}
            WHERE REASON = 'TIME EXPIRED'
            GROUP BY COALESCE(JOBTYPE, 'NULL'), REMOVED_PARTNO
            ORDER BY job_type, count DESC
        """
    },

    "true_reliability_population": {
        "description": "True Reliability population — count of defensible reliability events after all filters",
        "sql": """
            SELECT
                COUNT(*) AS true_reliability_count,
                COUNT(DISTINCT REMOVED_PARTNO) AS distinct_components,
                SUM(CASE WHEN REMOVAL_C_W_HRS IS NOT NULL AND CAST(REMOVAL_C_W_HRS AS DOUBLE) > 0
                          AND INSTALLED_C_W_HRS IS NOT NULL AND CAST(INSTALLED_C_W_HRS AS DOUBLE) > 0
                     THEN 1 ELSE 0 END) AS mtbur_computable_direct,
                SUM(CASE WHEN (REMOVAL_C_W_HRS IS NULL OR TRIM(REMOVAL_C_W_HRS) = '0')
                          OR (INSTALLED_C_W_HRS IS NULL OR TRIM(INSTALLED_C_W_HRS) = '0')
                     THEN 1 ELSE 0 END) AS requires_inference
            FROM {table}
            WHERE
                -- Reliability reason codes only
                (
                    JOBTYPE = 'UNSCHEDULED'
                    OR (JOBTYPE = 'SCHEDULED' AND REASON IN ('FAILURE','WORN','DAMAGED','TIRE CHANGE','ENGINE CHANGE','LOANER','UNKNOWN'))
                )
                -- No inspection tasks
                AND UPPER(DESCRIPTION) NOT LIKE '%CAPACITY CHECK%'
                AND UPPER(DESCRIPTION) NOT LIKE '%BENCH TEST%'
                AND UPPER(DESCRIPTION) NOT LIKE '%FUNCTIONAL%'
                AND UPPER(DESCRIPTION) NOT LIKE '%INSPECT%'
                AND UPPER(DESCRIPTION) NOT LIKE '%HYDROSTATIC%'
                -- Real part numbers only
                AND REMOVED_PARTNO IS NOT NULL
                AND TRIM(REMOVED_PARTNO) NOT IN ('', 'PN', '-')
                -- No same-serial reinstalls
                AND NOT (REMOVED_SERIALNO = INSTALLED_SERIALNO
                         AND REMOVED_SERIALNO IS NOT NULL
                         AND TRIM(REMOVED_SERIALNO) NOT IN ('', 'SN-UNKNOWN'))
        """
    },

    "component_mtbur": {
        "description": "Component-level MTBUR for parts with n >= 5 events",
        "sql": """
            WITH reliability_events AS (
                SELECT
                    REMOVED_PARTNO AS part_number,
                    CAST(REMOVAL_C_W_HRS AS DOUBLE) - CAST(INSTALLED_C_W_HRS AS DOUBLE) AS interval_hours
                FROM {table}
                WHERE
                    (
                        JOBTYPE = 'UNSCHEDULED'
                        OR (JOBTYPE = 'SCHEDULED' AND REASON IN ('FAILURE','WORN','DAMAGED','TIRE CHANGE','ENGINE CHANGE','LOANER','UNKNOWN'))
                    )
                    AND UPPER(DESCRIPTION) NOT LIKE '%CAPACITY CHECK%'
                    AND UPPER(DESCRIPTION) NOT LIKE '%BENCH TEST%'
                    AND UPPER(DESCRIPTION) NOT LIKE '%FUNCTIONAL%'
                    AND UPPER(DESCRIPTION) NOT LIKE '%INSPECT%'
                    AND UPPER(DESCRIPTION) NOT LIKE '%HYDROSTATIC%'
                    AND REMOVED_PARTNO IS NOT NULL
                    AND TRIM(REMOVED_PARTNO) NOT IN ('', 'PN', '-')
                    AND REMOVAL_C_W_HRS IS NOT NULL AND CAST(REMOVAL_C_W_HRS AS DOUBLE) > 0
                    AND INSTALLED_C_W_HRS IS NOT NULL AND CAST(INSTALLED_C_W_HRS AS DOUBLE) > 0
                    AND CAST(REMOVAL_C_W_HRS AS DOUBLE) > CAST(INSTALLED_C_W_HRS AS DOUBLE)
                    AND NOT (REMOVED_SERIALNO = INSTALLED_SERIALNO
                             AND REMOVED_SERIALNO IS NOT NULL
                             AND TRIM(REMOVED_SERIALNO) NOT IN ('', 'SN-UNKNOWN'))
            )
            SELECT
                part_number,
                COUNT(*) AS n_events,
                ROUND(AVG(interval_hours), 1)    AS mtbur_mean,
                ROUND(PERCENTILE(interval_hours, 0.5), 1) AS mtbur_median,
                ROUND(MIN(interval_hours), 1)    AS mtbur_min,
                ROUND(MAX(interval_hours), 1)    AS mtbur_max
            FROM reliability_events
            GROUP BY part_number
            HAVING COUNT(*) >= 5
            ORDER BY mtbur_mean ASC
        """
    },

}

# ── Schema context fed to Ollama ─────────────────────────────────────────────
#
# This is split into two parts so it stays correct across DIFFERENT tables:
#   • UNIVERSAL_GUARDRAILS — portable methodology that is true for ANY aviation
#     maintenance dataset. Safe to apply to any table.
#   • FB_HISTORY_SCHEMA    — schema + analytical notes SPECIFIC to the FB CAMP
#     history table. Only valid for that table's column layout.
#
# build_schema_context(table, columns) assembles the right context: if live
# columns are supplied (from a DESCRIBE of the active table) it builds a generic
# per-table note from them; otherwise it falls back to the FB history schema.

# Tokens that mean "empty" across AvTrix datasets. Trimmed + upper-cased before
# comparison. NOTE: 'UNKNOWN' is deliberately NOT here — it is a meaningful REASON
# value in the history table and is reported as its own category, not as missing.
PLACEHOLDER_TOKENS = [
    "", "-", "--", "---", "N/A", "NA", "NULL", "NONE", "NIL", "?",
    "PN", "SN-UNKNOWN", "NSN", "NOT INSTALLED",
]

UNIVERSAL_GUARDRAILS = """
UNIVERSAL METHODOLOGY GUARDRAILS (apply to ANY table — these are dataset-independent):
- PLACEHOLDERS: treat these as empty/NULL, not as real values —
  '', '-', '--', 'N/A', 'NA', 'NULL', 'NONE', 'PN', 'SN-UNKNOWN', 'NSN', 'NOT INSTALLED'.
  ('UNKNOWN' is a real category, not a placeholder — count it separately.)
- STRING-TYPED NUMBERS: many columns are stored as STRING even when numeric. Always
  CAST(field AS DOUBLE) before arithmetic, and TRY_CAST(field AS DATE) before DATE/YEAR.
  Some hour fields use "H:MM" time format and some use decimals — do not assume one.
- SAMPLE SIZE: always return COUNT(*) alongside any rate or average so sample size is visible.
  Small-fleet results are directional, not statistically significant.
- CTE RULES (violations cause UNRESOLVED_COLUMN errors):
  * An aggregate/GROUP BY CTE loses all non-aggregated columns. Never reference a column
    from such a CTE unless it is explicitly in that CTE's SELECT list.
  * NEVER write "FROM base_table JOIN aggregate_cte" and then reference base columns.
  * Prefer ONE flat SELECT with all aggregates. Example:
      SELECT COUNT(*) AS total, COUNT(DISTINCT AC_REG) AS aircraft FROM {table}
  * To combine aggregates with row-level data use a subquery or window function, never a
    cross-join to an aggregate CTE.
- OUTPUT: Databricks/Spark SQL only. No markdown fences, no commentary. Directly executable.
""".strip()

FB_HISTORY_SCHEMA = """
TABLE: {table}  (FB CAMP maintenance history — column layout specific to this table)

KEY FIELDS:
- JOBTYPE: 'SCHEDULED', 'UNSCHEDULED', or NULL (~20-27% null — a known data integrity issue)
- REASON: reason code. Common values: '-', 'FAILURE', 'WORN', 'DAMAGED', 'TIME EXPIRED',
  'UNKNOWN', 'SERVICE', 'TIRE CHANGE', 'LOANER', 'MOD/UPGRADE', 'ENGINE CHANGE', NULL
- DESCRIPTION: free-text task description
- REMOVED_PARTNO / INSTALLED_PARTNO: part numbers ('PN', '' are placeholders = null)
- REMOVED_SERIALNO / INSTALLED_SERIALNO: serials ('SN-UNKNOWN','NSN','NOT INSTALLED' = null)
- REMOVAL_C_W_HRS / INSTALLED_C_W_HRS: aircraft hours (STRING — CAST before arithmetic)
- REMOVAL_C_W_AFL / INSTALLED_C_W_AFL: aircraft cycles
- REMOVAL_C_W_MOS / INSTALLED_C_W_MOS: dates (may be STRING — TRY_CAST AS DATE)
- REMOVAL_C_W_ENC / INSTALLED_C_W_ENC: engine cycles (engine tasks only)
- WORKORDER_NUMBER, PRICE, LABOR_HRS, UPDATE_NOTE: largely unpopulated
- AC_REG: aircraft registration

RELIABILITY METHODOLOGY (valid when the table HAS a REASON/JOBTYPE column like this one):
- TRUE RELIABILITY FILTER: a defensible reliability event requires a reliability REASON code
  (FAILURE, WORN, DAMAGED, TIRE CHANGE, ENGINE CHANGE, LOANER, UNKNOWN). Do not treat every
  removal as reliability, and do not trust JOBTYPE alone — it is mislabelled; filter on REASON.
- MTBUR = CAST(REMOVAL_C_W_HRS AS DOUBLE) - CAST(INSTALLED_C_W_HRS AS DOUBLE); exclude <= 0.
- SAME-SERIAL EXCLUSION: exclude REMOVED_SERIALNO = INSTALLED_SERIALNO from reliability/MTBUR.
- PART CONSOLIDATION: group by REMOVED_PARTNO; multiple P/Ns may map to one functional component.
- INSPECTION tasks: DESCRIPTION contains CAPACITY CHECK, BENCH TEST, FUNCTIONAL, INSPECT,
  HYDROSTATIC TEST (these are not removals).
""".strip()


def build_schema_context(table=None, columns=None):
    """Assemble the LLM schema context for a given table.

    - columns given (list of names from a live DESCRIBE): build a generic per-table
      note from the actual columns + universal guardrails. Portable to any table.
    - columns not given: fall back to the FB history schema + universal guardrails.
    """
    tbl = table or HISTORY_TABLE
    if columns:
        col_lines = "\n".join(f"- {c}" for c in columns)
        per_table = (
            f"TABLE: {tbl}  (columns discovered live from the table)\n\n"
            f"COLUMNS:\n{col_lines}\n\n"
            "You do not have type information — treat columns as STRING unless the name clearly "
            "implies a date (…DATE…/…_MOS) or a number (…HRS…/…HOURS…/…CYCLES…/…COUNT…/…CUM…). "
            "Apply CAST/TRY_CAST accordingly."
        )
    else:
        per_table = FB_HISTORY_SCHEMA.format(table=tbl)
    return (
        "You are an aviation maintenance data analyst writing Databricks SQL.\n\n"
        + per_table + "\n\n" + UNIVERSAL_GUARDRAILS.format(table=tbl)
    )


# Backwards-compatible default context (FB history table). nl_to_sql uses this
# unless a caller passes a dynamically-built context.
SCHEMA_CONTEXT = build_schema_context()


# ── Data integrity check (generalized, schema-agnostic) ──────────────────────

def _nullish_sql(col):
    """SQL boolean: is this column NULL or a placeholder token (trimmed, upper)?"""
    toks = ", ".join("'" + t.replace("'", "''") + "'" for t in PLACEHOLDER_TOKENS)
    c = f"`{col}`"
    return f"({c} IS NULL OR TRIM(UPPER(CAST({c} AS STRING))) IN ({toks}))"


def build_completeness_sql(table, columns):
    """One efficient query computing, per column: total rows, null/placeholder
    count, and distinct non-placeholder values. Works on ANY column set."""
    parts = ["COUNT(*) AS __total__"]
    for col in columns:
        safe = col.replace("`", "")
        nullish = _nullish_sql(safe)
        c = f"`{safe}`"
        parts.append(f"SUM(CASE WHEN {nullish} THEN 1 ELSE 0 END) AS `null__{safe}`")
        parts.append(f"COUNT(DISTINCT CASE WHEN {nullish} THEN NULL ELSE CAST({c} AS STRING) END) AS `uniq__{safe}`")
    select = ",\n       ".join(parts)
    return f"SELECT {select}\nFROM {table}"


def format_completeness_rows(columns, agg):
    """Turn the single aggregate row (dict) into the per-field integrity table.
    Returns (header_list, rows) where each row matches the user's format:
    Field | Unique Values | Populated | Total Rows | Null Count | % Null"""
    total = int(agg.get("__total__", 0) or 0)
    out = []
    for col in columns:
        safe = col.replace("`", "")
        nulls = int(agg.get(f"null__{safe}", 0) or 0)
        uniq = int(agg.get(f"uniq__{safe}", 0) or 0)
        populated = total - nulls
        pct = round(nulls * 100.0 / total, 2) if total else 0.0
        out.append({
            "Field Name": col,
            "Unique Values": uniq,
            "Populated Count": populated,
            "Total Rows": total,
            "Null Count": nulls,
            "% Null": pct,
        })
    header = ["Field Name", "Unique Values", "Populated Count", "Total Rows", "Null Count", "% Null"]
    return header, out


def _parse_describe_columns(describe_rows):
    """Extract column names from DESCRIBE TABLE output. Stops at the partition-
    info section (blank col_name or a '# ...' marker)."""
    cols = []
    for r in describe_rows:
        # r may be a dict (CLI) or a sequence; normalise to the first field
        if isinstance(r, dict):
            name = r.get("col_name") or r.get("name") or list(r.values())[0]
        else:
            name = r[0]
        if name is None:
            break
        name = str(name).strip()
        if name == "" or name.startswith("#"):
            break
        cols.append(name)
    return cols

# ── Databricks connection ────────────────────────────────────────────────────

def get_db_connection():
    """Create and return a Databricks SQL connection."""
    try:
        from databricks import sql
        conn = sql.connect(
            server_hostname=DATABRICKS_HOST,
            http_path=DATABRICKS_HTTP_PATH,
            access_token=DATABRICKS_TOKEN,
        )
        return conn
    except Exception as e:
        print(f"{RED}✗ Databricks connection failed: {e}{RESET}")
        print(f"{DIM}Check your .env file — DATABRICKS_HOST, DATABRICKS_HTTP_PATH, DATABRICKS_TOKEN{RESET}")
        return None


def _catalog_prefix(table_ref):
    """Return USE CATALOG statement if table_ref uses a three-part name."""
    parts = table_ref.strip().split(".")
    if len(parts) == 3:
        return f"USE CATALOG {parts[0]};\n"
    return ""


def run_sql(conn, sql_query, save_csv=False):
    """Execute SQL and return results as list of dicts."""
    try:
        cursor = conn.cursor()
        # Databricks requires USE CATALOG before cross-catalog references
        prefix = _catalog_prefix(HISTORY_TABLE)
        if prefix:
            cursor.execute(prefix.strip())
        cursor.execute(sql_query)
        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()
        results = [dict(zip(columns, row)) for row in rows]

        # Print results as a table
        if results:
            _print_table(columns, results)
            print(f"\n{DIM}{len(results)} row(s) returned{RESET}")

            if save_csv:
                fname = f"avtrix_result_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
                with open(fname, 'w', newline='') as f:
                    writer = csv.DictWriter(f, fieldnames=columns)
                    writer.writeheader()
                    writer.writerows(results)
                print(f"{GREEN}✓ Saved to {fname}{RESET}")
        else:
            print(f"{DIM}Query returned no results.{RESET}")

        return results

    except Exception as e:
        print(f"{RED}✗ Query error: {e}{RESET}")
        return None


def _print_table(columns, rows, max_col_width=22):
    """Print results as a formatted table."""
    widths = {c: min(max_col_width, max(len(str(c)), max(len(str(r.get(c, ''))) for r in rows)))
              for c in columns}
    header = "  ".join(str(c).ljust(widths[c]) for c in columns)
    divider = "  ".join("─" * widths[c] for c in columns)
    print(f"\n{COPPER}{header}{RESET}")
    print(f"{DIM}{divider}{RESET}")
    for row in rows:
        print("  ".join(str(row.get(c, '')).ljust(widths[c]) for c in columns))

# ── Ollama LLM layer ─────────────────────────────────────────────────────────

def check_ollama():
    """Check Ollama is running and the model is available."""
    try:
        import ollama
        models = [m.model for m in ollama.list().models]
        if not any(OLLAMA_MODEL in m for m in models):
            print(f"{COPPER}⚠ Model '{OLLAMA_MODEL}' not found locally. Pulling now...{RESET}")
            print(f"{DIM}This only happens once. Subsequent starts are instant.{RESET}")
            import subprocess
            subprocess.run(["ollama", "pull", OLLAMA_MODEL], check=True)
        return True
    except Exception as e:
        print(f"{RED}✗ Ollama not reachable: {e}{RESET}")
        print(f"{DIM}Run 'ollama serve' in a separate terminal, then retry.{RESET}")
        return False


def list_installed_models():
    """Return a list of locally installed Ollama model names (empty on failure)."""
    try:
        import ollama
        return [m.model for m in ollama.list().models]
    except Exception:
        return []


def set_model(name):
    """Switch the active Ollama model (module global). Returns (ok, message)."""
    global OLLAMA_MODEL
    name = (name or "").strip()
    if not name:
        return False, "No model name given."
    installed = list_installed_models()
    # allow prefix match (e.g. 'qwen2.5-coder' matches 'qwen2.5-coder:7b')
    exact = [m for m in installed if m == name]
    partial = [m for m in installed if name in m]
    if exact:
        OLLAMA_MODEL = exact[0]
    elif len(partial) == 1:
        OLLAMA_MODEL = partial[0]
    elif len(partial) > 1:
        return False, f"Ambiguous — matches {', '.join(partial)}. Be more specific."
    else:
        # not installed; set anyway (user may pull it) but warn
        OLLAMA_MODEL = name
        return True, (f"Set model to '{name}', but it is not installed locally. "
                      f"Pull it with: ollama pull {name}")
    return True, f"Model switched to '{OLLAMA_MODEL}'."


def nl_to_sql(question, conversation_history=None):
    """Convert a natural language question to SQL using Ollama."""
    try:
        import ollama

        # SCHEMA_CONTEXT is already built for HISTORY_TABLE; rebuild so a model
        # switch or table change is always reflected.
        system_prompt = build_schema_context(HISTORY_TABLE)
        messages = [{"role": "system", "content": system_prompt}]

        if conversation_history:
            messages.extend(conversation_history[-6:])  # last 3 exchanges for context

        messages.append({"role": "user", "content": f"Write a SQL query to: {question}"})

        response = ollama.chat(model=OLLAMA_MODEL, messages=messages)
        sql_raw = response['message']['content'].strip()

        # Strip any markdown fences the model adds despite instructions
        sql_clean = sql_raw
        for fence in ['```sql', '```SQL', '```']:
            sql_clean = sql_clean.replace(fence, '')
        sql_clean = sql_clean.strip().rstrip('`').strip()

        return sql_clean

    except Exception as e:
        print(f"{RED}✗ Ollama error: {e}{RESET}")
        return None


def interpret_results(question, results, conversation_history=None):
    """Ask Ollama to interpret query results in plain English."""
    try:
        import ollama

        if not results:
            return "Query returned no results."

        # Truncate large result sets for interpretation
        sample = results[:20]
        results_text = json.dumps(sample, indent=2, default=str)

        system_prompt = (
            "You are an aviation maintenance data analyst. "
            "Interpret the query results concisely and accurately. "
            "Focus on findings relevant to reliability, data integrity, or CAMO compliance. "
            "Be specific about numbers. Flag anomalies. Keep it under 150 words."
        )

        messages = [{"role": "system", "content": system_prompt}]
        if conversation_history:
            messages.extend(conversation_history[-4:])

        messages.append({
            "role": "user",
            "content": f"Question asked: {question}\n\nResults:\n{results_text}\n\nInterpret these results."
        })

        response = ollama.chat(model=OLLAMA_MODEL, messages=messages)
        return response['message']['content'].strip()

    except Exception:
        return None

# ── Intent-to-shortcut matching ──────────────────────────────────────────────

import re as _re

# Maps a named shortcut to the phrases that should trigger it without going
# through Ollama SQL generation. Patterns are checked case-insensitively.
_SHORTCUT_PATTERNS = {
    "dataset_overview": [
        r"\bgeneral\s+overview\b",
        r"\boverview\s+of\s+the\s+data\b",
        r"\bdata\s+overview\b",
        r"\bsummar(y|ise|ize)\s+the\s+data\b",
        r"\bwhat.{0,20}\bdata.{0,20}\blook\s+like\b",
        r"\bshow\s+me\s+(the\s+)?overview\b",
        r"\bhow\s+much\s+data\b",
        r"\bhow\s+many\s+records\b",
        r"\btotal\s+records?\b",
        r"\bdataset\s+summar(y|ize)\b",
    ],
    "jobtype_distribution": [
        r"\bjobtype\s+distribution\b",
        r"\bjob\s+type\s+(split|breakdown|distribution|mix)\b",
        r"\bscheduled\s+vs\s+unscheduled\b",
        r"\bhow\s+many\s+(are\s+)?(scheduled|unscheduled)\b",
    ],
    "null_jobtype_by_aircraft": [
        r"\bnull\s+jobtype\s+by\s+aircraft\b",
        r"\bmissing\s+jobtype\s+per\s+aircraft\b",
        r"\bwhich\s+aircraft.{0,30}\bnull\s+jobtype\b",
    ],
    "top_removed_parts": [
        r"\btop.{0,20}\bremoved\s+part\b",
        r"\bmost\s+frequent(ly)?\s+removed\b",
        r"\bhighest\s+removal\s+rate\b",
        r"\bmost\s+removed\s+part\b",
    ],
    "mtbur_by_part": [
        r"\bmtbur\b",
        r"\bmean\s+time\s+between\s+(unscheduled\s+)?removal\b",
    ],
}


def _match_shortcut_by_intent(question):
    """Return the name of a NAMED_QUERIES shortcut if the question matches one,
    otherwise return None to fall through to Ollama."""
    q = question.strip().lower()
    for shortcut_name, patterns in _SHORTCUT_PATTERNS.items():
        for pattern in patterns:
            if _re.search(pattern, q):
                return shortcut_name
    return None


# ── Intent classification (so the CLI isn't SQL-only) ────────────────────────

_META_PATTERNS = [
    r"\b(what|which|list|show)\b.{0,30}\b(table|tables|schema|catalog|dataset|column|columns|field|fields)\b",
    r"\bwhat (data|tables|columns|fields|can you|do you have)\b",
    r"\bdo you have access\b",
    r"\b(available|accessible)\b.{0,20}\b(table|data|schema|column)\b",
    r"\b(describe|list)\b.{0,15}\b(table|schema|data|column)\b",
    r"\bwhat.{0,15}(columns?|fields?)\b",
    r"\bschema\b",
]

_DOMAIN_PATTERNS = [
    r"\b(what is|what are|explain|define|tell me about|how does|why does|why is)\b",
    r"\bwhat does\b.{0,30}\bmean\b",
    r"\b(advice|recommend|should i|what should|interpret|best practice)\b",
    r"\b(meaning|definition)\s+of\b",
]

_CHART_PATTERNS = [
    r"\b(pie|bar|line|donut)\s*(chart|graph|plot)?\b",
    r"\b(chart|graph|plot|visuali[sz]e)\b.{0,20}\b(this|that|it|these|the (result|results|data))\b",
    r"\bpresent\b.{0,20}\b(chart|graph|pie|bar|percentages?)\b",
    r"\bshow\b.{0,20}\b(as|in)\b.{0,10}\b(chart|graph|pie|bar)\b",
    r"\bpercentages?\b",
]

_INTEGRITY_PATTERNS = [
    r"\bdata\s+(integrity|quality)\b",
    r"\bintegrity\s+check\b",
    r"\b(completeness|fill rate|null count|null rate)\b",
    r"\b(profile|audit)\b.{0,20}\b(table|data|dataset|fields?|columns?)\b",
    r"\bcheck\b.{0,25}\b(null|placeholder|missing|completeness|fields?|columns?|quality|integrity)\b",
    r"\bwere\s+null(s| values)?\b",
    r"\bplaceholders?\b.{0,20}\b(taken|considered|handled|checked)\b",
]


# Words that signal a data query — these beat the generic "what is/are" domain cue.
_ANALYTICAL_SIGNALS = _re.compile(
    r"\b(top|how many|count|number of|list|show me|average|avg|sum|total|totals|"
    r"distribution|per|by (aircraft|part|reason|jobtype|tail|year|month)|most|least|"
    r"highest|lowest|rate|trend|rank|ranking|removals?|removed|installed|null|missing|"
    r"group(ed)? by|breakdown)\b"
)


def classify_intent_cli(question):
    """Classify a CLI question: 'integrity' | 'chart' | 'meta' | 'domain' | 'analytical'."""
    q = question.strip().lower()
    for pat in _INTEGRITY_PATTERNS:
        if _re.search(pat, q):
            return "integrity"
    for pat in _CHART_PATTERNS:
        if _re.search(pat, q):
            return "chart"
    for pat in _META_PATTERNS:
        if _re.search(pat, q):
            return "meta"
    # A question with analytical signals is a data query even if it opens with
    # "what are…"/"what is…" — those cues only mean 'domain' without data signals.
    if _ANALYTICAL_SIGNALS.search(q):
        return "analytical"
    for pat in _DOMAIN_PATTERNS:
        if _re.search(pat, q):
            return "domain"
    return "analytical"


def answer_meta_cli(question):
    """Answer a schema/catalog question from metadata — no SQL, no Ollama."""
    q = question.lower()
    parts = HISTORY_TABLE.split(".")
    catalog = parts[0] if len(parts) == 3 else "(default)"
    schema  = parts[1] if len(parts) == 3 else "(default)"

    if any(w in q for w in ["column", "columns", "field", "fields", "describe", "schema"]):
        print(f"\n{COPPER}► Columns in {HISTORY_TABLE}{RESET}")
        print(f"{DIM}{SCHEMA_CONTEXT}{RESET}")
        return

    # table / catalog listing
    print(f"\n{COPPER}► Data access{RESET}")
    print(f"  Catalog : {catalog}")
    print(f"  Schema  : {schema}")
    print(f"  Table   : {HISTORY_TABLE}")
    print(f"{DIM}  (The terminal tool queries this one table. The web app discovers")
    print(f"   all tables in the schema automatically.){RESET}")


def answer_domain_cli(question, conversation_history=None):
    """Answer an aviation/reliability knowledge question via Ollama — no SQL."""
    try:
        import ollama
        system_prompt = (
            "You are an aviation reliability and maintenance analytics expert with deep "
            "knowledge of MRO, component reliability, MTBUR (Mean Time Between Unscheduled "
            "Removals), ATA chapters, LRU, Airworthiness Directives, CAMO and fleet management. "
            "Answer concisely and accurately. Do NOT write SQL. If the question needs specific "
            "numbers from the data, say so and suggest the user ask for those figures directly."
        )
        messages = [{"role": "system", "content": system_prompt}]
        if conversation_history:
            messages.extend(conversation_history[-4:])
        messages.append({"role": "user", "content": question})
        response = ollama.chat(model=OLLAMA_MODEL, messages=messages)
        print(f"\n{BLUE}► {response['message']['content'].strip()}{RESET}")
    except Exception as e:
        print(f"{RED}✗ Ollama error: {e}{RESET}")


def _detect_chart_type_cli(question):
    q = question.lower()
    if _re.search(r"\bpie\b|\bdonut\b|\bpercentages?\b", q):
        return "percent"
    if _re.search(r"\bbar\b", q):
        return "bar"
    return "percent"


def chart_last_results_cli(question, last_columns, last_results):
    """Print the previous result set as a text percentage/bar breakdown.
    Never regenerates SQL."""
    if not last_results or not last_columns:
        print(f"{RED}No results to chart yet — run a query first, then ask me to chart it.{RESET}")
        return

    # pick first text column as labels, first numeric column as values
    label_col = None
    value_col = None
    first = last_results[0]
    for c in last_columns:
        v = first.get(c)
        if label_col is None and isinstance(v, str):
            label_col = c
        if value_col is None and isinstance(v, (int, float)) and not isinstance(v, bool):
            value_col = c
    if label_col is None:
        label_col = last_columns[0]
    if value_col is None:
        value_col = last_columns[-1]

    pairs = []
    for row in last_results:
        label = str(row.get(label_col, ''))
        try:
            val = float(row.get(value_col) or 0)
        except (TypeError, ValueError):
            val = 0.0
        pairs.append((label, val))

    total = sum(v for _, v in pairs) or 1.0
    pairs.sort(key=lambda x: x[1], reverse=True)

    print(f"\n{COPPER}► {value_col} by {label_col} (share of total){RESET}")
    maxlabel = max((len(l) for l, _ in pairs), default=10)
    for label, val in pairs:
        pct = val / total * 100
        bar = "█" * int(round(pct / 2))  # 50 chars = 100%
        print(f"  {label.ljust(maxlabel)}  {str(int(val)).rjust(8)}  {pct:5.1f}%  {COPPER}{bar}{RESET}")
    print(f"{DIM}  Total {value_col}: {int(total)}{RESET}")


def print_guardrails():
    """Show which methodology the assistant applies, and how it's split."""
    print(f"""
{COPPER}► Analytical guardrails{RESET}

{BOLD}How they're invoked:{RESET} automatically. Every SQL question the model answers is
given these rules in its system prompt. You don't call them — they're always on.
You can view them any time with {GREEN}guardrails{RESET}.

{BOLD}Two layers (so they stay correct across different tables):{RESET}

{COPPER}1. Universal methodology — applies to ANY table/aircraft:{RESET}
{DIM}{UNIVERSAL_GUARDRAILS}{RESET}

{COPPER}2. Per-table methodology — only valid for a table with these columns:{RESET}
   Active table: {HISTORY_TABLE}
   The reliability-specific rules (True Reliability filter, MTBUR, same-serial
   exclusion) ONLY apply when the table has REASON / removal-hours columns like the
   FB CAMP history table. On a different table (e.g. a utilisation table with
   Cum_Hours / ENG1-4 columns) those rules are NOT applied — the model is given
   that table's actual columns instead.
""")


def print_capabilities():
    """List what the assistant can do, so the user understands each function."""
    models = list_installed_models()
    model_line = ", ".join(models) if models else "(none detected — is Ollama running?)"
    print(f"""
{COPPER}► What I can do{RESET}

{BOLD}Ask in plain English — I route automatically:{RESET}
  {GREEN}Analytics{RESET}   Generate & run Databricks SQL
                "which aircraft have the most unscheduled removals?"
  {GREEN}Integrity{RESET}   Schema-agnostic data integrity check (any table)
                "run a data integrity check"   ·   command: {GREEN}check{RESET}
  {GREEN}Schema{RESET}      Columns / tables, answered from metadata (no SQL)
                "what columns do you have?"
  {GREEN}Knowledge{RESET}   Aviation / reliability expertise (no SQL)
                "what is MTBUR and why does it matter?"
  {GREEN}Charts{RESET}      Re-render the LAST result as a text breakdown
                "show that as percentages"

{BOLD}Commands:{RESET}
  {GREEN}check{RESET}        Data integrity check on the active table
  {GREEN}guardrails{RESET}   Show the methodology the model applies
  {GREEN}models{RESET}       List installed models   ·   {GREEN}model <name>{RESET} to switch
  {GREEN}list{RESET}         Named query shortcuts
  {GREEN}run <name>{RESET}   Run a named shortcut   ·   {GREEN}sql <query>{RESET} raw SQL
  {GREEN}save{RESET}         Save next result to CSV   ·   {GREEN}clear{RESET} / {GREEN}quit{RESET}

{BOLD}Active configuration:{RESET}
  Table : {HISTORY_TABLE}
  Model : {OLLAMA_MODEL}
  Installed models: {model_line}
""")


def print_models():
    """List installed Ollama models and the active one."""
    models = list_installed_models()
    print(f"\n{COPPER}► Ollama models{RESET}")
    if not models:
        print(f"{RED}  No models detected — is Ollama running? (ollama serve){RESET}")
        return
    for m in models:
        marker = f"{GREEN}● active{RESET}" if m == OLLAMA_MODEL else f"{DIM}  ○{RESET}"
        print(f"  {marker}  {m}")
    print(f"\n{DIM}  Switch with:  model <name>   (e.g. model qwen2.5-coder:7b){RESET}")
    print(f"{DIM}  For SQL, a coder model is strongly recommended over a general model.{RESET}")


def data_integrity_check(conn, table=None, save_csv=False):
    """Generalized, schema-agnostic data integrity check (Completeness).

    Introspects the table's columns, then reports per-field: unique values,
    populated count, total rows, null/placeholder count, % null. Placeholder
    tokens ('-', '--', 'PN', 'SN-UNKNOWN', etc.) count as missing, matching
    how AvTrix assesses every dataset."""
    table = table or HISTORY_TABLE
    print(f"\n{COPPER}► Data integrity check — {table}{RESET}")
    print(f"{DIM}Discovering columns…{RESET}")

    # 1. introspect columns
    desc = run_sql(conn, f"DESCRIBE TABLE {table}", save_csv=False)
    if not desc:
        print(f"{RED}✗ Could not describe {table}. Check the table name and connection.{RESET}")
        return None
    columns = _parse_describe_columns(desc)
    if not columns:
        print(f"{RED}✗ No columns found for {table}.{RESET}")
        return None

    # 2. run the completeness profile (single query)
    print(f"{DIM}Profiling {len(columns)} columns…{RESET}")
    sql = build_completeness_sql(table, columns)
    rows = run_sql(conn, sql, save_csv=False)
    if not rows:
        print(f"{RED}✗ Profile query returned nothing.{RESET}")
        return None

    header, report = format_completeness_rows(columns, rows[0])

    # 3. print as a markdown-style table
    print()
    widths = {h: max(len(h), max((len(str(r[h])) for r in report), default=0)) for h in header}
    print("  " + " | ".join(h.ljust(widths[h]) for h in header))
    print("  " + "-|-".join("-" * widths[h] for h in header))
    for r in report:
        # colour-code rows that are heavily null
        pct = r["% Null"]
        colour = RED if pct >= 50 else (COPPER if pct >= 20 else RESET)
        line = " | ".join(str(r[h]).ljust(widths[h]) for h in header)
        print(f"  {colour}{line}{RESET}")

    # 4. quick scorecard
    total = report[0]["Total Rows"] if report else 0
    empty_cols = [r["Field Name"] for r in report if r["% Null"] >= 100]
    high_null  = [r["Field Name"] for r in report if 50 <= r["% Null"] < 100]
    clean      = [r for r in report if r["% Null"] == 0]
    print(f"\n{COPPER}  Scorecard{RESET}")
    print(f"    Rows: {total:,}   Columns: {len(report)}")
    print(f"    Fully populated (0% null): {len(clean)}")
    print(f"    High null (>=50%): {len(high_null)}" + (f" — {', '.join(high_null)}" if high_null else ""))
    print(f"    Completely empty (100% null): {len(empty_cols)}" + (f" — {', '.join(empty_cols)}" if empty_cols else ""))

    if save_csv:
        fname = f"integrity_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        with open(fname, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=header)
            w.writeheader()
            w.writerows(report)
        print(f"{GREEN}  ✓ Saved to {fname}{RESET}")

    return report


# ── CLI and interactive loop ─────────────────────────────────────────────────

def run_named_query(conn, name, save_csv=False):
    """Run a pre-built named query shortcut."""
    if name not in NAMED_QUERIES:
        print(f"{RED}Unknown query: '{name}'. Run with --list to see available shortcuts.{RESET}")
        return

    q = NAMED_QUERIES[name]
    print(f"\n{COPPER}► {q['description']}{RESET}")
    sql = q['sql'].format(table=HISTORY_TABLE).strip()
    print(f"{DIM}{sql}{RESET}\n")
    return run_sql(conn, sql, save_csv=save_csv)


def list_shortcuts():
    """Print all named query shortcuts."""
    print(f"\n{COPPER}{BOLD}Named query shortcuts:{RESET}\n")
    for name, q in NAMED_QUERIES.items():
        print(f"  {GREEN}{name:<30}{RESET} {q['description']}")
    print(f"\n{DIM}Run with: python avtrix_analyst.py --run <name>{RESET}\n")


def interactive_loop(conn):
    """Main conversational loop."""
    conversation_history = []
    ollama_available = check_ollama()

    print(f"{DIM}Commands: 'run <name>', 'list', 'sql <query>', 'save', 'clear', 'quit'{RESET}\n")

    save_next = False
    last_results = None   # most recent result set (list of dicts)
    last_columns = None   # its column order

    def _remember(results):
        nonlocal last_results, last_columns
        if results:
            last_results = results
            last_columns = list(results[0].keys())

    while True:
        try:
            user_input = input(f"{COPPER}AvTrix >{RESET} ").strip()
        except (KeyboardInterrupt, EOFError):
            print(f"\n{DIM}Session ended.{RESET}")
            break

        if not user_input:
            continue

        cmd = user_input.lower()

        # ── Built-in commands ─────────────────────────────────────────────
        if cmd in ('quit', 'exit', 'q'):
            print(f"{DIM}Session ended.{RESET}")
            break

        elif cmd == 'help':
            print(f"""
{COPPER}Commands:{RESET}
  {GREEN}check{RESET}              Data integrity check on the active table
  {GREEN}guardrails{RESET}         Show the methodology the model applies
  {GREEN}capabilities{RESET}       Full breakdown of what I can do
  {GREEN}models{RESET}             List installed models  ·  {GREEN}model <name>{RESET} to switch
  {GREEN}run <name>{RESET}         Run a named query shortcut (e.g. run jobtype_temporal)
  {GREEN}list{RESET}               List all named query shortcuts
  {GREEN}sql <query>{RESET}        Execute raw SQL directly
  {GREEN}save{RESET}               Save the next query result to CSV
  {GREEN}clear{RESET}              Clear conversation history
  {GREEN}quit{RESET}               Exit

{COPPER}Natural language — the assistant routes your question automatically:{RESET}
  {GREEN}Analytics{RESET}  → generates and runs SQL
     "what are the top 10 most frequently removed part numbers?"
  {GREEN}Schema{RESET}     → answers from metadata, no SQL
     "what columns do you have?"  ·  "what tables can you access?"
  {GREEN}Knowledge{RESET}  → aviation/reliability expertise, no SQL
     "what is MTBUR and why does it matter?"
  {GREEN}Charts{RESET}     → re-renders the LAST result as a text breakdown
     "show that as percentages"  ·  "present it as a bar chart"
""")

        elif cmd == 'list':
            list_shortcuts()

        elif cmd in ('check', 'integrity', 'profile'):
            _remember(data_integrity_check(conn, HISTORY_TABLE, save_csv=save_next))
            save_next = False

        elif cmd in ('guardrails', 'methodology'):
            print_guardrails()

        elif cmd in ('capabilities', 'what can you do', 'options'):
            print_capabilities()

        elif cmd in ('models', 'model'):
            print_models()

        elif cmd.startswith('model '):
            ok, msg = set_model(user_input[6:].strip())
            print(f"{(GREEN if ok else RED)}{msg}{RESET}")

        elif cmd == 'save':
            save_next = True
            print(f"{DIM}Next query result will be saved to CSV.{RESET}")

        elif cmd == 'clear':
            conversation_history = []
            print(f"{DIM}Conversation history cleared.{RESET}")

        elif cmd.startswith('run '):
            name = user_input[4:].strip()
            _remember(run_named_query(conn, name, save_csv=save_next))
            save_next = False

        elif cmd in NAMED_QUERIES:
            # User typed a shortcut name directly (e.g. "general_overview")
            _remember(run_named_query(conn, cmd, save_csv=save_next))
            save_next = False

        elif cmd.startswith('sql '):
            raw_sql = user_input[4:].strip()
            results = run_sql(conn, raw_sql, save_csv=save_next)
            _remember(results)
            save_next = False
            if results and ollama_available:
                interpretation = interpret_results(raw_sql, results, conversation_history)
                if interpretation:
                    print(f"\n{BLUE}► {interpretation}{RESET}")

        # ── Natural language → intent router ──────────────────────────────
        else:
            intent = classify_intent_cli(user_input)

            # Data integrity check — schema-agnostic, no Ollama
            if intent == "integrity":
                _remember(data_integrity_check(conn, HISTORY_TABLE, save_csv=save_next))
                save_next = False
                continue

            # Chart the previous result — never regenerates SQL
            if intent == "chart":
                chart_last_results_cli(user_input, last_columns, last_results)
                continue

            # Schema / catalog questions — answered from metadata, no Ollama
            if intent == "meta":
                answer_meta_cli(user_input)
                continue

            # Aviation knowledge questions — Ollama, no SQL
            if intent == "domain":
                if not ollama_available:
                    print(f"{RED}Ollama not available — start it with 'ollama serve'.{RESET}")
                    continue
                answer_domain_cli(user_input, conversation_history)
                continue

            # ── Analytical → SQL ──
            if not ollama_available:
                print(f"{RED}Ollama not available. Use 'sql <query>' for direct SQL or start Ollama with 'ollama serve'.{RESET}")
                continue

            # Check if the question matches a named shortcut by intent
            matched_shortcut = _match_shortcut_by_intent(user_input)
            if matched_shortcut:
                _remember(run_named_query(conn, matched_shortcut, save_csv=save_next))
                save_next = False
                continue

            print(f"{DIM}Generating SQL...{RESET}")
            generated_sql = nl_to_sql(user_input, conversation_history)

            if not generated_sql:
                continue

            print(f"\n{DIM}Generated SQL:{RESET}")
            print(f"{DIM}{generated_sql}{RESET}\n")

            # Ask for confirmation before running
            confirm = input(f"{COPPER}Run this query? (y/n/edit): {RESET}").strip().lower()

            if confirm == 'n':
                print(f"{DIM}Skipped.{RESET}")
                continue
            elif confirm == 'edit':
                print(f"Paste edited SQL (press Enter twice when done):")
                lines = []
                while True:
                    line = input()
                    if line == '' and lines and lines[-1] == '':
                        break
                    lines.append(line)
                generated_sql = '\n'.join(lines[:-1])

            results = run_sql(conn, generated_sql, save_csv=save_next)
            _remember(results)
            save_next = False

            if results:
                interpretation = interpret_results(user_input, results, conversation_history)
                if interpretation:
                    print(f"\n{BLUE}► {interpretation}{RESET}")

                # Update conversation history
                conversation_history.append({"role": "user", "content": user_input})
                conversation_history.append({
                    "role": "assistant",
                    "content": f"SQL: {generated_sql}\n\nResults summary: {json.dumps(results[:5], default=str)}"
                })


# ── Entry point ──────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="AvTrix Fleet Intelligence — Local Analyst")
    parser.add_argument('--query',  '-q', help='Natural language question (non-interactive)')
    parser.add_argument('--run',    '-r', help='Run a named query shortcut')
    parser.add_argument('--list',   '-l', action='store_true', help='List named query shortcuts')
    parser.add_argument('--save',   '-s', action='store_true', help='Save result to CSV')
    parser.add_argument('--sql',          help='Execute raw SQL directly')
    parser.add_argument('--check',  '-c', action='store_true',
                        help='Run a data integrity check on the active table')
    args = parser.parse_args()

    if args.list:
        list_shortcuts()
        return

    banner()

    # Validate config
    missing = [k for k, v in {
        'DATABRICKS_HOST': DATABRICKS_HOST,
        'DATABRICKS_HTTP_PATH': DATABRICKS_HTTP_PATH,
        'DATABRICKS_TOKEN': DATABRICKS_TOKEN,
    }.items() if not v]

    if missing:
        print(f"{RED}✗ Missing config in .env: {', '.join(missing)}{RESET}")
        print(f"{DIM}Edit the .env file in the same folder as this script.{RESET}")
        sys.exit(1)

    conn = get_db_connection()
    if not conn:
        sys.exit(1)

    print(f"{GREEN}✓ Connected to Databricks{RESET}")

    if args.check:
        data_integrity_check(conn, HISTORY_TABLE, save_csv=args.save)

    elif args.run:
        run_named_query(conn, args.run, save_csv=args.save)

    elif args.sql:
        run_sql(conn, args.sql, save_csv=args.save)

    elif args.query:
        if not check_ollama():
            sys.exit(1)
        print(f"{DIM}Generating SQL for: {args.query}{RESET}")
        sql = nl_to_sql(args.query)
        if sql:
            print(f"{DIM}{sql}{RESET}\n")
            run_sql(conn, sql, save_csv=args.save)

    else:
        # Interactive mode
        interactive_loop(conn)

    conn.close()


if __name__ == "__main__":
    main()

# AvTrix Fleet Intelligence — Local Analyst

Replaces Databricks Genie with a local Ollama LLM connected directly
to your Delta tables. No usage caps. Everything runs on your laptop.
Your data never leaves your environment.

---

## First-time setup (one-time, ~10 minutes)

### 1. Install Python dependencies

```bash
pip install databricks-sql-connector python-dotenv ollama
```

### 2. Configure your credentials

```bash
cp .env.template .env
```

Open `.env` and fill in your three Databricks values:

| Setting | Where to find it |
|---|---|
| `DATABRICKS_HOST` | Databricks workspace URL (without https://) |
| `DATABRICKS_HTTP_PATH` | SQL Warehouses → your warehouse → Connection details |
| `DATABRICKS_TOKEN` | User Settings → Access Tokens → Generate new token |

Leave `HISTORY_TABLE` and `OLLAMA_MODEL` as-is unless you need to change them.

### 3. Pull the Ollama model (first time only)

```bash
ollama pull llama3
```

This downloads ~4GB once. Never again after that.

---

## Daily usage

### Start Ollama (if not set to auto-start)

```bash
ollama serve
```

Leave this running in a terminal tab. You only need to do this once per session.

### Open the analyst

```bash
cd avtrix_analyst
python avtrix_analyst.py
```

That's it. You're connected and ready.

---

## What you can do

### Natural language questions (Ollama generates the SQL)

```
AvTrix > how many records have a null jobtype in 2023?
AvTrix > show me the top 10 most frequently removed parts
AvTrix > what's the breakdown of reason codes under SCHEDULED jobs?
AvTrix > which components have the lowest MTBUR values?
```

The tool generates the SQL, shows it to you, asks for confirmation, runs it,
and interprets the results — same flow as Genie, no usage cap.

### Named shortcuts (pre-built, instant)

Pre-built queries from the FB discovery analysis. No LLM needed — run directly.

```bash
# List all shortcuts
python avtrix_analyst.py --list

# Run a specific shortcut
python avtrix_analyst.py --run jobtype_temporal
python avtrix_analyst.py --run reason_by_jobtype
python avtrix_analyst.py --run workorder_coverage
python avtrix_analyst.py --run component_mtbur
```

Or from inside the interactive session:
```
AvTrix > run jobtype_temporal
AvTrix > run component_mtbur
```

### Raw SQL (no LLM, instant)

```
AvTrix > sql SELECT COUNT(*) FROM poc.avtrix_fb.alg_history_report
```

Or from the command line:
```bash
python avtrix_analyst.py --sql "SELECT COUNT(*) FROM poc.avtrix_fb.alg_history_report"
```

### Save results to CSV

```
AvTrix > save
AvTrix > run component_mtbur
```

Or via flag:
```bash
python avtrix_analyst.py --run component_mtbur --save
```

---

## Named shortcuts available

| Shortcut | What it does |
|---|---|
| `jobtype_distribution` | Overall SCHEDULED / UNSCHEDULED / NULL split |
| `jobtype_temporal` | JOBTYPE by year — surfaces the 2022-2025 labelling collapse |
| `reason_by_jobtype` | REASON codes split by JOBTYPE — shows the '-' dominance |
| `workorder_coverage` | WORKORDER_NUMBER population rate |
| `installed_side_capture` | INSTALLED_PARTNO/SERIALNO null rates across three denominators |
| `utilisation_by_year` | Annual flight hours derived from the maintenance record |
| `missing_dates_by_aircraft` | Missing install/removal dates by aircraft registration |
| `time_expired_split` | TIME EXPIRED reason split across SCHEDULED vs UNSCHEDULED |
| `true_reliability_population` | Count of defensible reliability events after all filters |
| `component_mtbur` | Component-level MTBUR for parts with n ≥ 5 events |

---

## What persists when you shut down

| Thing | Persists? |
|---|---|
| Delta tables in Databricks | ✓ Always — unaffected by anything local |
| This script | ✓ It's a file on your laptop |
| Ollama models | ✓ Downloaded once, stored locally forever |
| Your .env credentials | ✓ File on your laptop |
| CSV exports | ✓ Saved to the script folder |
| Conversation context | ✗ Resets each session (same as a browser tab) |
| Ollama server process | ✗ Needs `ollama serve` each session (or set to auto-start) |

**Bottom line:** shut down any time. Open the laptop, run `ollama serve` + `python avtrix_analyst.py`, and you're back exactly where you were.

---

## Auto-start Ollama on login (optional)

### Mac
```bash
# Add to your ~/.zshrc or ~/.bashrc
# ollama serve runs automatically — no need to start it manually
```
Ollama on Mac installs as a menu bar app and auto-starts by default.

### Windows
Add a shortcut to `ollama serve` in your Startup folder
(`shell:startup` in Windows Explorer).

---

## Adding new named shortcuts

Open `avtrix_analyst.py` and add an entry to the `NAMED_QUERIES` dict:

```python
"my_new_query": {
    "description": "What this query does",
    "sql": """
        SELECT ...
        FROM {table}
        WHERE ...
    """
},
```

The `{table}` placeholder is automatically replaced with your `HISTORY_TABLE` value.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `Databricks connection failed` | Check .env credentials. Try generating a new token. |
| `Ollama not reachable` | Run `ollama serve` in a separate terminal |
| `Model not found` | Run `ollama pull llama3` |
| SQL error from LLM | Use `sql <query>` mode and write SQL directly |
| Wrong table name | Update `HISTORY_TABLE` in .env |

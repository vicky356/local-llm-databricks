"""Reliable, read-only Databricks SQL execution for AvTrix.

The web application is threaded, while Databricks SQL connections and cursors
are not safe to share between request threads.  This module therefore gives
each query its own connection, closes it deterministically, and retries once
when Databricks reports that the session handle has expired.
"""

from __future__ import annotations

from dataclasses import dataclass
import logging
import queue
import re
import threading
from typing import Any, Callable, Iterable, Optional


LOGGER = logging.getLogger(__name__)


_READ_ONLY_START = re.compile(r"^\s*(SELECT|WITH|DESCRIBE|DESC|SHOW|EXPLAIN|USE)\b", re.I)
_WRITE_KEYWORDS = re.compile(
    r"\b(INSERT|UPDATE|DELETE|MERGE|CREATE|ALTER|DROP|TRUNCATE|COPY|GRANT|"
    r"REVOKE|OPTIMIZE|VACUUM|CALL|EXECUTE|REPLACE|RESTORE)\b",
    re.I,
)
_SESSION_ERROR = re.compile(r"INVALID_STATE|Invalid\s+SessionHandle|SessionHandle", re.I)
_AUTH_ERROR = re.compile(r"UNAUTHENTICATED|PERMISSION_DENIED|HTTP\s*(401|403)|token|credential", re.I)
_TIMEOUT_ERROR = re.compile(r"timeout|timed\s*out|deadline", re.I)
_SQL_ERROR = re.compile(
    r"PARSE_SYNTAX_ERROR|SYNTAX_ERROR|UNRESOLVED_COLUMN|TABLE_OR_VIEW_NOT_FOUND|"
    r"AnalysisException|ParseException",
    re.I,
)


@dataclass(frozen=True)
class QueryError:
    category: str
    message: str
    retryable: bool = False
    detail: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "category": self.category,
            "message": self.message,
            "retryable": self.retryable,
        }
        if self.detail:
            payload["detail"] = self.detail
        return payload


@dataclass(frozen=True)
class QueryOutcome:
    columns: list[str]
    rows: list[list[Any]]
    truncated: bool = False
    error: Optional[QueryError] = None
    attempts: int = 1

    @property
    def ok(self) -> bool:
        return self.error is None


def _strip_sql_literals_and_comments(sql_text: str) -> str:
    """Remove quoted content/comments before checking for write keywords."""
    cleaned = re.sub(r"/\*.*?\*/", " ", sql_text, flags=re.S)
    cleaned = re.sub(r"--[^\n]*", " ", cleaned)
    cleaned = re.sub(r"'(?:''|[^'])*'", "''", cleaned)
    cleaned = re.sub(r'"(?:""|[^"])*"', '""', cleaned)
    cleaned = re.sub(r"`(?:``|[^`])*`", "``", cleaned)
    return cleaned


def validate_read_only_sql(sql_text: str) -> Optional[QueryError]:
    """Return a validation error when SQL is not a single read-only statement."""
    sql_text = (sql_text or "").strip()
    if not sql_text:
        return QueryError("validation", "No SQL statement was provided.", False)

    without_trailing_semicolon = sql_text[:-1] if sql_text.endswith(";") else sql_text
    cleaned = _strip_sql_literals_and_comments(without_trailing_semicolon)
    if ";" in cleaned:
        return QueryError(
            "validation",
            "Only one read-only SQL statement may be executed at a time.",
            False,
        )
    if not _READ_ONLY_START.search(cleaned):
        return QueryError(
            "validation",
            "Only SELECT, WITH, DESCRIBE, SHOW, EXPLAIN and USE statements are allowed.",
            False,
        )
    match = _WRITE_KEYWORDS.search(cleaned)
    if match:
        return QueryError(
            "validation",
            f"The statement contains a prohibited operation: {match.group(1).upper()}.",
            False,
        )
    return None


def classify_exception(exc: BaseException, secrets: Iterable[str] = ()) -> QueryError:
    raw = str(exc) or exc.__class__.__name__
    safe = raw
    for secret in secrets:
        if secret:
            safe = safe.replace(secret, "[REDACTED]")

    if _SESSION_ERROR.search(raw):
        return QueryError(
            "session_expired",
            "The Databricks session expired. AvTrix attempted to reconnect.",
            True,
            safe,
        )
    if _AUTH_ERROR.search(raw):
        return QueryError(
            "authentication",
            "Databricks authentication or permissions failed.",
            False,
            safe,
        )
    if _TIMEOUT_ERROR.search(raw):
        return QueryError(
            "timeout",
            "The Databricks request exceeded the configured timeout.",
            True,
            safe,
        )
    if _SQL_ERROR.search(raw):
        return QueryError("sql", "Databricks rejected the SQL query.", False, safe)
    return QueryError("connection", "The Databricks request failed.", True, safe)


class DatabricksQueryClient:
    """Thread-safe query runner using a short-lived connection per operation."""

    def __init__(
        self,
        server_hostname: str,
        http_path: str,
        access_token: str,
        *,
        max_rows: int = 500,
        query_timeout_seconds: float = 60,
        session_retries: int = 1,
        connector: Optional[Callable[..., Any]] = None,
    ) -> None:
        self.server_hostname = server_hostname
        self.http_path = http_path
        self.access_token = access_token
        self.max_rows = max(1, int(max_rows))
        self.query_timeout_seconds = max(0.1, float(query_timeout_seconds))
        self.session_retries = max(0, int(session_retries))
        self._connector = connector

    @property
    def configured(self) -> bool:
        return bool(self.server_hostname and self.http_path and self.access_token)

    def _connect(self):
        if not self.configured:
            raise RuntimeError("Databricks connection settings are incomplete.")
        connector = self._connector
        if connector is None:
            from databricks import sql as dbsql

            connector = dbsql.connect
        return connector(
            server_hostname=self.server_hostname,
            http_path=self.http_path,
            access_token=self.access_token,
        )

    @staticmethod
    def _catalog_prefix(table_ref: Optional[str]) -> Optional[str]:
        parts = (table_ref or "").strip().split(".")
        if len(parts) == 3:
            catalog = parts[0].replace("`", "")
            return f"USE CATALOG `{catalog}`"
        return None

    def _run_once(self, sql_text: str, table_ref: Optional[str]) -> QueryOutcome:
        result_queue: queue.Queue[QueryOutcome] = queue.Queue(maxsize=1)
        active: dict[str, Any] = {"connection": None, "cursor": None}
        active_lock = threading.Lock()

        def worker() -> None:
            connection = None
            cursor = None
            try:
                connection = self._connect()
                cursor = connection.cursor()
                with active_lock:
                    active["connection"] = connection
                    active["cursor"] = cursor

                prefix = self._catalog_prefix(table_ref)
                if prefix:
                    cursor.execute(prefix)
                cursor.execute(sql_text)

                description = cursor.description or []
                columns = [str(desc[0]) for desc in description]
                if not columns:
                    rows: list[list[Any]] = []
                    truncated = False
                else:
                    fetched = list(cursor.fetchmany(self.max_rows + 1))
                    truncated = len(fetched) > self.max_rows
                    rows = [list(row) for row in fetched[: self.max_rows]]
                result_queue.put(QueryOutcome(columns, rows, truncated=truncated))
            except Exception as exc:  # classified and redacted for the API boundary
                error = classify_exception(
                    exc,
                    secrets=(self.access_token, self.server_hostname, self.http_path),
                )
                LOGGER.warning("Databricks %s error: %s", error.category, error.detail or error.message)
                result_queue.put(QueryOutcome([], [], error=error))
            finally:
                for resource in (cursor, connection):
                    if resource is not None:
                        try:
                            resource.close()
                        except Exception:
                            pass

        thread = threading.Thread(target=worker, daemon=True, name="avtrix-databricks-query")
        thread.start()
        thread.join(self.query_timeout_seconds)

        if thread.is_alive():
            with active_lock:
                cursor = active.get("cursor")
                connection = active.get("connection")
            if cursor is not None:
                try:
                    cursor.cancel()
                except Exception:
                    pass
            if connection is not None:
                try:
                    connection.close()
                except Exception:
                    pass
            return QueryOutcome(
                [],
                [],
                error=QueryError(
                    "timeout",
                    f"The Databricks query exceeded {self.query_timeout_seconds:g} seconds.",
                    True,
                ),
            )

        try:
            return result_queue.get_nowait()
        except queue.Empty:
            return QueryOutcome(
                [],
                [],
                error=QueryError("application", "The query worker returned no result.", True),
            )

    def execute(self, sql_text: str, *, table_ref: Optional[str] = None) -> QueryOutcome:
        validation_error = validate_read_only_sql(sql_text)
        if validation_error:
            return QueryOutcome([], [], error=validation_error)

        attempts = 0
        while True:
            attempts += 1
            outcome = self._run_once(sql_text, table_ref)
            if outcome.ok:
                return QueryOutcome(
                    outcome.columns,
                    outcome.rows,
                    truncated=outcome.truncated,
                    attempts=attempts,
                )
            should_retry = (
                outcome.error is not None
                and outcome.error.category == "session_expired"
                and attempts <= self.session_retries
            )
            if not should_retry:
                return QueryOutcome(
                    outcome.columns,
                    outcome.rows,
                    truncated=outcome.truncated,
                    error=outcome.error,
                    attempts=attempts,
                )
            LOGGER.info("Retrying Databricks query after an expired session (attempt %s)", attempts + 1)

    def healthcheck(self) -> QueryOutcome:
        """Verify the connection with a real query, not only a Python object check."""
        return self.execute("SELECT 1 AS avtrix_healthcheck")

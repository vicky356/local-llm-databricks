import unittest

from databricks_client import QueryOutcome
from dataset_registry import (
    DatasetDiscoveryService,
    DatasetRegistry,
    parse_table_ref,
)


class FakeClient:
    def __init__(self, responses):
        self.responses = responses
        self.queries = []

    def execute(self, sql_text, *, table_ref=None):
        self.queries.append((sql_text, table_ref))
        for prefix, outcome in self.responses:
            if sql_text.startswith(prefix):
                return outcome
        raise AssertionError(f"Unexpected SQL: {sql_text}")


class DatasetRegistryTests(unittest.TestCase):
    def test_registry_tracks_active_dataset(self):
        registry = DatasetRegistry("catalog.schema.first_table")
        self.assertEqual(registry.get().table_ref, "catalog.schema.first_table")
        self.assertEqual(registry.get().schema_fingerprint, "pending")

    def test_requires_fully_qualified_simple_name(self):
        self.assertEqual(
            parse_table_ref("catalog.schema.table_name"),
            ("catalog", "schema", "table_name"),
        )
        with self.assertRaises(ValueError):
            parse_table_ref("schema.table")
        with self.assertRaises(ValueError):
            parse_table_ref("catalog.schema.bad table")


class DatasetDiscoveryTests(unittest.TestCase):
    def test_discovers_catalogs_schemas_and_tables(self):
        client = FakeClient([
            ("SHOW CATALOGS", QueryOutcome(["catalog"], [["main"], ["poc"]])),
            ("SHOW SCHEMAS", QueryOutcome(["databaseName"], [["default"], ["aviation"]])),
            ("SHOW TABLES", QueryOutcome(
                ["database", "tableName", "isTemporary"],
                [["aviation", "fleet_history", False], ["aviation", "fleet_view", False]],
            )),
        ])
        discovery = DatasetDiscoveryService(client)

        self.assertEqual(discovery.list_catalogs().value, ["main", "poc"])
        self.assertEqual(discovery.list_schemas("poc").value, ["aviation", "default"])
        tables = discovery.list_tables("poc", "aviation").value
        self.assertEqual(
            [table["table_ref"] for table in tables],
            ["poc.aviation.fleet_history", "poc.aviation.fleet_view"],
        )

    def test_describe_builds_repeatable_schema_fingerprint(self):
        rows = [
            ["aircraft", "string", "Registration"],
            ["event_date", "date", None],
            ["hours", "double", None],
            ["", "", None],
        ]
        client = FakeClient([
            ("DESCRIBE TABLE", QueryOutcome(["col_name", "data_type", "comment"], rows)),
        ])
        discovery = DatasetDiscoveryService(client)

        first = discovery.describe_table("poc.aviation.fleet_history")
        second = discovery.describe_table("poc.aviation.fleet_history")

        self.assertTrue(first.ok)
        self.assertEqual(first.value.schema_fingerprint, second.value.schema_fingerprint)
        self.assertEqual(first.value.column_count if hasattr(first.value, "column_count") else len(first.value.columns), 3)
        self.assertEqual(first.value.columns[0].data_type, "string")


if __name__ == "__main__":
    unittest.main()

import sys
import types
import unittest


try:
    import dotenv  # noqa: F401
except ImportError:
    dotenv = types.ModuleType("dotenv")
    dotenv.load_dotenv = lambda *args, **kwargs: None
    sys.modules["dotenv"] = dotenv

from avtrix_analyst import NAMED_QUERIES, _match_shortcut_by_intent, classify_intent_cli


class IntentRoutingTests(unittest.TestCase):
    def test_stale_shortcut_pattern_falls_through_instead_of_raising(self):
        self.assertNotIn("mtbur_by_part", NAMED_QUERIES)
        self.assertIsNone(_match_shortcut_by_intent("What's MTBUR?"))
        self.assertEqual(classify_intent_cli("What's MTBUR?"), "domain")
        self.assertEqual(classify_intent_cli("Whats MTBUR?"), "domain")

    def test_available_shortcut_still_matches(self):
        shortcut = _match_shortcut_by_intent("Show the jobtype distribution")
        self.assertEqual(shortcut, "jobtype_distribution")
        self.assertIn(shortcut, NAMED_QUERIES)


if __name__ == "__main__":
    unittest.main()

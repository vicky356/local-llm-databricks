"""Schema-agnostic, read-only dataset profiling for AvTrix.

Profiles are derived from live Databricks metadata and aggregate queries.  A
profile is evidence for investigation, not a declaration that data is wrong.
Cached profiles are keyed by both dataset reference and schema fingerprint so
a schema change can never silently reuse stale context.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import threading
from typing import Any, Iterable, Optional

from databricks_client import DatabricksQueryClient, QueryError
from dataset_registry import ColumnMetadata, DatasetMetadata, parse_table_ref, quote_identifier


PROFILE_VERSION = 1

DEFAULT_PLACEHOLDERS = (
    "-", "--", "n/a", "na", "none", "null", "not available", "tbc", "tbd", "unknown",
)

_SENSITIVE_NAME = re.compile(
    r"(^|_)(name|email|phone|mobile|address|notes?|comments?|description|text|"
    r"url|website|contact|account|iban|swift|routing|password|token|secret)(_|$)",
    re.I,
)
_IDENTIFIER_NAME = re.compile(r"(^id$|_id$|^id_|uuid|guid|(^|_)key$|autonumber)", re.I)
_NATURAL_KEY_NAME = re.compile(
    r"(^|_)(registration|reg|serial|sn|reference|ref|number|no|code|date|time|"
    r"timestamp|leg|line|event|part|tail|invoice|order)(_|$)",
    re.I,
)
_CUMULATIVE_NAME = re.compile(r"cum|cumulative|lifetime|to_date|running_total|total_since", re.I)


def _type_family(data_type: str) -> str:
    base = (data_type or "").strip().lower().split("(", 1)[0]
    if base in {"string", "varchar", "char"}:
        return "string"
    if base in {
        "tinyint", "smallint", "int", "integer", "bigint", "float", "double",
        "real", "decimal", "numeric", "short", "long",
    }:
        return "numeric"
    if base in {"date", "timestamp", "timestamp_ntz", "timestamp_ltz"}:
        return "date"
    if base in {"boolean", "bool"}:
        return "boolean"
    if base.startswith(("array", "map", "struct", "variant", "object")):
        return "complex"
    return "other"


def _quoted_table(table_ref: str) -> str:
    return ".".join(quote_identifier(part) for part in parse_table_ref(table_ref))


def _sql_string(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def _alias(index: int, metric: str) -> str:
    return f"c{index:04d}_{metric}"


def _chunks(values: list[Any], size: int) -> Iterable[list[Any]]:
    for start in range(0, len(values), size):
        yield values[start:start + size]


def _safe_int(value: Any) -> int:
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


def _json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, (datetime,)):
        return value.isoformat()
    return str(value)


@dataclass(frozen=True)
class ProfilerConfig:
    columns_per_query: int = 16
    low_cardinality_threshold: int = 20
    max_representative_values: int = 10
    max_value_columns: int = 25
    sample_values_enabled: bool = True
    placeholders: tuple[str, ...] = DEFAULT_PLACEHOLDERS

    def __post_init__(self) -> None:
        object.__setattr__(self, "columns_per_query", max(1, int(self.columns_per_query)))
        object.__setattr__(self, "low_cardinality_threshold", max(1, int(self.low_cardinality_threshold)))
        object.__setattr__(self, "max_representative_values", max(1, int(self.max_representative_values)))
        object.__setattr__(self, "max_value_columns", max(0, int(self.max_value_columns)))


@dataclass(frozen=True)
class ProfileOutcome:
    profile: Optional[dict[str, Any]] = None
    error: Optional[QueryError] = None
    cached: bool = False

    @property
    def ok(self) -> bool:
        return self.error is None and self.profile is not None


class ProfileStore:
    """Local JSON cache that never returns a mismatched schema fingerprint."""

    def __init__(self, root: Path | str) -> None:
        self.root = Path(root)
        self._lock = threading.RLock()

    @staticmethod
    def _dataset_key(table_ref: str) -> str:
        return hashlib.sha256(table_ref.encode("utf-8")).hexdigest()[:16]

    def path_for(self, metadata: DatasetMetadata) -> Path:
        dataset_key = self._dataset_key(metadata.table_ref)
        return self.root / f"{dataset_key}-{metadata.schema_fingerprint[:16]}.json"

    def load(self, metadata: DatasetMetadata) -> Optional[dict[str, Any]]:
        path = self.path_for(metadata)
        if not path.exists():
            return None
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        dataset = payload.get("dataset") or {}
        if (
            payload.get("profile_version") != PROFILE_VERSION
            or dataset.get("table_ref") != metadata.table_ref
            or dataset.get("schema_fingerprint") != metadata.schema_fingerprint
        ):
            return None
        return payload

    def save(self, profile: dict[str, Any], metadata: DatasetMetadata) -> Path:
        path = self.path_for(metadata)
        with self._lock:
            self.root.mkdir(parents=True, exist_ok=True)
            temporary = path.with_suffix(".tmp")
            temporary.write_text(
                json.dumps(profile, indent=2, ensure_ascii=False, default=_json_safe),
                encoding="utf-8",
            )
            try:
                os.chmod(temporary, 0o600)
            except OSError:
                pass
            os.replace(temporary, path)
        return path


class DatasetProfiler:
    """Create and cache a bounded structural/statistical dataset profile."""

    def __init__(
        self,
        client: DatabricksQueryClient,
        store: ProfileStore,
        config: Optional[ProfilerConfig] = None,
    ) -> None:
        self.client = client
        self.store = store
        self.config = config or ProfilerConfig()
        self._lock = threading.RLock()

    def get_cached(self, metadata: DatasetMetadata) -> Optional[dict[str, Any]]:
        return self.store.load(metadata)

    def get_or_create(self, metadata: DatasetMetadata, *, refresh: bool = False) -> ProfileOutcome:
        with self._lock:
            if not refresh:
                cached = self.store.load(metadata)
                if cached is not None:
                    return ProfileOutcome(profile=cached, cached=True)
            return self._create(metadata)

    def _execute(self, sql: str, metadata: DatasetMetadata):
        return self.client.execute(sql, table_ref=metadata.table_ref)

    def _count_records(self, metadata: DatasetMetadata) -> tuple[Optional[int], Optional[QueryError], int]:
        sql = f"SELECT COUNT(*) AS total_records FROM {_quoted_table(metadata.table_ref)}"
        outcome = self._execute(sql, metadata)
        if not outcome.ok:
            return None, outcome.error, 1
        if not outcome.rows:
            return None, QueryError("profile", "The record-count query returned no result.", False), 1
        return _safe_int(outcome.rows[0][0]), None, 1

    def _aggregate_sql(self, metadata: DatasetMetadata, indexed_columns: list[tuple[int, ColumnMetadata]]) -> str:
        expressions: list[str] = []
        placeholders = ", ".join(_sql_string(token.lower()) for token in self.config.placeholders)
        for index, column in indexed_columns:
            quoted = quote_identifier(column.name)
            family = _type_family(column.data_type)
            expressions.append(
                f"SUM(CASE WHEN {quoted} IS NULL THEN 1 ELSE 0 END) AS `{_alias(index, 'null')}`"
            )
            if family != "complex":
                expressions.append(
                    f"approx_count_distinct({quoted}) AS `{_alias(index, 'distinct')}`"
                )
            if family == "string":
                text = f"TRIM(CAST({quoted} AS STRING))"
                expressions.extend([
                    f"SUM(CASE WHEN {quoted} IS NOT NULL AND {text} = '' THEN 1 ELSE 0 END) "
                    f"AS `{_alias(index, 'blank')}`",
                    f"SUM(CASE WHEN {quoted} IS NOT NULL AND LOWER({text}) IN ({placeholders}) "
                    f"THEN 1 ELSE 0 END) AS `{_alias(index, 'placeholder')}`",
                    f"SUM(CASE WHEN {quoted} IS NOT NULL AND {text} <> '' AND "
                    f"TRY_CAST({text} AS DOUBLE) IS NOT NULL THEN 1 ELSE 0 END) "
                    f"AS `{_alias(index, 'numeric_like')}`",
                    f"SUM(CASE WHEN {quoted} IS NOT NULL AND {text} <> '' AND "
                    f"TRY_CAST({text} AS TIMESTAMP) IS NOT NULL THEN 1 ELSE 0 END) "
                    f"AS `{_alias(index, 'date_like')}`",
                    f"MIN(LENGTH({text})) AS `{_alias(index, 'min_length')}`",
                    f"MAX(LENGTH({text})) AS `{_alias(index, 'max_length')}`",
                ])
            elif family in {"numeric", "date"}:
                expressions.extend([
                    f"MIN({quoted}) AS `{_alias(index, 'min')}`",
                    f"MAX({quoted}) AS `{_alias(index, 'max')}`",
                ])
        return "SELECT\n  " + ",\n  ".join(expressions) + f"\nFROM {_quoted_table(metadata.table_ref)}"

    def _profile_columns(
        self,
        metadata: DatasetMetadata,
        record_count: int,
    ) -> tuple[Optional[list[dict[str, Any]]], Optional[QueryError], int]:
        indexed = list(enumerate(metadata.columns))
        raw_stats: dict[str, Any] = {}
        query_count = 0
        for chunk in _chunks(indexed, self.config.columns_per_query):
            outcome = self._execute(self._aggregate_sql(metadata, chunk), metadata)
            query_count += 1
            if not outcome.ok:
                return None, outcome.error, query_count
            if not outcome.rows:
                return None, QueryError("profile", "A column-profile query returned no result.", False), query_count
            raw_stats.update({str(key).lower(): value for key, value in zip(outcome.columns, outcome.rows[0])})

        columns: list[dict[str, Any]] = []
        for index, column in indexed:
            family = _type_family(column.data_type)
            null_count = _safe_int(raw_stats.get(_alias(index, "null")))
            blank_count = _safe_int(raw_stats.get(_alias(index, "blank"))) if family == "string" else 0
            placeholder_count = _safe_int(raw_stats.get(_alias(index, "placeholder"))) if family == "string" else 0
            missing_count = min(record_count, null_count + blank_count + placeholder_count)
            distinct = None if family == "complex" else _safe_int(raw_stats.get(_alias(index, "distinct")))
            non_missing = max(0, record_count - missing_count)
            unique_ratio = (distinct / non_missing) if distinct is not None and non_missing else None

            entry: dict[str, Any] = {
                "name": column.name,
                "data_type": column.data_type,
                "type_family": family,
                "comment": column.comment,
                "null_count": null_count,
                "blank_count": blank_count,
                "placeholder_count": placeholder_count,
                "missing_count": missing_count,
                "missing_rate": round(missing_count / record_count, 6) if record_count else 0.0,
                "approx_distinct_count": distinct,
                "approx_unique_ratio": round(unique_ratio, 6) if unique_ratio is not None else None,
                "representative_values": [],
                "values_suppressed": bool(_SENSITIVE_NAME.search(column.name)),
                "anomalies": [],
            }
            if family == "string":
                entry.update({
                    "numeric_like_count": _safe_int(raw_stats.get(_alias(index, "numeric_like"))),
                    "date_like_count": _safe_int(raw_stats.get(_alias(index, "date_like"))),
                    "min_length": _safe_int(raw_stats.get(_alias(index, "min_length"))),
                    "max_length": _safe_int(raw_stats.get(_alias(index, "max_length"))),
                })
            if family in {"numeric", "date"}:
                entry["min"] = _json_safe(raw_stats.get(_alias(index, "min")))
                entry["max"] = _json_safe(raw_stats.get(_alias(index, "max")))

            self._classify_column(entry, record_count)
            columns.append(entry)
        return columns, None, query_count

    @staticmethod
    def _classify_column(entry: dict[str, Any], record_count: int) -> None:
        name = entry["name"]
        family = entry["type_family"]
        ratio = entry.get("approx_unique_ratio")
        missing_rate = entry["missing_rate"]
        non_missing = max(0, record_count - entry["missing_count"])

        if family == "date":
            role = "date"
        elif _IDENTIFIER_NAME.search(name):
            role = "identifier"
        elif family == "numeric":
            role = "measure"
        elif ratio is not None and ratio >= 0.98 and missing_rate == 0:
            role = "identifier"
        elif family in {"string", "boolean"}:
            role = "dimension"
        else:
            role = "complex" if family == "complex" else "attribute"
        entry["inferred_role"] = role
        entry["is_cumulative_candidate"] = bool(_CUMULATIVE_NAME.search(name))

        anomalies = entry["anomalies"]
        if missing_rate >= 0.5:
            anomalies.append("high_missing_rate")
        elif missing_rate >= 0.1:
            anomalies.append("moderate_missing_rate")
        if entry["blank_count"]:
            anomalies.append("blank_strings")
        if entry["placeholder_count"]:
            anomalies.append("placeholder_values")
        if record_count > 1 and entry.get("approx_distinct_count") == 1:
            anomalies.append("constant_column")
        if family == "string" and non_missing:
            numeric_like = entry.get("numeric_like_count", 0)
            date_like = entry.get("date_like_count", 0)
            if numeric_like == non_missing:
                anomalies.append("numeric_values_stored_as_text")
            elif numeric_like / non_missing >= 0.1:
                anomalies.append("mixed_numeric_like_text")
            if date_like == non_missing:
                anomalies.append("date_values_stored_as_text")
            elif date_like / non_missing >= 0.1:
                anomalies.append("mixed_date_like_text")

    def _add_representative_values(
        self,
        metadata: DatasetMetadata,
        columns: list[dict[str, Any]],
    ) -> tuple[Optional[QueryError], int]:
        if not self.config.sample_values_enabled or self.config.max_value_columns == 0:
            return None, 0
        eligible = [
            column for column in columns
            if not column["values_suppressed"]
            and column["type_family"] in {"string", "boolean", "numeric"}
            and column.get("approx_distinct_count") is not None
            and 0 < column["approx_distinct_count"] <= self.config.low_cardinality_threshold
        ][:self.config.max_value_columns]

        query_count = 0
        placeholder_sql = ", ".join(_sql_string(token.lower()) for token in self.config.placeholders)
        table_sql = _quoted_table(metadata.table_ref)
        for column in eligible:
            quoted = quote_identifier(column["name"])
            text = f"TRIM(CAST({quoted} AS STRING))"
            sql = (
                f"SELECT {text} AS value, COUNT(*) AS value_count\n"
                f"FROM {table_sql}\n"
                f"WHERE {quoted} IS NOT NULL AND {text} <> '' "
                f"AND LOWER({text}) NOT IN ({placeholder_sql})\n"
                f"GROUP BY {quoted}\nORDER BY value_count DESC, value ASC\n"
                f"LIMIT {self.config.max_representative_values}"
            )
            outcome = self._execute(sql, metadata)
            query_count += 1
            if not outcome.ok:
                return outcome.error, query_count
            column["representative_values"] = [
                {"value": _json_safe(row[0]), "count": _safe_int(row[1])}
                for row in outcome.rows if row
            ]
        return None, query_count

    @staticmethod
    def _candidate_keys(columns: list[dict[str, Any]], record_count: int) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        identifiers: list[dict[str, Any]] = []
        semantic_components: list[tuple[float, str]] = []
        if record_count > 1:
            for column in columns:
                ratio = column.get("approx_unique_ratio")
                if ratio is not None and ratio >= 0.98 and column["missing_count"] == 0:
                    identifiers.append({
                        "columns": [column["name"]],
                        "confidence": "high" if ratio >= 0.999 else "medium",
                        "basis": "Approximate distinctness and completeness; confirm with an exact duplicate check.",
                        "requires_validation": True,
                    })
                if _NATURAL_KEY_NAME.search(column["name"]) and column["missing_rate"] < 0.2:
                    semantic_components.append((ratio or 0.0, column["name"]))

        identifiers.sort(key=lambda item: item["columns"][0].lower())
        semantic_components.sort(key=lambda item: (-item[0], item[1].lower()))
        natural_keys: list[dict[str, Any]] = []
        names = [name for _, name in semantic_components[:3]]
        if len(names) >= 2:
            natural_keys.append({
                "columns": names,
                "confidence": "low",
                "basis": "Name and completeness heuristics only; combination uniqueness has not been tested.",
                "requires_validation": True,
            })
        return identifiers[:10], natural_keys

    def _create(self, metadata: DatasetMetadata) -> ProfileOutcome:
        if not metadata.columns or metadata.schema_fingerprint == "pending":
            return ProfileOutcome(error=QueryError(
                "profile", "Live column metadata is required before profiling.", False,
            ))

        query_count = 0
        record_count, error, count_queries = self._count_records(metadata)
        query_count += count_queries
        if error is not None or record_count is None:
            return ProfileOutcome(error=error)

        columns, error, profile_queries = self._profile_columns(metadata, record_count)
        query_count += profile_queries
        if error is not None or columns is None:
            return ProfileOutcome(error=error)

        error, value_queries = self._add_representative_values(metadata, columns)
        query_count += value_queries
        if error is not None:
            return ProfileOutcome(error=error)

        identifiers, natural_keys = self._candidate_keys(columns, record_count)
        anomaly_counts: dict[str, int] = {}
        role_counts: dict[str, int] = {}
        for column in columns:
            role = column["inferred_role"]
            role_counts[role] = role_counts.get(role, 0) + 1
            for anomaly in column["anomalies"]:
                anomaly_counts[anomaly] = anomaly_counts.get(anomaly, 0) + 1

        profile = {
            "profile_version": PROFILE_VERSION,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "cached": False,
            "dataset": metadata.to_dict(include_columns=False),
            "record_count": record_count,
            "column_count": len(columns),
            "role_summary": role_counts,
            "anomaly_summary": anomaly_counts,
            "candidate_identifiers": identifiers,
            "candidate_natural_keys": natural_keys,
            "columns": columns,
            "provenance": {
                "query_count": query_count,
                "uses_approximate_distinct_counts": True,
                "representative_values_enabled": self.config.sample_values_enabled,
                "sensitive_value_sampling_suppressed": True,
                "warning": "Flags and key suggestions are evidence for review, not proof of an error or key.",
            },
        }
        self.store.save(profile, metadata)
        return ProfileOutcome(profile=profile, cached=False)


def profile_summary(profile: dict[str, Any]) -> dict[str, Any]:
    """Small, UI-safe summary that excludes column values."""
    return {
        "dataset": profile.get("dataset"),
        "generated_at": profile.get("generated_at"),
        "record_count": profile.get("record_count", 0),
        "column_count": profile.get("column_count", 0),
        "role_summary": profile.get("role_summary", {}),
        "anomaly_summary": profile.get("anomaly_summary", {}),
        "candidate_identifier_count": len(profile.get("candidate_identifiers") or []),
        "candidate_natural_key_count": len(profile.get("candidate_natural_keys") or []),
        "provenance": profile.get("provenance", {}),
    }

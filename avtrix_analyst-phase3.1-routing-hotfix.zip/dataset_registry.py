"""Runtime dataset discovery and active-table state for AvTrix."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import re
import threading
from typing import Any, Optional

from databricks_client import DatabricksQueryClient, QueryError


_SIMPLE_IDENTIFIER = re.compile(r"^[A-Za-z0-9_$-]+$")


def quote_identifier(value: str) -> str:
    value = (value or "").strip()
    if not value or "`" in value:
        raise ValueError("Invalid Databricks identifier.")
    return f"`{value}`"


def parse_table_ref(table_ref: str) -> tuple[str, str, str]:
    parts = [part.strip().strip("`") for part in (table_ref or "").split(".")]
    if len(parts) != 3 or not all(parts):
        raise ValueError("Use a fully qualified table name: catalog.schema.table.")
    if not all(_SIMPLE_IDENTIFIER.fullmatch(part) for part in parts):
        raise ValueError("The table name contains unsupported identifier characters.")
    return parts[0], parts[1], parts[2]


def qualified_ref(catalog: str, schema: str, table: str) -> str:
    for part in (catalog, schema, table):
        if not _SIMPLE_IDENTIFIER.fullmatch(part or ""):
            raise ValueError("The dataset identifier contains unsupported characters.")
    return f"{catalog}.{schema}.{table}"


@dataclass(frozen=True)
class ColumnMetadata:
    name: str
    data_type: str
    comment: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "data_type": self.data_type, "comment": self.comment}


@dataclass(frozen=True)
class DatasetMetadata:
    table_ref: str
    catalog: str
    schema: str
    table: str
    object_type: str
    columns: tuple[ColumnMetadata, ...]
    schema_fingerprint: str

    def to_dict(self, include_columns: bool = True) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "table_ref": self.table_ref,
            "catalog": self.catalog,
            "schema": self.schema,
            "table": self.table,
            "object_type": self.object_type,
            "schema_fingerprint": self.schema_fingerprint,
            "column_count": len(self.columns),
        }
        if include_columns:
            payload["columns"] = [column.to_dict() for column in self.columns]
        return payload


@dataclass(frozen=True)
class DiscoveryOutcome:
    value: Any = None
    error: Optional[QueryError] = None

    @property
    def ok(self) -> bool:
        return self.error is None


class DatasetRegistry:
    """Thread-safe active dataset state shared by all web requests."""

    def __init__(self, default_table: str) -> None:
        catalog, schema, table = parse_table_ref(default_table)
        self._lock = threading.RLock()
        self._active = DatasetMetadata(
            table_ref=qualified_ref(catalog, schema, table),
            catalog=catalog,
            schema=schema,
            table=table,
            object_type="UNKNOWN",
            columns=(),
            schema_fingerprint="pending",
        )

    def get(self) -> DatasetMetadata:
        with self._lock:
            return self._active

    def activate(self, metadata: DatasetMetadata) -> DatasetMetadata:
        with self._lock:
            self._active = metadata
            return self._active


class DatasetDiscoveryService:
    def __init__(self, client: DatabricksQueryClient) -> None:
        self.client = client

    @staticmethod
    def _failure(outcome) -> DiscoveryOutcome:
        return DiscoveryOutcome(error=outcome.error)

    def list_catalogs(self) -> DiscoveryOutcome:
        outcome = self.client.execute("SHOW CATALOGS")
        if not outcome.ok:
            return self._failure(outcome)
        catalogs = sorted({str(row[0]) for row in outcome.rows if row and row[0]})
        return DiscoveryOutcome(catalogs)

    def list_schemas(self, catalog: str) -> DiscoveryOutcome:
        try:
            catalog_sql = quote_identifier(catalog)
        except ValueError as exc:
            return DiscoveryOutcome(error=QueryError("validation", str(exc), False))
        outcome = self.client.execute(f"SHOW SCHEMAS IN {catalog_sql}")
        if not outcome.ok:
            return self._failure(outcome)
        schemas = sorted({str(row[0]) for row in outcome.rows if row and row[0]})
        return DiscoveryOutcome(schemas)

    def list_tables(self, catalog: str, schema: str) -> DiscoveryOutcome:
        try:
            catalog_sql = quote_identifier(catalog)
            schema_sql = quote_identifier(schema)
        except ValueError as exc:
            return DiscoveryOutcome(error=QueryError("validation", str(exc), False))
        outcome = self.client.execute(
            f"SHOW TABLES IN {catalog_sql}.{schema_sql}",
            table_ref=qualified_ref(catalog, schema, "discovery"),
        )
        if not outcome.ok:
            return self._failure(outcome)

        tables = []
        for row in outcome.rows:
            if len(row) < 2 or not row[1]:
                continue
            name = str(row[1])
            try:
                table_ref = qualified_ref(catalog, schema, name)
            except ValueError:
                continue
            is_temporary = bool(row[2]) if len(row) > 2 else False
            tables.append({
                "table_ref": table_ref,
                "catalog": catalog,
                "schema": schema,
                "table": name,
                "object_type": "TEMPORARY" if is_temporary else "TABLE_OR_VIEW",
            })
        tables.sort(key=lambda item: item["table"].lower())
        return DiscoveryOutcome(tables)

    def describe_table(self, table_ref: str, object_type: str = "TABLE_OR_VIEW") -> DiscoveryOutcome:
        try:
            catalog, schema, table = parse_table_ref(table_ref)
            quoted = ".".join(quote_identifier(part) for part in (catalog, schema, table))
        except ValueError as exc:
            return DiscoveryOutcome(error=QueryError("validation", str(exc), False))

        outcome = self.client.execute(
            f"DESCRIBE TABLE {quoted}",
            table_ref=qualified_ref(catalog, schema, table),
        )
        if not outcome.ok:
            return self._failure(outcome)

        columns: list[ColumnMetadata] = []
        for row in outcome.rows:
            if not row:
                continue
            name = str(row[0] or "").strip()
            if not name or name.startswith("#"):
                break
            data_type = str(row[1] or "").strip() if len(row) > 1 else "UNKNOWN"
            comment = str(row[2]).strip() if len(row) > 2 and row[2] is not None else None
            columns.append(ColumnMetadata(name=name, data_type=data_type, comment=comment))

        if not columns:
            return DiscoveryOutcome(error=QueryError(
                "metadata",
                "Databricks returned no columns for the selected dataset.",
                False,
            ))

        canonical = json.dumps(
            [column.to_dict() for column in columns],
            ensure_ascii=True,
            sort_keys=True,
            separators=(",", ":"),
        )
        fingerprint = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        metadata = DatasetMetadata(
            table_ref=qualified_ref(catalog, schema, table),
            catalog=catalog,
            schema=schema,
            table=table,
            object_type=object_type,
            columns=tuple(columns),
            schema_fingerprint=fingerprint,
        )
        return DiscoveryOutcome(metadata)

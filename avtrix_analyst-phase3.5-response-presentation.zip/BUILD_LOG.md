# AvTrix Analyst Build Log

This is the authoritative running record for the AvTrix local-LLM and
Databricks application. Update it whenever a phase is completed, a material
architecture decision is made, a milestone is tested, or a known limitation is
introduced or resolved.

## Project objective

Build a dataset-agnostic analytical agent that can connect to an unfamiliar
Databricks dataset, discover and profile it at runtime, generate safe SQL, and
provide evidence-based answers without training or hardcoding the model for a
specific table.

## Core principles

- Dataset knowledge is discovered at runtime, not fine-tuned into the model.
- Live Databricks metadata takes precedence over stored descriptions.
- Queries are read-only, bounded and auditable.
- Business methodology must be explicitly defined or approved.
- Inference is labelled as inference; uncertainty triggers clarification.
- Dataset-specific analysis packs remain optional and separate from the core.
- No credentials, tokens or complete connection strings are written to logs.

## Current milestone

**Milestone 2 — Generic runtime dataset profiling**

Status: **Implemented locally; live Mac/Databricks acceptance test pending.**

Included phases:

- Phase 1 — Databricks connector hardening
- Phase 2 — Dataset discovery and server-side table switching
- Phase 3 — Schema-agnostic profiling and fingerprinted profile storage

Packaged build:

`outputs/avtrix_analyst-phase3.5-response-presentation.zip`

---

## Phase 1 — Databricks connector hardening

Status: **Implemented**

### Problem addressed

The original web application retained one global Databricks connection. The UI
reported that Databricks was connected when the Python object existed, even if
the underlying server session had expired. Queries then failed with:

`INVALID_STATE: Invalid SessionHandle`

Unhandled server exceptions could also return Flask HTML to a browser expecting
JSON, producing messages such as:

`Unexpected token '<', "<!doctype "... is not valid JSON`

### Changes implemented

- Added `databricks_client.py`.
- Replaced shared cursors with managed, short-lived query connections.
- Added a real `SELECT 1` health check.
- Added one controlled reconnect after an expired session.
- Prevented unlimited retry loops.
- Added structured query outcomes and error categories.
- Redacted credentials and connection details from errors and logs.
- Added read-only SQL validation.
- Added a configurable 500-row result maximum.
- Added a configurable 60-second query timeout.
- Made web API failures consistently JSON-shaped.
- Applied the query client to both the browser and CLI paths.

### Configuration introduced

```text
DATABRICKS_QUERY_TIMEOUT_SECONDS=60
DATABRICKS_MAX_ROWS=500
DATABRICKS_SESSION_RETRIES=1
AVTRIX_LOG_LEVEL=INFO
```

### Verification

- Python compilation: passed.
- Connector unit tests: passed.
- Expired-session reconnect test: passed.
- Retry-limit test: passed.
- Timeout test: passed.
- Credential-redaction test: passed.
- Read-only SQL validation tests: passed.

### Live verification outstanding

- Deploy on the Mac.
- Confirm health check against the live Databricks warehouse.
- Confirm a query succeeds after an expired or restarted session.
- Confirm browser failures remain valid JSON.

---

## Phase 2 — Dataset discovery and selection

Status: **Implemented**

### Problem addressed

The interface displayed discovered tables, but clicking a table did not change
the server-side query target. The application continued to rely on the startup
`HISTORY_TABLE`, allowing the displayed dataset and queried dataset to diverge.

### Changes implemented

- Added `dataset_registry.py`.
- Added lazy catalog discovery.
- Added lazy schema discovery.
- Added table and view discovery within the selected schema.
- Added catalog and schema selectors to the web interface.
- Made table selection a server-side action through `POST /api/table`.
- Validated each selected dataset using a live `DESCRIBE TABLE`.
- Stored the active dataset in a thread-safe runtime registry.
- Captured the active dataset at the beginning of every query request.
- Refreshed the model's column context from live metadata.
- Added column names, data types and comments to dataset metadata.
- Added a SHA-256 schema fingerprint.
- Included source-dataset metadata in analytical responses.
- Cleared cached chart results when switching datasets.
- Changed `HISTORY_TABLE` into a startup default rather than a permanent target.
- Replaced the FB-specific default overview with a structural overview that is
  valid for any dataset.

### Discovery endpoints

```text
GET  /api/catalogs
GET  /api/schemas?catalog=<catalog>
GET  /api/tables?catalog=<catalog>&schema=<schema>
POST /api/table
```

### Verification

- Total automated tests: 11 passed.
- Python compilation: passed.
- Rendered web page generation: passed.
- Embedded JavaScript syntax validation: passed.
- Dataset discovery tests: passed.
- Schema-fingerprint repeatability test: passed.

### Live verification outstanding

- Confirm catalog and schema permissions against the live account.
- Switch between the two existing fleet tables in the browser.
- Confirm the displayed table and SQL source always match.
- Confirm the schema fingerprint changes when a schema changes.

---

## Phase 3 — Schema-agnostic dataset profiling

Status: **Implemented locally**

### Problem addressed

Live column names alone do not give the model enough context to reason reliably
about an unfamiliar dataset. A generic profiling layer was needed to establish
the dataset's shape, completeness, cardinality, ranges and likely analytical
roles without hardcoding field names from one aviation table.

### Changes implemented

- Added `dataset_profiler.py`.
- Added record and column counts.
- Added null, blank and placeholder counts and rates.
- Added approximate distinct counts and uniqueness ratios.
- Added numeric and date ranges.
- Added bounded representative values for low-cardinality columns.
- Suppressed representative-value sampling for sensitive-looking fields such
  as names, email, phone, address, notes, contact, account and token fields.
- Added inferred roles: identifier, dimension, measure, date, attribute and
  complex field.
- Added cumulative-field candidates based on neutral naming heuristics.
- Added candidate single-column identifiers.
- Added possible composite natural-key components, explicitly marked as
  unverified until an exact duplicate check is performed.
- Added structural review flags for missingness, constants, placeholders and
  numeric/date-like values stored in text fields.
- Added bounded query batching so wide schemas do not produce one unbounded
  aggregate statement.
- Added local JSON profile storage with restrictive file permissions where the
  operating system supports them.
- Keyed every stored profile to both dataset reference and schema fingerprint.
- Added live metadata refresh before profile lookup or creation so a changed
  schema cannot reuse stale context.
- Added `GET /api/profile` for cache lookup and `POST /api/profile` for explicit
  generation or refresh.
- Added a profile status card and Generate/Refresh control to the browser.
- Made the general overview use the generic profile.
- Added natural-language routing for requests such as “profile the active
  dataset”.
- Added profile configuration and privacy controls to `.env.template`.
- Excluded `.avtrix_profiles/` from Git.
- Corrected the read-only validator so quoted columns named after SQL verbs do
  not create false positives.

### Safety and interpretation

- All profile queries are read-only.
- Distinct counts are approximate to reduce cost.
- Candidate keys require exact validation before use.
- Review flags are evidence for review, not proof of bad data.
- Low-cardinality samples are local, bounded and suppress sensitive-looking
  fields by default.
- `AVTRIX_PROFILE_SAMPLE_VALUES=false` disables all representative-value
  storage while retaining counts, ranges and classifications.

### Verification

- Total automated tests: 15 passed.
- Python compilation: passed.
- Unfamiliar-schema profiling test: passed.
- Schema-fingerprint cache isolation test: passed.
- Sensitive-value suppression test: passed.
- Unverified natural-key suggestion test: passed.
- Quoted SQL-keyword identifier test: passed.
- Rendered web page generation: passed.
- Embedded JavaScript syntax validation: passed.

### Live verification outstanding

- Generate profiles for both current fleet tables on the Mac.
- Compare record counts, missingness and ranges with direct Databricks results.
- Profile at least one structurally different non-FB dataset.
- Confirm a second request uses the matching cached profile.
- Confirm profile runtime is acceptable on the free-tier warehouse.
- Confirm sensitive-looking columns contain no representative values in the
  local profile JSON.

---

## Phase 3.1 — MTBUR intent-routing hotfix

Date: **11 October 2026**  
Status: **Deployed and verified on the Mac**

### Incident

Asking “What's MTBUR?” or “Whats MTBUR?” returned the generic unexpected
application error. Separately, the deployed LAN URL timed out and did not
return a page.

### Root cause

- `_SHORTCUT_PATTERNS` still contained `mtbur_by_part` after that shortcut had
  been removed from `NAMED_QUERIES`.
- The web route trusted the matcher result and indexed
  `NAMED_QUERIES['mtbur_by_part']`, raising a `KeyError`.
- The domain classifier recognised “what is” but not the common “what's” or
  “whats” forms.
- The page timeout is a separate operational condition: no service responded
  at `192.168.0.197:5001` during inspection. It is not caused by the MTBUR
  routing exception.

### Changes implemented

- Intent matching now ignores patterns whose shortcut is unavailable.
- The web route defensively confirms a shortcut exists before indexing it.
- Web and CLI domain patterns now recognise “what is”, “what's” and “whats”.
- Added regression coverage for stale patterns and both MTBUR question forms.

### Verification

- Total automated tests: 17 passed.
- Python compilation: passed.
- Direct `/api/query` routing simulation: passed for both “What's MTBUR?” and
  “Whats MTBUR?”.
- Live page check at `192.168.0.201:5001`: passed (HTTP 200).
- Live `/api/query` checks: both “What's MTBUR?” and “Whats MTBUR?” returned
  HTTP 200, routed as domain questions and produced an MTBUR explanation.
- No `KeyError` or unexpected application error was reproduced after deployment.

---

## Live milestone acceptance — Mac deployment

Date: **11 October 2026**  
Status: **Core service passed; free-text SQL quality gap confirmed**

### Environment observed

- Active model: `ministral-3:8b`.
- Active dataset: `poc.avtrix_fb.fb_camp_fleet_history_join`.
- Live schema: 71 columns, fingerprint `8300218b3a16`.
- Ollama health: passed.
- Databricks health: first eight-second check timed out while the warehouse was
  cold; the warm-state check then passed in 1.2 seconds.

### Passed live checks

- Main page: HTTP 200.
- Capabilities question: HTTP 200, routed locally as `meta` in 0.15 seconds.
- Table-discovery question: HTTP 200, returned 14 tables in 0.03 seconds.
- “What's MTBUR?”: HTTP 200, `domain`, 22.76 seconds.
- “Whats MTBUR?”: HTTP 200, `domain`, 25.50 seconds.
- Generic overview: HTTP 200, returned the cached 27,311-row, 71-column
  fingerprinted profile in 3.96 seconds.
- Named categorical query (`jobtype_distribution`): HTTP 200, returned three
  rows from Databricks with a chart payload in 16.81 seconds.
- The deployed page includes the client-side last-result re-chart path, so a
  chart follow-up does not need to regenerate SQL. Interactive browser clicking
  was not exercised because the test browser cannot route to the private LAN.

### Failed live check and evidence

The free-text question “Which aircraft have the most component removals? Show
the top five.” reached the service, but `ministral-3:8b` produced invalid SQL:

- It invented `AC_Registration_Number` instead of using the live `AC_REG`
  column.
- It selected `COUNT(*) AS sample_size` after the aggregate CTE without a
  corresponding `GROUP BY`.
- Databricks rejected the query with `MISSING_GROUP_BY`.

This is a response-quality failure, not a speed or availability failure. It is
direct evidence for Milestone 3: validate generated identifiers before
execution, include the compact active profile in model context, and make one
bounded repair attempt using the real Databricks error.

### Model comparison

The same failed free-text question was repeated with the already-installed
`qwen3.5:latest` model. It reached the application's 120-second Ollama timeout
without producing SQL. The service was then restored to `ministral-3:8b`.

This single A/B test does not rank the models generally, but it does show that a
model swap alone does not solve the current problem on this hardware. The next
step remains deterministic validation and bounded repair, followed by a small,
repeatable cross-model evaluation set.

---

## Phase 3.2 — Evidence-led distribution stories

Date: **11 October 2026**  
Status: **Implemented locally; Mac deployment verification pending**

### Incident

The question “whats the spread across jobtype and also across removal reason?”
was classified as generic domain knowledge because it began with “whats”. The
application did not query Databricks, returned invented generic percentages and
ATA examples, and had no result rows from which to build a visual.

### Changes implemented

- Analytical cues such as spread, distribution, breakdown, mix, percentage and
  trend now take precedence over conversational domain openers.
- A combined JOBTYPE and REASON question routes to the existing read-only
  `reason_by_jobtype` analytical shortcut.
- The query now calculates full-population job-type totals and percentages while
  returning the leading removal reasons for display.
- Scheduled, unscheduled, other and missing job types are kept distinct.
- Missing and placeholder reason codes are quantified as a visibility gap, not
  presented as an operational cause.
- The answer is generated deterministically from returned figures and leads with
  the actual split, leading valid reasons and a data-quality warning.
- The browser receives a two-panel Plotly.js specification: an overall job-type
  donut and a stacked horizontal chart of the top removal reasons by job type.
- Visual-story generation was isolated in a dependency-free module so it can be
  tested without starting Flask, Databricks or Plotly's Python package.

### Verification

- Total automated tests: 20 passed.
- Python compilation: passed.
- Exact reported question routes to `reason_by_jobtype`: passed in web and CLI
  routing tests.
- Read-only SQL validation: passed.
- Evidence-only summary totals and quality warning: passed.
- Donut plus stacked-bar Plotly specification: passed.
- Live test of the new build: pending. The previously running Mac service
  actively refused the final connection attempt before this local build was
  deployed.

---

## Phase 3.3 — Guided analysis and dataset-portfolio routing

Date: **11 October 2026**  
Status: **Implemented locally; batched with Phase 3.2 for the next Mac push**

### Incidents

- “Give me a general summary of the datasets” fell through to model-generated
  SQL instead of a deterministic overview. One attempt produced SQL that
  Databricks rejected; another reached the Ollama generation timeout.
- The two visible outcomes differed between Focused and Analyst views even
  though both views use the same API route, making the behaviour appear
  view-dependent.
- Example questions existed only in the initial Focused welcome panel and
  disappeared after interaction. Analyst mode had no equivalent examples.
- Successful responses did not guide the user towards useful next questions.
- “What data is available?” matched the broad capabilities rule and returned a
  feature list instead of the discovered data portfolio.

### Changes implemented

- Plural dataset-summary wording now has a dedicated deterministic route and
  never invokes Ollama or generates SQL.
- Data-availability wording now has its own route to the same portfolio. The
  capabilities trigger is limited to explicit feature questions such as “what
  can you do?” and can no longer capture “what data is available?”.
- The portfolio response lists every discovered table, the active table, active
  schema width and conservative indicative coverage derived from table names.
  It explicitly states that content and quality require a verified profile.
- Singular active-dataset overview behaviour remains separate.
- Focused and Analyst views continue to call the same `/api/query` route, so the
  overview decision is identical in both modes.
- A persistent “Try asking” shelf now remains above both composers after the
  welcome panel disappears.
- Every successful response now includes up to three deterministic “Ask next”
  questions appropriate to its response type or shortcut.
- Follow-up chart suggestions reuse the last result locally and do not ask the
  model to regenerate SQL.

### Verification

- Total automated tests: 23 passed.
- Python compilation: passed.
- Exact plural-summary phrase recognised without model/SQL: passed.
- Exact data-availability phrase is not classified as capabilities: passed.
- Dataset-portfolio response generation: passed.
- Persistent prompt shelves present in both rendered modes: passed.
- Follow-up question rendering path present: passed.
- Rendered inline JavaScript syntax check with Node: passed.
- Live Mac verification: pending until the combined next-push package is
  deployed.

---

## Phase 3.4 — Distribution reliability and query control

Date: **11 October 2026**  
Status: **Implemented locally; batched with Phases 3.2/3.3 for the next Mac push**

### Incidents

- “Show me a yearly distribution of job types” fell through to generated SQL
  and Databricks rejected the request.
- Reversing the wording to “overall distribution of jobtype” bypassed the
  trusted shortcut, and the improvised result omitted missing JOBTYPE values.
- “Show me the same distribution including null” was treated as a new request
  because the server did not retain the last successful shortcut as structured
  context.
- “Distribution of year type” was ambiguous but still sent to SQL generation.
- A component-type distribution received an overconfident narrative that
  inferred causes, maintenance strategy and operational risk not established by
  the returned counts.
- A mistaken or slow prompt could not be stopped from the browser.
- The browser hid the detailed Databricks error when the API returned one.

### Changes implemented

- Added symmetric intent phrases for “distribution of jobtype” and routed
  yearly JOBTYPE wording before the overall-distribution rule.
- Hardened the yearly query with `TRY_CAST(... AS TIMESTAMP)`, removed the stale
  2025 ceiling, and made missing and non-standard labels visible.
- Normalised overall JOBTYPE labels using trim/case handling and always exposes
  null or blank labels as `(Missing)`.
- Stored the last successful named shortcut as structured server context. A
  “same/previous distribution” follow-up reruns that trusted query rather than
  asking the model to reconstruct SQL. Context resets when the table or
  conversation changes.
- Ambiguous “year type” wording now asks whether the user means job, component
  or aircraft type instead of attempting SQL.
- Trusted JOBTYPE summaries are deterministic and distinguish record shares
  from reliability conclusions.
- Generic categorical distribution questions now receive a schema-agnostic,
  deterministic summary of returned category counts and shares. This avoids
  model-authored causal narratives for simple descriptive results.
- Tightened the remaining model interpretation prompt: it must distinguish
  record/event/entity counts and cannot infer causes, criticality, maintenance
  maturity or operational impact without direct evidence.
- Added Stop controls to both views. Stop aborts the active browser request and
  clearly warns that an operation already accepted by Databricks may still
  complete server-side.
- The UI now displays structured Databricks error detail returned by the API.
- Yearly visualisation excludes total and percentage denominator fields when
  category-count series are available, reducing chart noise.

### Verification

- Total automated tests: 29 passed.
- Python compilation: passed.
- Rendered inline JavaScript syntax check with Node: passed.
- Exact failed phrasings route deterministically: passed.
- Hardened yearly and overall SQL pass read-only validation: passed.
- Missing-label inclusion and generic grounded component summary: passed.
- Stop controls, browser abort path and detailed-error rendering: present in
  both rendered modes.
- Live Mac/Databricks verification: pending deployment of the combined build.

---

## Phase 3.5 — Domain accuracy and response presentation

Date: **11 October 2026**  
Status: **Implemented locally; included in the next Mac push**

### Incident

A multi-topic reliability question was displayed as a dense, almost entirely
bold block. Headings and comparison tables were not rendered, and nearly every
line was presented as a bullet. The generated content also incorrectly expanded
TSI and TSN as regulatory standards, confused the maintenance-record meaning of
TSO with FAA Technical Standard Order, and made unsupported claims about MTBF
and aircraft utilisation.

### Changes implemented

- Removed the interface-level bold font weight previously applied to every
  answer.
- Replaced the line-break-only Markdown converter with a safe structured
  renderer for headings, paragraphs, genuine bullet/numbered lists, horizontal
  rules, inline emphasis, code and comparison tables.
- Added spacing, hierarchy and responsive table styling for answer content.
- Tightened the general domain prompt: direct answer first, short headings,
  bullets only for lists, restrained emphasis and no invented acronym
  expansions.
- Added explicit terminology safeguards for TSI (Time Since Installation), TSN
  (Time Since New), maintenance-record TSO (Time Since Overhaul) and the separate
  certification meaning, FAA Technical Standard Order.
- Added safeguards distinguishing removals from confirmed failures and
  utilisation exposure from turnaround time.
- Added a deterministic, model-independent knowledge card for combined
  reliability, time-status and aircraft-utilisation questions.
- Domain responses now offer relevant follow-up questions rather than generic
  dataset-navigation prompts.
- Mirrored the terminology and presentation guardrails in the CLI prompt.

### Verification

- Total automated tests: 31 passed.
- Python compilation: passed.
- Rendered inline JavaScript syntax check with Node: passed.
- Exact reported multi-topic question selects the deterministic knowledge card:
  passed.
- The card contains the four intended acronym meanings and excludes the
  invented “Technical Standard Notice” expansion: passed.
- Structured headings, table renderer and normal answer font weight are present:
  passed.
- Live browser verification: pending Mac deployment.

---

## Architecture decisions

### ADR-001 — No table-specific model fine-tuning

Decision: dataset adaptability will be achieved through runtime discovery,
profiling, semantic manifests and retrieval. The model remains replaceable.

### ADR-002 — Short-lived Databricks query connections

Decision: the threaded web application will not share a long-lived Databricks
cursor or connection across requests. Reliability and isolation take precedence
over avoiding connection setup time.

### ADR-003 — Startup default versus active dataset

Decision: `HISTORY_TABLE` identifies only the startup dataset. Runtime queries
use the active dataset stored by the dataset registry.

### ADR-004 — Schema fingerprinting

Decision: column names, data types and comments are canonicalised and hashed.
Stored profiles will be keyed by this fingerprint so schema changes invalidate
stale context automatically.

### ADR-005 — Generic overview replaces default FB overview

Decision: the default overview may only report facts available for any dataset.
Richer statistics will come from the generic profiler rather than hardcoded
aviation columns.

### ADR-006 — Approximate discovery, exact confirmation

Decision: generic profiling uses approximate distinct counts for efficient
discovery. Any candidate identifier or natural key remains unverified until a
separate exact duplicate check confirms it.

### ADR-007 — Profiles are schema-fingerprint scoped

Decision: cached profiles are addressed by dataset reference and live schema
fingerprint. A profile for an older schema is never silently loaded for a newer
schema.

### ADR-008 — Sensitive representative values are suppressed

Decision: representative values may improve semantic understanding, but are
only sampled from bounded low-cardinality fields. Sensitive-looking fields are
excluded, and all value sampling can be disabled by configuration.

---

## Known limitations and technical debt

- Existing named shortcuts remain FB-specific and can fail on unrelated tables.
- Dataset identifiers containing dots, backticks or spaces are not yet supported.
- Discovered objects are currently labelled `TABLE_OR_VIEW`; exact object type
  classification is not yet populated on every Databricks surface.
- Relationships between tables have not yet been inferred.
- Approximate key candidates do not yet run an exact uniqueness confirmation.
- Complex columns currently receive null/completeness statistics only.
- Type-format flags use conservative heuristics and may include legitimate
  operational formats; they require review.
- Generic profile performance has not yet been measured against the live
  free-tier warehouse.
- Free-text SQL is not yet schema-validated before execution; a live test showed
  that `ministral-3:8b` can invent a plausible column name even when live column
  metadata is present in its prompt.
- A rejected generated query is not yet repaired automatically from the real
  Databricks error.
- The CLI still starts from its configured table and does not yet expose the
  browser's full catalog/schema selection workflow.
- Live testing has covered the active dataset only; cross-dataset acceptance on
  at least two structurally different tables is still pending.
- The Stop control currently aborts the browser request. A Databricks statement
  already submitted may continue because the HTTP route does not yet expose a
  cancellable server-side operation handle.

---

## Next phase — Profile-informed reasoning

Planned outcomes:

- Give the LLM a compact, value-safe profile of the active dataset.
- Build model context from live metadata and the matching fingerprinted
  profile, never from one table's hardcoded notes.
- Match user language to likely columns using metadata, comments, inferred
  roles and safe low-cardinality values.
- Prevent table-specific shortcuts from appearing or running when their
  required columns are absent.
- Validate generated column references against the active schema before SQL is
  executed.
- Add one bounded repair attempt that receives the real Databricks error and
  live schema context.
- Include dataset reference, schema fingerprint and profile timestamp in answer
  provenance.

---

## Milestone acceptance checklist

### Milestone 1

- [x] Expired-session recovery implemented.
- [x] Read-only query client implemented.
- [x] Structured API errors implemented.
- [x] Catalog/schema/table discovery implemented.
- [x] Server-side table switching implemented.
- [x] Live schema metadata captured.
- [x] Schema fingerprint implemented.
- [x] Automated tests passed locally.
- [x] Deployed to the Mac.
- [x] Verified against live Databricks.

### Milestone 2

- [x] Generic profiler implemented.
- [x] Profiles cached by schema fingerprint.
- [x] Profile visible in the web interface.
- [x] Offline tests use an unfamiliar synthetic schema.
- [x] No FB-specific field names required by the profiler.
- [ ] Tested live against at least three structurally different datasets.

### Milestone 3

- [ ] Compact profile included in model context.
- [ ] Generated column references validated before execution.
- [ ] Incompatible table-specific shortcuts blocked or hidden.
- [ ] One bounded, evidence-based SQL repair attempt implemented.
- [ ] Answer provenance includes active dataset and profile identity.
- [ ] Tested with questions across three different dataset structures.

---

## Build-log update rules

At every material change:

1. Update the current milestone and phase status.
2. Record what changed and why.
3. Record tests run and their results.
4. Record live verification separately from local automated verification.
5. Add or update an architecture decision when a durable design choice is made.
6. Record known limitations without presenting them as completed work.
7. Update the next action so another session can resume without reconstruction.

## Next action

Deploy and verify the combined Phase 3.2/3.3/3.4/3.5 package on the Mac, then implement
Phase 4: use the matching generic profile to improve SQL generation and response
quality. Do not fine-tune or hardcode the model for a specific table, and do not
expand the FB-specific shortcut set.

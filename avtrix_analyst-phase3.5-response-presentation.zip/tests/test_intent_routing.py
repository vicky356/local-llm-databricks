import sys
import types
import unittest


try:
    import dotenv  # noqa: F401
except ImportError:
    dotenv = types.ModuleType("dotenv")
    dotenv.load_dotenv = lambda *args, **kwargs: None
    sys.modules["dotenv"] = dotenv

try:
    import flask  # noqa: F401
except ImportError:
    flask = types.ModuleType("flask")

    class _TestFlask:
        def __init__(self, *args, **kwargs):
            self.secret_key = None

        def route(self, *args, **kwargs):
            return lambda function: function

        def errorhandler(self, *args, **kwargs):
            return lambda function: function

    flask.Flask = _TestFlask
    flask.request = types.SimpleNamespace(path="/")
    flask.jsonify = lambda payload=None, **kwargs: payload if payload is not None else kwargs
    sys.modules["flask"] = flask

from avtrix_analyst import NAMED_QUERIES, _match_shortcut_by_intent, classify_intent_cli
from databricks_client import validate_read_only_sql
import web_analyst as web

classify_intent_web = web.classify_intent


class IntentRoutingTests(unittest.TestCase):
    def test_stale_shortcut_pattern_falls_through_instead_of_raising(self):
        self.assertNotIn("mtbur_by_part", NAMED_QUERIES)
        self.assertIsNone(_match_shortcut_by_intent("What's MTBUR?"))
        self.assertEqual(classify_intent_cli("What's MTBUR?"), "domain")
        self.assertEqual(classify_intent_cli("Whats MTBUR?"), "domain")

    def test_available_shortcut_still_matches(self):
        shortcut = _match_shortcut_by_intent("Show the jobtype distribution")
        self.assertEqual(shortcut, "jobtype_distribution")
        self.assertIn(shortcut, NAMED_QUERIES)

    def test_reversed_jobtype_wording_uses_trusted_distribution(self):
        shortcut = _match_shortcut_by_intent("show me an overall distribution of jobtype")
        self.assertEqual(shortcut, "jobtype_distribution")
        sql = NAMED_QUERIES[shortcut]["sql"]
        self.assertIn("'(Missing)'", sql)
        self.assertIn("UPPER(TRIM(JOBTYPE))", sql)

    def test_yearly_jobtype_wording_uses_hardened_temporal_query(self):
        shortcut = _match_shortcut_by_intent("show me a yearly distribution of job types")
        self.assertEqual(shortcut, "jobtype_temporal")
        sql = NAMED_QUERIES[shortcut]["sql"].format(
            table="poc.avtrix_fb.fb_camp_fleet_history_join"
        )
        self.assertIn("TRY_CAST(REMOVAL_C_W_MOS AS TIMESTAMP)", sql)
        self.assertIn("missing_jobtype", sql)
        self.assertNotIn("BETWEEN 1995 AND 2025", sql)
        self.assertIsNone(validate_read_only_sql(sql))

    def test_contextual_repeat_and_ambiguous_year_type_are_recognised(self):
        self.assertTrue(web._is_contextual_repeat("show me the same distribution including null"))
        self.assertTrue(web._is_ambiguous_year_type_question("show me a distribution of year type"))
        self.assertFalse(web._is_ambiguous_year_type_question("show job type by year"))

    def test_combined_jobtype_reason_question_uses_data_story(self):
        question = "whats the spread across jobtype and also across removal reason?"
        shortcut = _match_shortcut_by_intent(question)
        self.assertEqual(shortcut, "reason_by_jobtype")
        self.assertIn(shortcut, NAMED_QUERIES)
        self.assertEqual(classify_intent_cli(question), "analytical")
        self.assertEqual(classify_intent_web(question), "analytical")
        sql = NAMED_QUERIES[shortcut]["sql"].format(
            table="poc.avtrix_fb.fb_camp_fleet_history_join"
        )
        self.assertIsNone(validate_read_only_sql(sql))

    def test_plural_dataset_summary_is_deterministic(self):
        question = "give me a general summary of the datasets"
        self.assertTrue(web._is_multi_dataset_overview(question))
        original = list(web.discovered_tables)
        try:
            web.discovered_tables[:] = [
                "poc.avtrix_fb.fb_camp_fleet_history_join",
                "poc.avtrix_fb.unified_fleet_detailed_utilization",
            ]
            result = web.answer_dataset_portfolio()
        finally:
            web.discovered_tables[:] = original
        self.assertEqual(result["type"], "overview")
        self.assertEqual(len(result["rows"]), 2)
        self.assertIn("Dataset portfolio", result["answer"])

    def test_data_availability_is_not_misclassified_as_capabilities(self):
        question = "what data is available"
        self.assertTrue(web._is_data_availability_question(question))
        self.assertFalse(web._is_capabilities_question(question))
        self.assertTrue(web._is_capabilities_question("what can you do?"))

    def test_ui_keeps_examples_and_renders_followup_questions(self):
        page = web.render_html()
        self.assertGreaterEqual(page.count('class="prompt-shelf"'), 2)
        self.assertIn("Ask next", page)
        self.assertIn("suggested_questions", page)

    def test_ui_has_stop_control_and_detailed_query_errors(self):
        page = web.render_html()
        self.assertIn('id="stop-btn"', page)
        self.assertIn('id="analyst-stop-btn"', page)
        self.assertIn("new AbortController()", page)
        self.assertIn("Databricks detail:", page)

    def test_domain_answers_have_structured_markdown_rendering(self):
        page = web.render_html()
        self.assertIn("function inlineMarkdown", page)
        self.assertIn("class=\"answer-table\"", page)
        self.assertIn(".answer-lead { font-weight:400", page)
        self.assertIn("const heading = line.match", page)

    def test_reliability_status_utilisation_question_uses_verified_card(self):
        question = "what is reliability? TSI and TSN or TSO? Aircraft utilization"
        self.assertTrue(web._is_reliability_glossary_question(question))
        result = web.answer_reliability_glossary()
        self.assertEqual(result["type"], "domain")
        self.assertIn("## Reliability", result["answer"])
        self.assertIn("Time Since Installation", result["answer"])
        self.assertIn("Time Since New", result["answer"])
        self.assertIn("Time Since Overhaul", result["answer"])
        self.assertIn("Technical Standard Order", result["answer"])
        self.assertIn("## Aircraft utilization", result["answer"])
        self.assertNotIn("Technical Standard Notice", result["answer"])

    def test_trusted_jobtype_summary_is_grounded(self):
        answer = web.summarise_jobtype_distribution(
            ["job_type", "record_count", "pct_of_total"],
            [["SCHEDULED", 17, 68.0], ["UNSCHEDULED", 5, 20.0], ["(Missing)", 3, 12.0]],
        )
        self.assertIn("25 records", answer)
        self.assertIn("(Missing)", answer)
        self.assertIn("do not by themselves establish failure rates", answer)
        self.assertIn("Do not infer causes", web.RESULT_INTERPRETATION_SYSTEM)

    def test_generic_component_distribution_uses_exact_counts_not_model_story(self):
        columns = [
            "component_type", "total_components", "unique_aircraft",
            "removals", "installations", "replacements",
        ]
        rows = [
            ["AIRCRAFT", 24131, 5, 933, 777, 42],
            ["ENGINE", 2923, 5, 69, 76, 36],
            ["APU", 256, 5, 14, 14, 16],
        ]
        answer = web.summarise_categorical_distribution(
            "show me a distribution of component type", columns, rows
        )
        self.assertIn("27,310", answer)
        self.assertIn("AIRCRAFT", answer)
        self.assertIn("88.4%", answer)
        self.assertIn("do not by themselves establish failure rates", answer)


if __name__ == "__main__":
    unittest.main()

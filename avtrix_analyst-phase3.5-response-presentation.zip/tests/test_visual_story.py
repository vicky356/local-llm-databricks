import unittest

from visual_story import (
    summarise_reason_by_jobtype,
    build_reason_jobtype_story_chart,
)


COLUMNS = [
    "reason",
    "scheduled_count",
    "unscheduled_count",
    "other_jobtype_count",
    "missing_jobtype_count",
    "total",
    "pct_of_all_records",
    "grand_total",
    "grand_scheduled",
    "grand_unscheduled",
    "grand_other_jobtype",
    "grand_missing_jobtype",
    "grand_unusable_reason",
]

ROWS = [
    ["-", 420, 70, 0, 110, 600, 60.0, 1000, 650, 150, 20, 180, 600],
    ["FAILURE", 120, 60, 10, 30, 220, 22.0, 1000, 650, 150, 20, 180, 600],
    ["LEAK", 110, 20, 10, 20, 160, 16.0, 1000, 650, 150, 20, 180, 600],
    ["DAMAGE", 0, 0, 0, 20, 20, 2.0, 1000, 650, 150, 20, 180, 600],
]


class VisualStoryTests(unittest.TestCase):
    def test_summary_uses_exact_returned_totals_and_warns_about_quality(self):
        summary = summarise_reason_by_jobtype(COLUMNS, ROWS)
        self.assertIn("1,000 records", summary)
        self.assertIn("Scheduled:** 650 (65.0%)", summary)
        self.assertIn("Unscheduled:** 150 (15.0%)", summary)
        self.assertIn("600 records (60.0%)", summary)
        self.assertIn("**FAILURE** — 220 (22.0%)", summary)

    def test_story_chart_contains_donut_and_stacked_bars(self):
        chart = build_reason_jobtype_story_chart(COLUMNS, ROWS)
        self.assertIsNotNone(chart)
        trace_types = [trace["type"] for trace in chart["data"]]
        self.assertIn("pie", trace_types)
        self.assertIn("bar", trace_types)
        self.assertEqual(chart["layout"]["barmode"], "stack")


if __name__ == "__main__":
    unittest.main()

"""Evidence-led narrative and Plotly specs for analytical story responses.

This module deliberately has no Flask, Databricks or Plotly dependency. The web
app can return the generated figure specification directly to Plotly.js, while
unit tests can verify the story offline.
"""


def _positions(columns):
    return {str(name).lower(): index for index, name in enumerate(columns)}


def _cell(row, positions, name, default=0):
    index = positions.get(name)
    if index is None or index >= len(row) or row[index] is None:
        return default
    return row[index]


def _number(raw):
    try:
        return float(raw)
    except (TypeError, ValueError):
        return 0.0


def _count(raw):
    return f"{int(round(_number(raw))):,}"


def summarise_reason_by_jobtype(columns, rows):
    """Build an evidence-only executive summary for the combined distribution.

    The query repeats full-population totals on every displayed reason row, so
    the headline is not distorted by the top-20 visual limit.
    """
    if not rows:
        return "No job-type or removal-reason records were returned."

    positions = _positions(columns)
    first = rows[0]
    grand_total = _number(_cell(first, positions, "grand_total"))
    scheduled = _number(_cell(first, positions, "grand_scheduled"))
    unscheduled = _number(_cell(first, positions, "grand_unscheduled"))
    other = _number(_cell(first, positions, "grand_other_jobtype"))
    missing = _number(_cell(first, positions, "grand_missing_jobtype"))
    unusable_reason = _number(_cell(first, positions, "grand_unusable_reason"))

    def pct(raw):
        return (_number(raw) * 100.0 / grand_total) if grand_total else 0.0

    placeholders = {"", "-", "--", "N/A", "NA", "NULL", "NONE", "UNKNOWN", "(MISSING)"}
    reason_rows = []
    for row in rows:
        label = str(_cell(row, positions, "reason", "(Missing)"))
        if label.strip().upper() in placeholders:
            continue
        reason_rows.append((
            label,
            _number(_cell(row, positions, "total")),
            _number(_cell(row, positions, "pct_of_all_records")),
        ))

    leading = reason_rows[:3]
    leading_text = "; ".join(
        f"**{label}** — {_count(total)} ({share:.1f}%)"
        for label, total, share in leading
    ) or "No usable removal-reason labels were found in the displayed categories."

    headline_parts = [
        f"**Scheduled:** {_count(scheduled)} ({pct(scheduled):.1f}%)",
        f"**Unscheduled:** {_count(unscheduled)} ({pct(unscheduled):.1f}%)",
    ]
    if other:
        headline_parts.append(f"**Other:** {_count(other)} ({pct(other):.1f}%)")
    headline_parts.append(f"**Missing job type:** {_count(missing)} ({pct(missing):.1f}%)")

    quality_text = (
        f"Unusable or missing removal-reason labels account for **{_count(unusable_reason)} "
        f"records ({pct(unusable_reason):.1f}%)**. Treat that as a visibility gap, not an "
        "operational cause."
        if unusable_reason
        else "No configured placeholder removal-reason codes were detected."
    )

    return (
        f"**What the data says — {_count(grand_total)} records**\n\n"
        + " · ".join(headline_parts)
        + "\n\n"
        + f"**Leading valid removal reasons:** {leading_text}\n\n"
        + f"**Data-quality warning:** {quality_text}\n\n"
        + "The visual pairs the overall job-type mix with the leading removal reasons split by "
          "scheduled, unscheduled, other and missing job type. This shows both the operational "
          "pattern and where incomplete classification weakens the conclusion."
    )


def build_reason_jobtype_story_chart(columns, rows):
    """Return a dependency-free Plotly.js two-panel figure specification."""
    if not columns or not rows:
        return None
    positions = _positions(columns)
    required = {
        "reason", "scheduled_count", "unscheduled_count", "other_jobtype_count",
        "missing_jobtype_count", "grand_scheduled", "grand_unscheduled",
        "grand_other_jobtype", "grand_missing_jobtype",
    }
    if not required.issubset(positions):
        return None

    first = rows[0]
    jobs = [
        ("Scheduled", _cell(first, positions, "grand_scheduled"), "#B8864F"),
        ("Unscheduled", _cell(first, positions, "grand_unscheduled"), "#D96C4A"),
        ("Other", _cell(first, positions, "grand_other_jobtype"), "#6F8FAF"),
        ("Missing", _cell(first, positions, "grand_missing_jobtype"), "#697583"),
    ]
    jobs = [item for item in jobs if _number(item[1])]

    display_rows = list(rows[:10])[::-1]
    reasons = [str(_cell(row, positions, "reason", "(Missing)")) for row in display_rows]
    data = [{
        "type": "pie",
        "labels": [item[0] for item in jobs],
        "values": [item[1] for item in jobs],
        "hole": 0.58,
        "textinfo": "label+percent",
        "textposition": "outside",
        "marker": {"colors": [item[2] for item in jobs]},
        "hovertemplate": "%{label}: %{value:,} (%{percent})<extra></extra>",
        "sort": False,
        "domain": {"x": [0.0, 0.29], "y": [0.0, 1.0]},
        "name": "Job type",
    }]

    series = [
        ("Scheduled", "scheduled_count", "#B8864F"),
        ("Unscheduled", "unscheduled_count", "#D96C4A"),
        ("Other", "other_jobtype_count", "#6F8FAF"),
        ("Missing", "missing_jobtype_count", "#697583"),
    ]
    for label, column, colour in series:
        values = [_cell(row, positions, column) for row in display_rows]
        if not any(_number(value) for value in values):
            continue
        data.append({
            "type": "bar",
            "name": label,
            "x": values,
            "y": reasons,
            "orientation": "h",
            "marker": {"color": colour},
            "hovertemplate": f"{label}: %{{x:,}}<extra>%{{y}}</extra>",
            "xaxis": "x2",
            "yaxis": "y2",
        })

    layout = {
        "barmode": "stack",
        "paper_bgcolor": "rgba(0,0,0,0)",
        "plot_bgcolor": "rgba(0,0,0,0)",
        "font": {"color": "#FCFAF6", "family": "Inter, ui-sans-serif, sans-serif"},
        "legend": {"orientation": "h", "yanchor": "bottom", "y": 1.06, "xanchor": "right", "x": 1},
        "margin": {"l": 24, "r": 20, "t": 72, "b": 45},
        "height": 430,
        "xaxis2": {
            "domain": [0.42, 1.0],
            "title": {"text": "Records"},
            "gridcolor": "rgba(138,155,173,0.18)",
            "anchor": "y2",
        },
        "yaxis2": {
            "domain": [0.0, 1.0],
            "title": {"text": "Removal reason"},
            "anchor": "x2",
            "automargin": True,
        },
        "annotations": [
            {"text": "Overall job-type mix", "x": 0.145, "y": 1.08, "xref": "paper", "yref": "paper", "showarrow": False},
            {"text": "Top removal reasons by job type", "x": 0.71, "y": 1.08, "xref": "paper", "yref": "paper", "showarrow": False},
        ],
    }
    return {"data": data, "layout": layout}
